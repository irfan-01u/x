import { Subject, Chapter, Topic, Task, Note, Exam, StudyBlock, Achievement, UserProfile, StudySession } from '../types';

export const INITIAL_SUBJECTS: Subject[] = [];

export const INITIAL_CHAPTERS: Chapter[] = [];

export const INITIAL_TOPICS: Topic[] = [];

export const INITIAL_TASKS: Task[] = [];

export const INITIAL_NOTES: Note[] = [];

export const INITIAL_EXAMS: Exam[] = [];

export const INITIAL_STUDY_BLOCKS: StudyBlock[] = [];

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  { id: 'ach-1', title: 'First Hour', description: 'Log your first 60 minutes of focused study time', category: 'TIME', targetValue: 1, unit: 'hours', unlocked: false, icon: 'Clock' },
  { id: 'ach-2', title: '10 Hours', description: 'Accumulate 10 total hours of deep study', category: 'TIME', targetValue: 10, unit: 'hours', unlocked: false, icon: 'Timer' },
  { id: 'ach-3', title: '50 Hours', description: 'Accumulate 50 total hours of academic study', category: 'TIME', targetValue: 50, unit: 'hours', unlocked: false, icon: 'Flame' },
  { id: 'ach-4', title: '100 Hours', description: 'Centurion scholar: Reach 100 hours of study', category: 'TIME', targetValue: 100, unit: 'hours', unlocked: false, icon: 'ShieldAlert' },
  { id: 'ach-5', title: '500 Hours', description: 'Ascend to grandmaster academic consistency', category: 'TIME', targetValue: 500, unit: 'hours', unlocked: false, icon: 'Crown' },
  { id: 'ach-6', title: '1000 Hours', description: 'Legendary scholar status: 1000 study hours', category: 'TIME', targetValue: 1000, unit: 'hours', unlocked: false, icon: 'Gem' },

  { id: 'ach-7', title: '3-Day Momentum', description: 'Maintain a study streak for 3 consecutive days', category: 'STREAK', targetValue: 3, unit: 'days', unlocked: false, icon: 'Zap' },
  { id: 'ach-8', title: '7-Day Iron Discipline', description: 'Complete daily study goals 7 days straight', category: 'STREAK', targetValue: 7, unit: 'days', unlocked: false, icon: 'Award' },
  { id: 'ach-9', title: '30-Day Relentless Habit', description: 'Reach a full 30-day streak milestone', category: 'STREAK', targetValue: 30, unit: 'days', unlocked: false, icon: 'Calendar' },
  { id: 'ach-10', title: '100-Day Dynasty', description: 'Preserve your daily streak for 100 days', category: 'STREAK', targetValue: 100, unit: 'days', unlocked: false, icon: 'Sparkles' },

  { id: 'ach-11', title: 'First Pomodoro', description: 'Finish your very first 25-minute Pomodoro cycle', category: 'POMODORO', targetValue: 1, unit: 'pomodoros', unlocked: false, icon: 'CheckCircle2' },
  { id: 'ach-12', title: '10 Pomodoros', description: 'Complete 10 focused Pomodoro cycles', category: 'POMODORO', targetValue: 10, unit: 'pomodoros', unlocked: false, icon: 'Target' },
  { id: 'ach-13', title: '50 Pomodoros', description: 'Complete 50 disciplined Pomodoro sessions', category: 'POMODORO', targetValue: 50, unit: 'pomodoros', unlocked: false, icon: 'Compass' },
  { id: 'ach-14', title: '100 Pomodoros', description: 'Century Pomodoro master: 100 cycles', category: 'POMODORO', targetValue: 100, unit: 'pomodoros', unlocked: false, icon: 'Medal' },
  { id: 'ach-15', title: '500 Pomodoros', description: 'Zenith of single-task flow: 500 pomodoros', category: 'POMODORO', targetValue: 500, unit: 'pomodoros', unlocked: false, icon: 'Star' },

  { id: 'ach-16', title: 'Perfect Week', description: 'Study on all 7 days of a calendar week', category: 'CONSISTENCY', targetValue: 7, unit: 'days', unlocked: false, icon: 'CheckSquare' },
  { id: 'ach-17', title: '20 Study Days / Month', description: 'Log productive study sessions across 20 separate days', category: 'CONSISTENCY', targetValue: 20, unit: 'days', unlocked: false, icon: 'CalendarDays' },

  { id: 'ach-18', title: 'First Subject Mastery', description: 'Complete 100% of chapters in any subject', category: 'SUBJECT', targetValue: 1, unit: 'subject', unlocked: false, icon: 'BookOpen' },
  { id: 'ach-19', title: '5 Chapters Conquered', description: 'Complete 5 syllabus chapters across subjects', category: 'SUBJECT', targetValue: 5, unit: 'chapters', unlocked: false, icon: 'BookmarkCheck' },

  { id: 'ach-20', title: 'Early Bird', description: 'Complete a study session before 7:00 AM', category: 'SPECIAL', targetValue: 1, unit: 'session', unlocked: false, icon: 'Sunrise' },
  { id: 'ach-21', title: 'Night Owl', description: 'Complete a deep work session past midnight', category: 'SPECIAL', targetValue: 1, unit: 'session', unlocked: false, icon: 'Moon' },
  { id: 'ach-22', title: 'Weekend Warrior', description: 'Study over 4 hours across Saturday & Sunday', category: 'SPECIAL', targetValue: 4, unit: 'hours', unlocked: false, icon: 'Coffee' },
  { id: 'ach-23', title: 'Deep Work Master', description: 'Complete a continuous 90-minute session without pauses', category: 'SPECIAL', targetValue: 90, unit: 'minutes', unlocked: false, icon: 'ZapOff' },
  { id: 'ach-24', title: 'Goal Crusher', description: 'Exceed your daily target by 150% in a single day', category: 'SPECIAL', targetValue: 150, unit: 'percent', unlocked: false, icon: 'Trophy' },
];

export const INITIAL_USER_PROFILE: UserProfile = {
  id: '',
  accountType: 'guest',
  deviceId: '',
  name: 'Student',
  username: 'student',
  avatar: '',
  bio: '',
  dailyGoalMinutes: 0,
  preferredSubjects: [],
  examDate: '',
  studyTarget: '',
  level: 1,
  xp: 0,
  pinnedAchievementIds: [],
  privacy: {
    isPublic: false,
    showOnLeaderboard: true,
    showAvatar: true,
    showRealName: false,
    discoverable: false,
  },
};

export function generateInitialSessions(): StudySession[] {
  return [];
}
