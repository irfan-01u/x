import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import confetti from 'canvas-confetti';
import {
  StudySession,
  Subject,
  Chapter,
  Task,
  Note,
  Exam,
  StudyBlock,
  Achievement,
  UserProfile,
  NotificationItem,
  AppSettings,
  SyncStatus,
  DailyGoal,
  StreakData,
  TimerMode,
  StudyType,
  Difficulty,
  LeaderboardUser,
  ActiveStopwatchServerSession,
  DailyLeaderboardData,
} from '../types';
import {
  INITIAL_ACHIEVEMENTS,
  INITIAL_USER_PROFILE,
} from '../data/initialData';
import { soundFx } from '../utils/audio';

const LEGACY_STORAGE_KEY_PREFIX = 'studium_app_';
const DEVICE_ID_STORAGE_KEY = 'notiq:device:id';

function createDeviceIdentity(): string {
  try {
    const existing = localStorage.getItem(DEVICE_ID_STORAGE_KEY);
    if (existing && /^device:[A-Za-z0-9_-]{16,}$/.test(existing)) return existing;
  } catch {}

  let randomId = '';
  try {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      randomId = crypto.randomUUID().replace(/-/g, '');
    } else if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
      const bytes = new Uint8Array(24);
      crypto.getRandomValues(bytes);
      randomId = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
    }
  } catch {}
  if (!randomId) {
    randomId = `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}${Math.random().toString(36).slice(2)}`;
  }
  const id = `device:${randomId}`;
  try { localStorage.setItem(DEVICE_ID_STORAGE_KEY, id); } catch {}
  return id;
}

const DEVICE_ID = createDeviceIdentity();
const STORAGE_KEY_PREFIX = `notiq:device:${DEVICE_ID}:`;
const DEMO_SEED_VERSION = '2026-09-26-clean';
const DEMO_SUBJECT_IDS = new Set(['subj-1','subj-2','subj-3','subj-4','subj-5']);
const DEMO_CHAPTER_IDS = new Set(['chap-1-1','chap-1-2','chap-1-3','chap-2-1','chap-2-2','chap-3-1','chap-3-2','chap-4-1']);
const DEMO_TASK_IDS = new Set(['task-1','task-2','task-3','task-4']);
const DEMO_NOTE_IDS = new Set(['note-1','note-2','note-3']);
const DEMO_EXAM_IDS = new Set(['exam-1','exam-2','exam-3']);
const DEMO_BLOCK_IDS = new Set(['blk-1','blk-2','blk-3','blk-4','blk-5','blk-6','blk-7']);
const DEMO_SESSION_PREFIX = 'sess-seed-';
const DEMO_ACHIEVEMENT_IDS = new Set(Array.from({ length: 24 }, (_, i) => `ach-${i + 1}`));

function storageKey(key: string): string {
  return `${STORAGE_KEY_PREFIX}${key}`;
}

function migrateLegacyLocalDataToDeviceNamespace() {
  // Legacy data is migrated only from this browser's own storage. A fresh device/browser has no legacy keys.
  try {
    const marker = storageKey('legacyMigrationVersion');
    if (localStorage.getItem(marker) === '2') return;

    const keys = ['sessions','subjects','chapters','tasks','notes','exams','studyBlocks','achievements','profile','settings','notifications','dailyGoals','activeTimer'];
    for (const key of keys) {
      const namespaced = storageKey(key);
      if (localStorage.getItem(namespaced) === null) {
        const legacy = localStorage.getItem(`${LEGACY_STORAGE_KEY_PREFIX}${key}`);
        if (legacy !== null) localStorage.setItem(namespaced, legacy);
      }
    }

    const legacyProfileRaw = localStorage.getItem(`${LEGACY_STORAGE_KEY_PREFIX}profile`);
    if (legacyProfileRaw && !localStorage.getItem(storageKey('profile'))) {
      try {
        const legacyProfile = JSON.parse(legacyProfileRaw);
        if (legacyProfile && (legacyProfile.id === 'guest-user' || legacyProfile.id === 'usr-main-me' || legacyProfile.username === 'student' || legacyProfile.username === 'irfanzaman')) {
          legacyProfile.id = DEVICE_ID;
          legacyProfile.accountType = 'guest';
          legacyProfile.deviceId = DEVICE_ID;
          legacyProfile.name = legacyProfile.name || 'Student';
          legacyProfile.username = legacyProfile.username || 'student';
          localStorage.setItem(storageKey('profile'), JSON.stringify(legacyProfile));
        }
      } catch {}
    }
    for (const key of keys) {
      try { localStorage.removeItem(`${LEGACY_STORAGE_KEY_PREFIX}${key}`); } catch {}
    }
    localStorage.setItem(marker, '2');
  } catch {}
}

migrateLegacyLocalDataToDeviceNamespace();

function cleanKnownDemoLocalData() {
  const parse = <T,>(key: string, fallback: T): T => {
    try {
      const raw = localStorage.getItem(storageKey(key));
      return raw ? JSON.parse(raw) : fallback;
    } catch { return fallback; }
  };
  const write = (key: string, value: unknown) => localStorage.setItem(storageKey(key), JSON.stringify(value));
  const filterByIds = <T extends { id?: string }>(key: string, ids: Set<string>) => {
    const value = parse<T[]>(key, []);
    if (!Array.isArray(value)) return [];
    const cleaned = value.filter(item => !item?.id || !ids.has(item.id));
    write(key, cleaned);
    return cleaned;
  };
  filterByIds('subjects', DEMO_SUBJECT_IDS);
  filterByIds('chapters', DEMO_CHAPTER_IDS);
  filterByIds('tasks', DEMO_TASK_IDS);
  filterByIds('notes', DEMO_NOTE_IDS);
  filterByIds('exams', DEMO_EXAM_IDS);
  filterByIds('studyBlocks', DEMO_BLOCK_IDS);
  const sessions = parse<any[]>('sessions', []).filter(s => !String(s?.id || '').startsWith(DEMO_SESSION_PREFIX));
  write('sessions', sessions);
  const achievements = parse<any[]>('achievements', []).map(a => DEMO_ACHIEVEMENT_IDS.has(a?.id) ? { ...a, unlocked: false, unlockedAt: undefined } : a);
  write('achievements', achievements);
  const savedProfile = parse<any>('profile', null);
  if (savedProfile && (savedProfile.id === 'usr-main-me' || savedProfile.id === 'guest-user' || savedProfile.username === 'irfanzaman')) {
    write('profile', { ...INITIAL_USER_PROFILE, id: DEVICE_ID, accountType: 'guest', deviceId: DEVICE_ID });
  }
  const goals = parse<Record<string, any>>('dailyGoals', {});
  const cleanedGoals = Object.fromEntries(Object.entries(goals).filter(([, g]) => !g || !String(g.id || '').startsWith('gt-')));
  write('dailyGoals', cleanedGoals);
  // Demo notifications are explicitly identified by their legacy ids. Preserve user-created notifications.
  const notifications = parse<any[]>('notifications', []).filter(n => !['notif-1','notif-2'].includes(n?.id));
  write('notifications', notifications);
  localStorage.setItem(storageKey('demoCleanupVersion'), DEMO_SEED_VERSION);
}


export interface ActiveTimerState {
  mode: TimerMode;
  status: 'idle' | 'running' | 'paused';
  startTime?: number; // timestamp
  lastTickTime?: number;
  targetDuration: number; // in seconds
  elapsedSeconds: number; // accumulated running seconds
  subjectId: string;
  chapterId?: string;
  studyType: StudyType;
  difficulty: Difficulty;
  taskTitle: string;
  note: string;
  tags: string[];
  sessionId?: string;
  pomodoro: {
    phase: 'focus' | 'shortBreak' | 'longBreak';
    cycle: number;
    totalCycles: number;
    completedFocusCount: number;
    interruptedCount: number;
  };
  stopwatch: {
    laps: Array<{ lapNumber: number; lapTime: number; totalTime: number }>;
  };
}

export interface SessionCompletionData {
  session: StudySession;
  earnedXP: number;
  newLevel?: number;
  isGoalCompleted: boolean;
  newStreak: number;
  rankImpact: string;
  unlockedAchievements: Achievement[];
}

interface StudiumContextType {
  // Primary Source of Truth
  sessions: StudySession[];
  subjects: Subject[];
  chapters: Chapter[];
  tasks: Task[];
  notes: Note[];
  exams: Exam[];
  studyBlocks: StudyBlock[];
  achievements: Achievement[];
  profile: UserProfile;
  settings: AppSettings;
  syncStatus: SyncStatus;
  notifications: NotificationItem[];
  dailyGoals: Record<string, DailyGoal>;
  streakData: StreakData;
  activeTimer: ActiveTimerState;
  leaderboardUsers: LeaderboardUser[];
  currentCompletion: SessionCompletionData | null;
  clearCompletionModal: () => void;

  // Persistent Stopwatch & Daily Leaderboard
  recoveredStopwatchSession: ActiveStopwatchServerSession | null;
  conflictStopwatchSession: ActiveStopwatchServerSession | null;
  dailyLeaderboard: DailyLeaderboardData | null;
  isDailyLeaderboardLoading: boolean;
  isOfflineMode: boolean;
  refreshDailyLeaderboard: () => Promise<void>;
  resumeRecoveredStopwatch: () => void;
  finishRecoveredStopwatch: () => void;
  cancelRecoveredStopwatch: () => void;
  dismissRecoveryModal: () => void;
  resolveConflictWithResume: () => void;
  resolveConflictWithDiscard: (newSetup?: Partial<ActiveTimerState>) => void;
  dismissConflictModal: () => void;

  // Active Timer / Pomodoro / Stopwatch Controls
  startTimer: (setup?: Partial<ActiveTimerState>, force?: boolean) => void;
  pauseTimer: () => void;
  resumeTimer: () => void;
  resetTimer: () => void;
  finishTimerSession: (interrupted?: boolean) => void;
  cancelTimerSession: () => void;
  adjustTimerTime: (deltaSeconds: number) => void;
  skipPomodoroPhase: () => void;
  addStopwatchLap: () => void;
  quickStart: (minutes: number, mode?: TimerMode) => void;

  // Subjects Management
  addSubject: (subject: Omit<Subject, 'id' | 'createdAt' | 'order'>) => void;
  updateSubject: (id: string, updates: Partial<Subject>) => void;
  deleteSubject: (id: string) => void;
  reorderSubjects: (ids: string[]) => void;

  // Chapter Management
  addChapter: (chapter: Omit<Chapter, 'id'>) => void;
  markChapterCompleted: (chapterId: string, completed?: boolean) => void;
  updateChapter: (id: string, updates: Partial<Chapter>) => void;
  deleteChapter: (id: string) => void;
  toggleChecklistItem: (chapterId: string, itemId: string) => void;
  addChecklistItem: (chapterId: string, title: string) => void;
  removeChecklistItem: (chapterId: string, itemId: string) => void;
  markChapterRevisionCompleted: (chapterId: string) => void;

  // Task Management
  addTask: (task: Omit<Task, 'id'>) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  toggleTaskCompletion: (id: string) => void;
  startTimerFromTask: (task: Task) => void;

  // Notes Management
  addNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateNote: (id: string, updates: Partial<Note>) => void;
  deleteNote: (id: string) => void;
  duplicateNote: (id: string) => void;

  // Exams Management
  addExam: (exam: Omit<Exam, 'id'>) => void;
  updateExam: (id: string, updates: Partial<Exam>) => void;
  deleteExam: (id: string) => void;

  // Study Planner Management
  addStudyBlock: (block: Omit<StudyBlock, 'id'>) => void;
  updateStudyBlock: (id: string, updates: Partial<StudyBlock>) => void;
  deleteStudyBlock: (id: string) => void;

  // Daily Goal Management
  updateDailyGoalTarget: (minutes: number) => void;
  addGoalTask: (title: string) => void;
  toggleGoalTask: (id: string) => void;
  deleteGoalTask: (id: string) => void;

  // Streaks Management
  useStreakFreeze: () => void;

  // Achievements
  togglePinAchievement: (achievementId: string) => void;

  // Profile & Settings
  updateProfile: (updates: Partial<UserProfile>) => void;
  updateSettings: (updates: Partial<AppSettings>) => void;
  toggleWidget: (widgetKey: string) => void;

  // Notifications
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  clearNotification: (id: string) => void;

  // Session History Management
  deleteSession: (id: string) => void;

  // Ambient sound
  ambientPlaying: string | null;
  toggleAmbientSound: (type: 'rain' | 'whitenoise' | 'binaural' | 'drone') => void;
  setAmbientVolume: (vol: number) => void;

  // Cloud Sync Simulation / Data
  triggerManualSync: () => void;
  exportDataJSON: () => string;
  importDataJSON: (jsonString: string) => boolean;
  resetAllData: () => void;

  // Global Modals / Helpers
  isFocusMode: boolean;
  setFocusMode: (val: boolean) => void;
  isQuickActionOpen: boolean;
  setQuickActionOpen: (val: boolean) => void;
  isSearchOpen: boolean;
  setSearchOpen: (val: boolean) => void;
}

const StudiumContext = createContext<StudiumContextType | null>(null);

const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  accent: 'mint',
  soundEnabled: true,
  masterVolume: 0.7,
  autoStartBreak: true,
  autoStartFocus: false,
  autoPlayMusic: false,
  longBreakInterval: 4,
  defaultPomodoroFocus: 25,
  defaultPomodoroShortBreak: 5,
  defaultPomodoroLongBreak: 15,
  defaultTimerPreset: 25,
  streakRequirementMinutes: 20,
  quietHoursEnabled: true,
  quietHoursStart: '22:00',
  quietHoursEnd: '07:00',
  reducedMotion: false,
  highContrast: false,
  fontSize: 'md',
  dashboardLayout: 'standard',
  enabledWidgets: {
    todayFocus: true,
    dailyGoal: true,
    studyStats: true,
    weeklyLeague: true,
    streak: true,
    heatmap: true,
    subjects: true,
    recentSessions: true,
    tasks: true,
    upcomingExam: true,
    achievements: true,
    recentNotes: true,
    studyChallenge: true,
  },
};

const INITIAL_ACTIVE_TIMER: ActiveTimerState = {
  mode: 'countdown',
  status: 'idle',
  targetDuration: 25 * 60,
  elapsedSeconds: 0,
  subjectId: '',
  studyType: 'Problem Solving',
  difficulty: 'Medium',
  taskTitle: '',
  note: '',
  tags: [],
  pomodoro: {
    phase: 'focus',
    cycle: 1,
    totalCycles: 4,
    completedFocusCount: 0,
    interruptedCount: 0,
  },
  stopwatch: {
    laps: [],
  },
};

const isRegisteredProfile = (p: UserProfile): boolean =>
  p.accountType !== 'guest' && typeof p.id === 'string' && p.id.length > 0 && !p.id.startsWith('device:') && p.id !== 'guest-user';

export const StudiumProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  if (localStorage.getItem(storageKey('demoCleanupVersion')) !== DEMO_SEED_VERSION) cleanKnownDemoLocalData();
  // Load state from local storage or clean defaults
  const [sessions, setSessions] = useState<StudySession[]>(() => {
    const saved = localStorage.getItem(storageKey('sessions'));
    return saved ? JSON.parse(saved) : [];
  });

  const [subjects, setSubjects] = useState<Subject[]>(() => {
    const saved = localStorage.getItem(storageKey('subjects'));
    return saved ? JSON.parse(saved) : [];
  });

  const [chapters, setChapters] = useState<Chapter[]>(() => {
    const saved = localStorage.getItem(storageKey('chapters'));
    return saved ? JSON.parse(saved) : [];
  });

  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem(storageKey('tasks'));
    return saved ? JSON.parse(saved) : [];
  });

  const [notes, setNotes] = useState<Note[]>(() => {
    const saved = localStorage.getItem(storageKey('notes'));
    return saved ? JSON.parse(saved) : [];
  });

  const [exams, setExams] = useState<Exam[]>(() => {
    const saved = localStorage.getItem(storageKey('exams'));
    return saved ? JSON.parse(saved) : [];
  });

  const [studyBlocks, setStudyBlocks] = useState<StudyBlock[]>(() => {
    const saved = localStorage.getItem(storageKey('studyBlocks'));
    return saved ? JSON.parse(saved) : [];
  });

  const [achievements, setAchievements] = useState<Achievement[]>(() => {
    const saved = localStorage.getItem(storageKey('achievements'));
    return saved ? JSON.parse(saved).map((a: Achievement) => DEMO_ACHIEVEMENT_IDS.has(a.id) ? { ...a, unlocked: false, unlockedAt: undefined } : a) : INITIAL_ACHIEVEMENTS.map(a => ({ ...a, unlocked: false, unlockedAt: undefined }));
  });

  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem(storageKey('profile'));
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const isLegacyGuest = !parsed?.accountType || parsed.accountType === 'guest' || parsed?.id === 'guest-user';
        if (isLegacyGuest) {
          const guestProfile = { ...INITIAL_USER_PROFILE, ...parsed, id: DEVICE_ID, accountType: 'guest' as const, deviceId: DEVICE_ID };
          localStorage.setItem(storageKey('profile'), JSON.stringify(guestProfile));
          return guestProfile;
        }
        return parsed;
      } catch {}
    }
    return { ...INITIAL_USER_PROFILE, id: DEVICE_ID, accountType: 'guest', deviceId: DEVICE_ID };
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem(storageKey('settings'));
    return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem(storageKey('notifications'));
return saved ? JSON.parse(saved) : [];
  });

  const [dailyGoals, setDailyGoals] = useState<Record<string, DailyGoal>>(() => {
    const saved = localStorage.getItem(storageKey('dailyGoals'));
    const today = new Date().toISOString().slice(0, 10);
return saved ? JSON.parse(saved) : {};
  });

  const [activeTimer, setActiveTimer] = useState<ActiveTimerState>(() => {
    const saved = localStorage.getItem(storageKey('activeTimer'));
    return saved ? JSON.parse(saved) : INITIAL_ACTIVE_TIMER;
  });

  const [leaderboardUsers, setLeaderboardUsers] = useState<LeaderboardUser[]>([]);

  const [syncStatus, setSyncStatus] = useState<SyncStatus>({
    status: navigator.onLine ? 'Connected' : 'Offline',
    lastSyncedAt: 'Just now',
    pendingChangesCount: 0,
  });

  const [currentCompletion, setCurrentCompletion] = useState<SessionCompletionData | null>(null);
  const [ambientPlaying, setAmbientPlaying] = useState<string | null>(null);
  const [isFocusMode, setFocusMode] = useState(false);
  const [isQuickActionOpen, setQuickActionOpen] = useState(false);
  const [isSearchOpen, setSearchOpen] = useState(false);

  // Persistent Stopwatch & Daily Leaderboard States
  const [recoveredStopwatchSession, setRecoveredStopwatchSession] = useState<ActiveStopwatchServerSession | null>(null);
  const [conflictStopwatchSession, setConflictStopwatchSession] = useState<ActiveStopwatchServerSession | null>(null);
  const [pendingTimerSetup, setPendingTimerSetup] = useState<Partial<ActiveTimerState> | null>(null);
  const [dailyLeaderboard, setDailyLeaderboard] = useState<DailyLeaderboardData | null>(null);
  const [isDailyLeaderboardLoading, setIsDailyLeaderboardLoading] = useState(false);
  const [isOfflineMode, setIsOfflineMode] = useState(!navigator.onLine);

  // Fetch live daily leaderboard with 30s lightweight polling fallback
  const fetchDailyLeaderboard = useCallback(async () => {
    try {
      setIsDailyLeaderboardLoading(true);
      const userId = profile.id;
      if (!isRegisteredProfile(profile)) {
        setDailyLeaderboard(null);
        setLeaderboardUsers([]);
        return;
      }
      if (isRegisteredProfile(profile)) {
        await fetch('/api/platform/profile/sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: userId, username: profile.username, name: profile.name, avatar: profile.avatar, privacy: profile.privacy }),
        });
      }
      const leaderboardUrl = `/api/platform/leaderboard/daily?userId=${encodeURIComponent(userId)}`;
      const res = await fetch(leaderboardUrl);
      if (res.ok) {
        const data = await res.json();
        setDailyLeaderboard(data);
        setLeaderboardUsers((data.rankings || []).map((u: any) => ({ ...u, change: u.change || 0 })));
        try {
          const nr = await fetch(`/api/platform/leaderboard/notifications?userId=${encodeURIComponent(userId)}`);
          if (nr.ok) {
            const serverNotifications = await nr.json();
            if (Array.isArray(serverNotifications) && serverNotifications.length) {
              setNotifications(prev => {
                const existing = new Set(prev.map(n => n.id));
                const mapped = serverNotifications.filter((n: any) => !existing.has(n.id)).map((n: any) => ({ id: n.id, title: n.title, message: n.message, type: 'Leaderboard' as const, timestamp: n.createdAt, read: n.read }));
                return [...mapped, ...prev];
              });
            }
          }
        } catch { /* notification sync is non-blocking */ }
      }
    } catch (err) {
      console.warn('Daily leaderboard fetch error:', err);
    } finally {
      setIsDailyLeaderboardLoading(false);
    }
  }, [profile]);

  // Check unfinished active stopwatch on initial load / refresh
  useEffect(() => {
    const checkServerActiveStopwatch = async () => {
      try {
        const res = await fetch(`/api/stopwatch/active?userId=${encodeURIComponent(profile.id)}`);
        if (res.ok) {
          const data = await res.json();
          if (data.active && data.session) {
            const serverSession: ActiveStopwatchServerSession = data.session;
            setRecoveredStopwatchSession(serverSession);
          }
        }
      } catch (err) {
        console.warn('Could not query active stopwatch from server:', err);
      }
    };

    checkServerActiveStopwatch();
    fetchDailyLeaderboard();

    // 30-second lightweight polling fallback
    const pollInterval = setInterval(() => {
      fetchDailyLeaderboard();
    }, 30000);

    return () => clearInterval(pollInterval);
  }, [profile.id, fetchDailyLeaderboard]);

  // Sync to local storage on changes
  useEffect(() => {
    localStorage.setItem(storageKey('sessions'), JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem(storageKey('subjects'), JSON.stringify(subjects));
  }, [subjects]);

  useEffect(() => {
    localStorage.setItem(storageKey('chapters'), JSON.stringify(chapters));
  }, [chapters]);

  useEffect(() => {
    localStorage.setItem(storageKey('tasks'), JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem(storageKey('notes'), JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    localStorage.setItem(storageKey('exams'), JSON.stringify(exams));
  }, [exams]);

  useEffect(() => {
    localStorage.setItem(storageKey('studyBlocks'), JSON.stringify(studyBlocks));
  }, [studyBlocks]);

  useEffect(() => {
    localStorage.setItem(storageKey('achievements'), JSON.stringify(achievements));
  }, [achievements]);

  useEffect(() => {
    localStorage.setItem(storageKey('profile'), JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem(storageKey('settings'), JSON.stringify(settings));
    // Apply theme and accent to document root
    document.documentElement.setAttribute('data-theme', settings.theme);
    document.documentElement.setAttribute('data-accent', settings.accent);
    if (settings.theme === 'light') {
      document.body.classList.remove('bg-neutral-950', 'text-neutral-100');
      document.body.classList.add('bg-slate-50', 'text-slate-900');
    } else {
      document.body.classList.remove('bg-slate-50', 'text-slate-900');
      document.body.classList.add('bg-neutral-950', 'text-neutral-100');
    }
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(storageKey('notifications'), JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(storageKey('dailyGoals'), JSON.stringify(dailyGoals));
  }, [dailyGoals]);

  useEffect(() => {
    localStorage.setItem(storageKey('activeTimer'), JSON.stringify(activeTimer));
  }, [activeTimer]);

  // Online / Offline listener & offline recovery reconciliation
  useEffect(() => {
    const handleOnline = async () => {
      setIsOfflineMode(false);
      setSyncStatus(prev => ({ ...prev, status: 'Connected', lastSyncedAt: 'Just now' }));

      // Reconcile local active session with backend if stopwatch is running
      if (activeTimer.mode === 'stopwatch' && activeTimer.status !== 'idle') {
        try {
          await fetch('/api/stopwatch/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              userId: profile.id,
              session: {
                sessionId: activeTimer.sessionId,
                startTime: activeTimer.startTime,
                accumulatedSeconds: activeTimer.elapsedSeconds,
                status: activeTimer.status,
                subjectId: activeTimer.subjectId,
                chapterId: activeTimer.chapterId,
                sessionType: activeTimer.studyType,
                laps: activeTimer.stopwatch.laps,
              },
            }),
          });
        } catch (err) {
          console.warn('Failed to sync offline stopwatch to backend:', err);
        }
      }

      fetchDailyLeaderboard();
    };

    const handleOffline = () => {
      setIsOfflineMode(true);
      setSyncStatus(prev => ({ ...prev, status: 'Offline' }));
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [activeTimer, profile.id, fetchDailyLeaderboard]);

  // Keyboard shortcut Ctrl+K / Cmd+K for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchOpen(prev => !prev);
      }
      if (e.key === 'Escape') {
        setSearchOpen(false);
        setQuickActionOpen(false);
        if (isFocusMode) setFocusMode(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFocusMode]);

  // Wall-clock precision timer loop
  // Recovers after tab switch, laptop sleep, refresh without drift
  useEffect(() => {
    if (activeTimer.status !== 'running') return;

    const interval = setInterval(() => {
      setActiveTimer((prev) => {
        if (prev.status !== 'running') return prev;

        const now = Date.now();
        const lastTick = prev.lastTickTime || now;
        const deltaSeconds = Math.max(1, Math.round((now - lastTick) / 1000));
        const newElapsed = prev.elapsedSeconds + deltaSeconds;

        // Warning sound on countdown when 3 seconds remain
        if (prev.mode !== 'countup' && prev.mode !== 'stopwatch') {
          const remaining = prev.targetDuration - newElapsed;
          if (remaining > 0 && remaining <= 3 && settings.soundEnabled) {
            soundFx.playWarningTick(settings.masterVolume);
          }
        }

        // Check if countdown target reached
        if (prev.mode !== 'countup' && prev.mode !== 'stopwatch' && newElapsed >= prev.targetDuration) {
          // Play finish chime
          if (settings.soundEnabled) {
            soundFx.playFinishChime(settings.masterVolume);
          }

          // Auto-handle Pomodoro phase transitions or finish
          if (prev.mode === 'pomodoro') {
            const isFocus = prev.pomodoro.phase === 'focus';
            if (isFocus) {
              const newCompletedCount = prev.pomodoro.completedFocusCount + 1;
              const isLongBreak = newCompletedCount % settings.longBreakInterval === 0;
              const nextPhase = isLongBreak ? 'longBreak' : 'shortBreak';
              const nextTarget = isLongBreak
                ? settings.defaultPomodoroLongBreak * 60
                : settings.defaultPomodoroShortBreak * 60;

              return {
                ...prev,
                targetDuration: nextTarget,
                elapsedSeconds: 0,
                lastTickTime: now,
                status: settings.autoStartBreak ? 'running' : 'paused',
                pomodoro: {
                  ...prev.pomodoro,
                  phase: nextPhase,
                  completedFocusCount: newCompletedCount,
                },
              };
            } else {
              // Break finished -> back to focus
              return {
                ...prev,
                targetDuration: settings.defaultPomodoroFocus * 60,
                elapsedSeconds: 0,
                lastTickTime: now,
                status: settings.autoStartFocus ? 'running' : 'paused',
                pomodoro: {
                  ...prev.pomodoro,
                  phase: 'focus',
                  cycle: prev.pomodoro.cycle + 1,
                },
              };
            }
          }

          // Standard countdown finished
          return {
            ...prev,
            elapsedSeconds: prev.targetDuration,
            status: 'paused',
            lastTickTime: now,
          };
        }

        return {
          ...prev,
          elapsedSeconds: newElapsed,
          lastTickTime: now,
        };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [activeTimer.status, settings]);

  // Derived Streaks (Source of truth: sessions)
  const streakData = useMemo<StreakData>(() => {
    const reqMinutes = settings.streakRequirementMinutes || 20;
    // Group minutes by date
    const dateMinutesMap: Record<string, number> = {};
    sessions.forEach((s) => {
      dateMinutesMap[s.dateString] = (dateMinutesMap[s.dateString] || 0) + s.duration / 60;
    });

    const dates = Object.keys(dateMinutesMap).sort();
    if (dates.length === 0) {
      return {
        currentStreak: 0,
        longestStreak: 0,
        lastStudyDate: '',
        streakRequirementMinutes: reqMinutes,
        streakFreezesLeft: 0,
        graceDayActive: false,
        streakHistory: [],
      };
    }

    const todayStr = new Date().toISOString().slice(0, 10);
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().slice(0, 10);

    let currentStreak = 0;
    let longestStreak = 0;
    let runningStreak = 0;

    // Check backwards from today/yesterday for current streak
    let checkDate = new Date();
    // if today has met req:
    const todayMinutes = dateMinutesMap[todayStr] || 0;
    if (todayMinutes < reqMinutes) {
      // see if streak is still active from yesterday
      checkDate = yesterday;
    }

    while (true) {
      const dStr = checkDate.toISOString().slice(0, 10);
      const mins = dateMinutesMap[dStr] || 0;
      if (mins >= reqMinutes) {
        currentStreak++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        break;
      }
    }

    // Calculate longest streak historically
    let prevD: Date | null = null;
    dates.forEach((dStr) => {
      const mins = dateMinutesMap[dStr];
      const curD = new Date(dStr);
      if (mins >= reqMinutes) {
        if (!prevD) {
          runningStreak = 1;
        } else {
          const diffDays = Math.round((curD.getTime() - prevD.getTime()) / (1000 * 60 * 60 * 24));
          if (diffDays === 1) {
            runningStreak++;
          } else {
            runningStreak = 1;
          }
        }
        if (runningStreak > longestStreak) longestStreak = runningStreak;
        prevD = curD;
      }
    });

    const streakHistory = dates.map(d => ({
      date: d,
      minutes: Math.round(dateMinutesMap[d]),
      achieved: (dateMinutesMap[d] || 0) >= reqMinutes,
    }));

    return {
      currentStreak,
      longestStreak,
      lastStudyDate: dates[dates.length - 1],
      streakRequirementMinutes: reqMinutes,
      streakFreezesLeft: 0,
      graceDayActive: false,
      streakHistory,
    };
  }, [sessions, settings.streakRequirementMinutes]);

  // Finish Timer Session -> Source of truth update
  const finishTimerSession = useCallback((interrupted = false) => {
    const elapsed = Math.max(activeTimer.elapsedSeconds, 15); // min 15s to record
    const now = new Date();
    const startTime = new Date(now.getTime() - elapsed * 1000);
    const todayStr = now.toISOString().slice(0, 10);

    const newSession: StudySession = {
      id: `sess-${Date.now()}`,
      startTime: startTime.toISOString(),
      endTime: now.toISOString(),
      duration: elapsed,
      subjectId: activeTimer.subjectId,
      chapterId: activeTimer.chapterId,
      studyType: activeTimer.studyType,
      difficulty: activeTimer.difficulty,
      taskTitle: activeTimer.taskTitle || undefined,
      note: activeTimer.note || undefined,
      tags: activeTimer.tags.length > 0 ? activeTimer.tags : ['#study'],
      timerMode: activeTimer.mode,
      completedNormally: !interrupted,
      interrupted,
      dateString: todayStr,
      deviceId: DEVICE_ID,
    };

    // Calculate XP: 10 XP per minute studied + bonuses
    const studyMinutes = Math.max(1, Math.round(elapsed / 60));
    let earnedXP = studyMinutes * 10;
    if (!interrupted) earnedXP += 25; // Focus completion bonus

    // Update Daily Goals
    const currentGoal = dailyGoals[todayStr] || {
      dateString: todayStr,
      targetMinutes: profile.dailyGoalMinutes,
      targetPomodoros: 4,
      targetSessions: 3,
      targetChapters: 1,
      targetTasks: 2,
      tasks: [],
    };

    const isGoalJustCompleted = currentGoal.targetMinutes > 0 && studyMinutes >= currentGoal.targetMinutes;
    if (isGoalJustCompleted) {
      earnedXP += 50; // Goal complete bonus
    }

    // Update XP and Level
    const newTotalXP = profile.xp + earnedXP;
    const newLevel = Math.floor(Math.sqrt(newTotalXP / 100)) + 1;
    const didLevelUp = newLevel > profile.level;

    setProfile(prev => ({
      ...prev,
      xp: newTotalXP,
      level: newLevel,
    }));

    // Update session list (Source of Truth)
    setSessions(prev => [newSession, ...prev]);

    // Check achievement progress
    const unlockedNow: Achievement[] = [];
    setAchievements((prevAchs) => {
      return prevAchs.map((ach) => {
        if (ach.unlocked) return ach;
        let isNowUnlocked = false;

        const totalHours = (sessions.reduce((acc, s) => acc + s.duration, elapsed)) / 3600;
        const totalPomos = sessions.filter(s => s.timerMode === 'pomodoro').length + (activeTimer.mode === 'pomodoro' ? 1 : 0);

        if (ach.category === 'TIME' && totalHours >= ach.targetValue) isNowUnlocked = true;
        if (ach.category === 'POMODORO' && totalPomos >= ach.targetValue) isNowUnlocked = true;
        if (ach.category === 'STREAK' && streakData.currentStreak >= ach.targetValue) isNowUnlocked = true;
        if (ach.id === 'ach-23' && elapsed >= 5400 && !interrupted) isNowUnlocked = true; // 90 min deep work

        if (isNowUnlocked) {
          const unlockedAch = { ...ach, unlocked: true, unlockedAt: now.toISOString() };
          unlockedNow.push(unlockedAch);
          return unlockedAch;
        }
        return ach;
      });
    });

    // Update Leaderboard position for current user
    setLeaderboardUsers((prev) => {
      return prev.map((u) => {
        if (u.isCurrentUser || u.userId === profile.id) {
          const newMinutes = u.studyMinutes + studyMinutes;
          const newXp = u.xp + earnedXP;
          return {
            ...u,
            studyMinutes: newMinutes,
            xp: newXp,
          };
        }
        return u;
      }).sort((a, b) => b.studyMinutes - a.studyMinutes).map((u, idx) => ({ ...u, rank: idx + 1 }));
    });

    // Sound FX & Confetti
    if (settings.soundEnabled) {
      if (unlockedNow.length > 0) {
        soundFx.playAchievementFanfare(settings.masterVolume);
      } else {
        soundFx.playFinishChime(settings.masterVolume);
      }
    }

    try {
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10b981', '#38bdf8', '#a855f7', '#f59e0b'],
      });
    } catch {
      // Ignore if canvas error
    }

    // Set Completion Modal Data
    setCurrentCompletion({
      session: newSession,
      earnedXP,
      newLevel: didLevelUp ? newLevel : undefined,
      isGoalCompleted: isGoalJustCompleted,
      newStreak: streakData.currentStreak,
      rankImpact: 'Leaderboard updates after validation',
      unlockedAchievements: unlockedNow,
    });

    // Reset active timer to initial idle
    setActiveTimer({
      ...INITIAL_ACTIVE_TIMER,
      subjectId: activeTimer.subjectId,
      studyType: activeTimer.studyType,
      targetDuration: activeTimer.targetDuration,
    });

    // Add in-app notification
    const subjName = subjects.find(s => s.id === activeTimer.subjectId)?.name || 'Study';
    setNotifications(prev => [
      {
        id: `notif-${Date.now()}`,
        title: `Session Logged: ${studyMinutes}m ${subjName}`,
        message: `Earned +${earnedXP} XP. Streak maintained at ${streakData.currentStreak} days!`,
        type: 'Study',
        timestamp: now.toISOString(),
        read: false,
      },
      ...prev,
    ]);

    // Send completed session to server for daily leaderboard aggregation & persistent storage
    if (isRegisteredProfile(profile)) {
      fetch('/api/platform/sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session: { ...newSession, userId: profile.id, sessionType: newSession.studyType } }),
      })
        .then(() => fetchDailyLeaderboard())
        .catch(console.warn);
    }

    // If stopwatch was running on backend, finalize it there too
    if (activeTimer.mode === 'stopwatch' && isRegisteredProfile(profile)) {
      fetch('/api/stopwatch/finish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: profile.id,
          interrupted,
        }),
      }).catch(console.warn);
    }
  }, [activeTimer, dailyGoals, fetchDailyLeaderboard, profile, sessions, settings, streakData.currentStreak, subjects]);

  const clearCompletionModal = () => setCurrentCompletion(null);

  // Recovery Modal Handlers
  const resumeRecoveredStopwatch = useCallback(() => {
    if (!recoveredStopwatchSession) return;
    const sess = recoveredStopwatchSession;
    const now = Date.now();
    setActiveTimer({
      mode: 'stopwatch',
      status: 'running',
      startTime: sess.startTime,
      lastTickTime: now,
      targetDuration: 0,
      elapsedSeconds: sess.elapsedSeconds || sess.accumulatedSeconds || 0,
      subjectId: sess.subjectId,
      chapterId: sess.chapterId,
      studyType: (sess.sessionType as StudyType) || 'Practice',
      difficulty: 'Medium',
      taskTitle: sess.taskTitle || '',
      note: sess.note || '',
      tags: sess.tags || ['#study', '#stopwatch'],
      sessionId: sess.sessionId,
      pomodoro: INITIAL_ACTIVE_TIMER.pomodoro,
      stopwatch: {
        laps: sess.laps || [],
      },
    });

    fetch('/api/stopwatch/resume', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: profile.id }),
    }).catch(console.warn);

    setRecoveredStopwatchSession(null);
  }, [recoveredStopwatchSession, profile.id]);

  const finishRecoveredStopwatch = useCallback(async () => {
    if (!recoveredStopwatchSession) return;
    const sess = recoveredStopwatchSession;
    try {
      const res = await fetch('/api/stopwatch/finish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: profile.id,
          interrupted: false,
        }),
      });

      const duration = sess.elapsedSeconds || sess.accumulatedSeconds || 60;
      const completed: StudySession = {
        id: sess.sessionId,
        startTime: new Date(sess.startTime).toISOString(),
        endTime: new Date().toISOString(),
        duration,
        subjectId: sess.subjectId,
        chapterId: sess.chapterId,
        studyType: (sess.sessionType as StudyType) || 'Practice',
        difficulty: 'Medium',
        taskTitle: sess.taskTitle,
        note: sess.note,
        tags: sess.tags || ['#study', '#stopwatch'],
        timerMode: 'stopwatch',
        completedNormally: true,
        interrupted: false,
        dateString: new Date().toISOString().slice(0, 10),
        deviceId: DEVICE_ID,
      };

      setSessions(prev => [completed, ...prev]);
      fetchDailyLeaderboard();
    } catch (err) {
      console.warn('Failed to finish recovered session:', err);
    }
    setRecoveredStopwatchSession(null);
  }, [recoveredStopwatchSession, profile.id, fetchDailyLeaderboard]);

  const cancelRecoveredStopwatch = useCallback(() => {
    fetch('/api/stopwatch/cancel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: profile.id }),
    }).catch(console.warn);
    setRecoveredStopwatchSession(null);
  }, [profile.id]);

  const dismissRecoveryModal = useCallback(() => {
    setRecoveredStopwatchSession(null);
  }, []);

  // Multiple Active Session Conflict Handlers
  const resolveConflictWithResume = useCallback(() => {
    setConflictStopwatchSession(null);
    setPendingTimerSetup(null);
    if (activeTimer.status === 'paused') {
      resumeTimer();
    }
  }, [activeTimer.status]);

  const resolveConflictWithDiscard = useCallback((newSetup?: Partial<ActiveTimerState>) => {
    const targetSetup = newSetup || pendingTimerSetup || {};
    // Cancel running stopwatch on server
    fetch('/api/stopwatch/cancel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: profile.id }),
    }).catch(console.warn);

    setConflictStopwatchSession(null);
    setPendingTimerSetup(null);

    // Force start new timer
    startTimer(targetSetup, true);
  }, [pendingTimerSetup, profile.id]);

  const dismissConflictModal = useCallback(() => {
    setConflictStopwatchSession(null);
    setPendingTimerSetup(null);
  }, []);

  // Timer Controls
  const startTimer = useCallback((setup?: Partial<ActiveTimerState>, force = false) => {
    const mode = setup?.mode || activeTimer.mode;
    const now = Date.now();

    // 46.5 Protection: Check if a session is already active (running or paused)
    if ((activeTimer.status === 'running' || activeTimer.status === 'paused') && !force) {
      setConflictStopwatchSession({
        userId: profile.id,
        sessionId: activeTimer.sessionId || `sess-${activeTimer.startTime || now}`,
        startTime: activeTimer.startTime || now,
        lastResumeTime: activeTimer.lastTickTime || now,
        status: activeTimer.status,
        subjectId: activeTimer.subjectId,
        chapterId: activeTimer.chapterId,
        sessionType: activeTimer.studyType,
        taskTitle: activeTimer.taskTitle,
        note: activeTimer.note,
        tags: activeTimer.tags,
        accumulatedSeconds: activeTimer.elapsedSeconds,
        createdAt: new Date(activeTimer.startTime || now).toISOString(),
        lastUpdatedAt: new Date(now).toISOString(),
        laps: activeTimer.stopwatch.laps,
        elapsedSeconds: activeTimer.elapsedSeconds,
      });
      setPendingTimerSetup(setup || null);
      return;
    }

    if (mode === 'stopwatch') {
      const subjId = setup?.subjectId || activeTimer.subjectId || subjects[0]?.id || '';
      if (!subjId) return;
      if (!isRegisteredProfile(profile)) {
        setActiveTimer(prev => ({ ...prev, ...setup, mode: 'stopwatch', status: 'running', startTime: now, lastTickTime: now, subjectId: subjId }));
        return;
      }
      fetch('/api/stopwatch/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: profile.id,
          subjectId: subjId,
          chapterId: setup?.chapterId || activeTimer.chapterId,
          sessionType: setup?.studyType || activeTimer.studyType,
          taskTitle: setup?.taskTitle || activeTimer.taskTitle,
          note: setup?.note || activeTimer.note,
          tags: setup?.tags || activeTimer.tags,
          force,
        }),
      })
        .then(async (res) => {
          if (res.status === 409) {
            const data = await res.json();
            setConflictStopwatchSession(data.existingSession);
            setPendingTimerSetup(setup || null);
            return;
          }
          if (res.ok) {
            const data = await res.json();
            setActiveTimer(prev => ({
              ...prev,
              ...setup,
              mode: 'stopwatch',
              status: 'running',
              startTime: data.session?.startTime || now,
              lastTickTime: now,
              elapsedSeconds: data.session?.elapsedSeconds || 0,
              sessionId: data.session?.sessionId,
              subjectId: subjId,
            }));
          }
        })
        .catch((err) => {
          console.warn('Network error starting server stopwatch, continuing locally offline:', err);
          setActiveTimer(prev => ({
            ...prev,
            ...setup,
            mode: 'stopwatch',
            status: 'running',
            startTime: now,
            lastTickTime: now,
            sessionId: `offline-${now}`,
          }));
        });
    } else {
      setActiveTimer(prev => ({
        ...prev,
        ...setup,
        status: 'running',
        startTime: now,
        lastTickTime: now,
      }));
    }

    if (settings.soundEnabled) {
      soundFx.playStartChime(settings.masterVolume);
    }
    if (settings.autoPlayMusic && !ambientPlaying) {
      soundFx.startAmbient('whitenoise', settings.masterVolume * 0.4);
      setAmbientPlaying('whitenoise');
    }
  }, [activeTimer, ambientPlaying, profile.id, settings, subjects]);

  const pauseTimer = useCallback(() => {
    setActiveTimer(prev => ({
      ...prev,
      status: 'paused',
      lastTickTime: Date.now(),
    }));

    if (activeTimer.mode === 'stopwatch') {
      fetch('/api/stopwatch/pause', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: profile.id }),
      }).catch(console.warn);
    }
  }, [activeTimer.mode, profile.id]);

  const resumeTimer = useCallback(() => {
    setActiveTimer(prev => ({
      ...prev,
      status: 'running',
      lastTickTime: Date.now(),
    }));

    if (activeTimer.mode === 'stopwatch') {
      fetch('/api/stopwatch/resume', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: profile.id }),
      }).catch(console.warn);
    }
  }, [activeTimer.mode, profile.id]);

  const resetTimer = useCallback(() => {
    setActiveTimer(prev => ({
      ...prev,
      status: 'idle',
      elapsedSeconds: 0,
      lastTickTime: Date.now(),
    }));

    if (activeTimer.mode === 'stopwatch') {
      fetch('/api/stopwatch/cancel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: profile.id }),
      }).catch(console.warn);
    }
  }, [activeTimer.mode, profile.id]);

  const cancelTimerSession = useCallback(() => {
    setActiveTimer(prev => ({
      ...prev,
      status: 'idle',
      elapsedSeconds: 0,
      lastTickTime: Date.now(),
    }));

    if (activeTimer.mode === 'stopwatch') {
      fetch('/api/stopwatch/cancel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: profile.id }),
      }).catch(console.warn);
    }
  }, [activeTimer.mode, profile.id]);

  const adjustTimerTime = useCallback((deltaSeconds: number) => {
    setActiveTimer(prev => ({
      ...prev,
      targetDuration: Math.max(60, prev.targetDuration + deltaSeconds),
    }));
  }, []);

  const skipPomodoroPhase = useCallback(() => {
    setActiveTimer(prev => {
      const isFocus = prev.pomodoro.phase === 'focus';
      const nextPhase = isFocus ? 'shortBreak' : 'focus';
      const nextTarget = isFocus
        ? settings.defaultPomodoroShortBreak * 60
        : settings.defaultPomodoroFocus * 60;
      return {
        ...prev,
        elapsedSeconds: 0,
        targetDuration: nextTarget,
        pomodoro: {
          ...prev.pomodoro,
          phase: nextPhase,
          cycle: isFocus ? prev.pomodoro.cycle : prev.pomodoro.cycle + 1,
        },
      };
    });
  }, [settings]);

  const addStopwatchLap = useCallback(() => {
    setActiveTimer(prev => {
      const totalTime = prev.elapsedSeconds;
      const prevLaps = prev.stopwatch.laps;
      const prevLapTotal = prevLaps.length > 0 ? prevLaps[prevLaps.length - 1].totalTime : 0;
      const lapTime = totalTime - prevLapTotal;
      const newLap = {
        lapNumber: prevLaps.length + 1,
        lapTime,
        totalTime,
      };

      if (prev.mode === 'stopwatch') {
        fetch('/api/stopwatch/lap', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: profile.id,
            lapTime,
            totalTime,
          }),
        }).catch(console.warn);
      }

      return {
        ...prev,
        stopwatch: {
          ...prev.stopwatch,
          laps: [...prevLaps, newLap],
        },
      };
    });
  }, [profile.id]);

  const quickStart = useCallback((minutes: number, mode: TimerMode = 'countdown') => {
    setActiveTimer(prev => ({
      ...prev,
      mode,
      targetDuration: minutes * 60,
      elapsedSeconds: 0,
      status: 'running',
      startTime: Date.now(),
      lastTickTime: Date.now(),
    }));
    if (settings.soundEnabled) soundFx.playStartChime(settings.masterVolume);
    setQuickActionOpen(false);
  }, [settings]);

  // Subjects CRUD
  const addSubject = (subj: Omit<Subject, 'id' | 'createdAt' | 'order'>) => {
    const newSubject: Subject = {
      ...subj,
      userId: profile.id,
      id: `subj-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      createdAt: new Date().toISOString(),
      order: subjects.length,
    };
    setSubjects(prev => [...prev, newSubject]);
  };

  const updateSubject = (id: string, updates: Partial<Subject>) => {
    setSubjects(prev => prev.map(s => s.id === id && (!s.userId || s.userId === profile.id) ? { ...s, ...updates } : s));
  };

  const deleteSubject = (id: string) => {
    setSubjects(prev => prev.filter(s => s.id !== id || (s.userId && s.userId !== profile.id)));
    setChapters(prev => prev.filter(c => c.subjectId !== id || (c.userId && c.userId !== profile.id)));
  };

  const reorderSubjects = (ids: string[]) => {
    setSubjects(prev => {
      const map = new Map(prev.map(s => [s.id, s]));
      return ids.map((id, idx) => ({ ...map.get(id)!, order: idx }));
    });
  };

  // Chapter CRUD
  const addChapter = (chap: Omit<Chapter, 'id'>) => {
    const newChapter: Chapter = {
      ...chap,
      userId: profile.id,
      id: `chap-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    };
    setChapters(prev => [...prev, newChapter]);
  };

  const updateChapter = (id: string, updates: Partial<Chapter>) => {
    setChapters(prev => prev.map(c => c.id === id && (!c.userId || c.userId === profile.id) ? { ...c, ...updates } : c));
  };

  const markChapterCompleted = (chapterId: string, completed = true) => {
    setChapters(prev => prev.map(c => {
      if (c.id !== chapterId || (c.userId && c.userId !== profile.id)) return c;
      const now = new Date().toISOString();
      return { ...c, status: completed ? 'Completed' : 'In Progress', customProgress: completed ? 100 : Math.min(99, c.customProgress), completionDate: completed ? (c.completionDate || now) : undefined };
    }));
  };

  const deleteChapter = (id: string) => {
    setChapters(prev => prev.filter(c => c.id !== id));
  };

  const toggleChecklistItem = (chapterId: string, itemId: string) => {
    setChapters(prev => prev.map(chap => {
      if (chap.id !== chapterId) return chap;
      const updatedList = chap.checklist.map(item =>
        item.id === itemId ? { ...item, completed: !item.completed } : item
      );
      const completedCount = updatedList.filter(i => i.completed).length;
      const newProgress = updatedList.length > 0 ? Math.round((completedCount / updatedList.length) * 100) : 0;
      const newStatus = newProgress === 100 ? 'Completed' : (newProgress > 0 ? 'In Progress' : 'Not Started');

      return {
        ...chap,
        checklist: updatedList,
        customProgress: newProgress,
        status: newStatus,
        completionDate: newProgress === 100 ? new Date().toISOString() : chap.completionDate,
      };
    }));
  };

  const addChecklistItem = (chapterId: string, title: string) => {
    setChapters(prev => prev.map(chap => {
      if (chap.id !== chapterId) return chap;
      const newItem = { id: `chk-${Date.now()}`, title, completed: false };
      const updatedList = [...chap.checklist, newItem];
      return { ...chap, checklist: updatedList };
    }));
  };

  const removeChecklistItem = (chapterId: string, itemId: string) => {
    setChapters(prev => prev.map(chap => {
      if (chap.id !== chapterId) return chap;
      const updatedList = chap.checklist.filter(i => i.id !== itemId);
      return { ...chap, checklist: updatedList };
    }));
  };

  const markChapterRevisionCompleted = (chapterId: string) => {
    setChapters(prev => prev.map(chap => {
      if (chap.id !== chapterId) return chap;
      const now = new Date();
      const nextRev = new Date(now);
      // Spaced repetition schedule based on count: 1d, 3d, 7d, 14d, 30d
      const intervals = [1, 3, 7, 14, 30];
      const daysToAdd = intervals[Math.min(chap.revisionCount, intervals.length - 1)];
      nextRev.setDate(now.getDate() + daysToAdd);

      return {
        ...chap,
        revisionCount: chap.revisionCount + 1,
        lastRevisionDate: now.toISOString().slice(0, 10),
        nextRevisionDate: nextRev.toISOString().slice(0, 10),
        revisionRequired: false,
      };
    }));

    if (settings.soundEnabled) soundFx.playAchievementFanfare(settings.masterVolume * 0.5);
  };

  // Task CRUD
  const addTask = (task: Omit<Task, 'id'>) => {
    const newTask: Task = {
      ...task,
      id: `task-${Date.now()}`,
    };
    setTasks(prev => [newTask, ...prev]);
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  const toggleTaskCompletion = (id: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id !== id) return t;
      const nextCompleted = !t.completed;
      return {
        ...t,
        completed: nextCompleted,
        completedAt: nextCompleted ? new Date().toISOString() : undefined,
      };
    }));
  };

  const startTimerFromTask = (task: Task) => {
    setActiveTimer(prev => ({
      ...prev,
      taskTitle: task.title,
      subjectId: task.subjectId || prev.subjectId,
      chapterId: task.chapterId,
      targetDuration: (task.estimatedMinutes || 25) * 60,
      elapsedSeconds: 0,
      status: 'running',
      startTime: Date.now(),
      lastTickTime: Date.now(),
    }));
    if (settings.soundEnabled) soundFx.playStartChime(settings.masterVolume);
  };

  // Notes CRUD
  const addNote = (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>) => {
    const now = new Date().toISOString();
    const newNote: Note = {
      ...note,
      id: `note-${Date.now()}`,
      createdAt: now,
      updatedAt: now,
    };
    setNotes(prev => [newNote, ...prev]);
  };

  const updateNote = (id: string, updates: Partial<Note>) => {
    setNotes(prev => prev.map(n => n.id === id ? { ...n, ...updates, updatedAt: new Date().toISOString() } : n));
  };

  const deleteNote = (id: string) => {
    setNotes(prev => prev.filter(n => n.id !== id));
  };

  const duplicateNote = (id: string) => {
    const existing = notes.find(n => n.id === id);
    if (!existing) return;
    const now = new Date().toISOString();
    const copy: Note = {
      ...existing,
      id: `note-${Date.now()}`,
      title: `${existing.title} (Copy)`,
      createdAt: now,
      updatedAt: now,
    };
    setNotes(prev => [copy, ...prev]);
  };

  // Exams CRUD
  const addExam = (exam: Omit<Exam, 'id'>) => {
    const newExam: Exam = { ...exam, id: `exam-${Date.now()}` };
    setExams(prev => [...prev, newExam]);
  };

  const updateExam = (id: string, updates: Partial<Exam>) => {
    setExams(prev => prev.map(e => e.id === id ? { ...e, ...updates } : e));
  };

  const deleteExam = (id: string) => {
    setExams(prev => prev.filter(e => e.id !== id));
  };

  // Study Blocks CRUD
  const addStudyBlock = (block: Omit<StudyBlock, 'id'>) => {
    const newBlock: StudyBlock = { ...block, id: `blk-${Date.now()}` };
    setStudyBlocks(prev => [...prev, newBlock]);
  };

  const updateStudyBlock = (id: string, updates: Partial<StudyBlock>) => {
    setStudyBlocks(prev => prev.map(b => b.id === id ? { ...b, ...updates } : b));
  };

  const deleteStudyBlock = (id: string) => {
    setStudyBlocks(prev => prev.filter(b => b.id !== id));
  };

  // Daily Goals Management
  const updateDailyGoalTarget = (minutes: number) => {
    const today = new Date().toISOString().slice(0, 10);
    setDailyGoals(prev => {
      const cur = prev[today] || {
        dateString: today,
        targetMinutes: minutes,
        targetPomodoros: 4,
        targetSessions: 3,
        targetChapters: 1,
        targetTasks: 2,
        tasks: [],
      };
      return {
        ...prev,
        [today]: { ...cur, targetMinutes: minutes },
      };
    });
  };

  const addGoalTask = (title: string) => {
    const today = new Date().toISOString().slice(0, 10);
    setDailyGoals(prev => {
      const cur = prev[today] || {
        dateString: today,
        targetMinutes: profile.dailyGoalMinutes,
        targetPomodoros: 4,
        targetSessions: 3,
        targetChapters: 1,
        targetTasks: 2,
        tasks: [],
      };
      return {
        ...prev,
        [today]: {
          ...cur,
          tasks: [...cur.tasks, { id: `gt-${Date.now()}`, title, completed: false }],
        },
      };
    });
  };

  const toggleGoalTask = (id: string) => {
    const today = new Date().toISOString().slice(0, 10);
    setDailyGoals(prev => {
      const cur = prev[today];
      if (!cur) return prev;
      return {
        ...prev,
        [today]: {
          ...cur,
          tasks: cur.tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t),
        },
      };
    });
  };

  const deleteGoalTask = (id: string) => {
    const today = new Date().toISOString().slice(0, 10);
    setDailyGoals(prev => {
      const cur = prev[today];
      if (!cur) return prev;
      return {
        ...prev,
        [today]: {
          ...cur,
          tasks: cur.tasks.filter(t => t.id !== id),
        },
      };
    });
  };

  const useStreakFreeze = () => {
    // Decrement freeze
  };

  // Achievements
  const togglePinAchievement = (id: string) => {
    setProfile(prev => {
      const isPinned = prev.pinnedAchievementIds.includes(id);
      let updated: string[];
      if (isPinned) {
        updated = prev.pinnedAchievementIds.filter(i => i !== id);
      } else {
        if (prev.pinnedAchievementIds.length >= 3) {
          updated = [...prev.pinnedAchievementIds.slice(1), id];
        } else {
          updated = [...prev.pinnedAchievementIds, id];
        }
      }
      return { ...prev, pinnedAchievementIds: updated };
    });
  };

  // Profile & Settings
  const updateProfile = (updates: Partial<UserProfile>) => {
    setProfile(prev => ({ ...prev, ...updates }));
  };

  const updateSettings = (updates: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...updates }));
  };

  const toggleWidget = (widgetKey: string) => {
    setSettings(prev => ({
      ...prev,
      enabledWidgets: {
        ...prev.enabledWidgets,
        [widgetKey]: !prev.enabledWidgets[widgetKey],
      },
    }));
  };

  // Notifications
  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const clearNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  // Session History Management
  const deleteSession = (id: string) => {
    setSessions(prev => prev.filter(s => s.id !== id));
  };

  // Ambient sound
  const toggleAmbientSound = (type: 'rain' | 'whitenoise' | 'binaural' | 'drone') => {
    if (ambientPlaying === type) {
      soundFx.stopAmbient();
      setAmbientPlaying(null);
    } else {
      soundFx.startAmbient(type, settings.masterVolume * 0.4);
      setAmbientPlaying(type);
    }
  };

  const setAmbientVolume = (vol: number) => {
    soundFx.setAmbientVolume(vol);
  };

  // Cloud Sync Simulation
  const triggerManualSync = () => {
    setSyncStatus(prev => ({ ...prev, status: 'Syncing' }));
    setTimeout(() => {
      setSyncStatus({
        status: navigator.onLine ? 'Connected' : 'Offline',
        lastSyncedAt: 'Just now',
        pendingChangesCount: 0,
      });
    }, 1000);
  };

  // Export / Import
  const exportDataJSON = () => {
    const data = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      sessions,
      subjects,
      chapters,
      tasks,
      notes,
      exams,
      studyBlocks,
      achievements,
      profile,
      settings,
      dailyGoals,
    };
    return JSON.stringify(data, null, 2);
  };

  const importDataJSON = (jsonString: string) => {
    try {
      const data = JSON.parse(jsonString);
      if (data.sessions) setSessions(data.sessions);
      if (data.subjects) setSubjects(data.subjects);
      if (data.chapters) setChapters(data.chapters);
      if (data.tasks) setTasks(data.tasks);
      if (data.notes) setNotes(data.notes);
      if (data.exams) setExams(data.exams);
      if (data.studyBlocks) setStudyBlocks(data.studyBlocks);
      if (data.achievements) setAchievements(data.achievements);
      if (data.profile) {
        const importedProfile = data.profile as UserProfile;
        if (importedProfile.accountType === 'guest' || importedProfile.id === 'guest-user' || importedProfile.id?.startsWith('device:')) {
          setProfile({ ...importedProfile, id: DEVICE_ID, accountType: 'guest', deviceId: DEVICE_ID });
        } else {
          setProfile(importedProfile);
        }
      }
      if (data.settings) setSettings(data.settings);
      if (data.dailyGoals) setDailyGoals(data.dailyGoals);
      return true;
    } catch {
      return false;
    }
  };

  const resetAllData = () => {
    const prefix = STORAGE_KEY_PREFIX;
    try {
      for (let i = localStorage.length - 1; i >= 0; i--) {
        const key = localStorage.key(i);
        if (key && key.startsWith(prefix)) localStorage.removeItem(key);
      }
    } catch {}
    setSessions([]);
    setSubjects([]);
    setChapters([]);
    setTasks([]);
    setNotes([]);
    setExams([]);
    setStudyBlocks([]);
    setAchievements(INITIAL_ACHIEVEMENTS.map(a => ({ ...a, unlocked: false, unlockedAt: undefined })));
    setProfile({ ...INITIAL_USER_PROFILE, id: DEVICE_ID, accountType: 'guest', deviceId: DEVICE_ID });
    setSettings(DEFAULT_SETTINGS);
    setNotifications([]);
    setDailyGoals({});
    setActiveTimer(INITIAL_ACTIVE_TIMER);
    setRecoveredStopwatchSession(null);
    setConflictStopwatchSession(null);
    setDailyLeaderboard(null);
  };

  return (
    <StudiumContext.Provider
      value={{
        sessions,
        subjects,
        chapters,
        tasks,
        notes,
        exams,
        studyBlocks,
        achievements,
        profile,
        settings,
        syncStatus,
        notifications,
        dailyGoals,
        streakData,
        activeTimer,
        leaderboardUsers,
        currentCompletion,
        clearCompletionModal,
        startTimer,
        pauseTimer,
        resumeTimer,
        resetTimer,
        finishTimerSession,
        cancelTimerSession,
        adjustTimerTime,
        skipPomodoroPhase,
        addStopwatchLap,
        quickStart,
        addSubject,
        updateSubject,
        deleteSubject,
        reorderSubjects,
        addChapter,
        updateChapter,
        markChapterCompleted,
        deleteChapter,
        toggleChecklistItem,
        addChecklistItem,
        removeChecklistItem,
        markChapterRevisionCompleted,
        addTask,
        updateTask,
        deleteTask,
        toggleTaskCompletion,
        startTimerFromTask,
        addNote,
        updateNote,
        deleteNote,
        duplicateNote,
        addExam,
        updateExam,
        deleteExam,
        addStudyBlock,
        updateStudyBlock,
        deleteStudyBlock,
        updateDailyGoalTarget,
        addGoalTask,
        toggleGoalTask,
        deleteGoalTask,
        useStreakFreeze,
        togglePinAchievement,
        updateProfile,
        updateSettings,
        toggleWidget,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        clearNotification,
        deleteSession,
        ambientPlaying,
        toggleAmbientSound,
        setAmbientVolume,
        triggerManualSync,
        exportDataJSON,
        importDataJSON,
        resetAllData,
        isFocusMode,
        setFocusMode,
        isQuickActionOpen,
        setQuickActionOpen,
        isSearchOpen,
        setSearchOpen,
        recoveredStopwatchSession,
        conflictStopwatchSession,
        dailyLeaderboard,
        isDailyLeaderboardLoading,
        isOfflineMode,
        refreshDailyLeaderboard: fetchDailyLeaderboard,
        resumeRecoveredStopwatch,
        finishRecoveredStopwatch,
        cancelRecoveredStopwatch,
        dismissRecoveryModal,
        resolveConflictWithResume,
        resolveConflictWithDiscard,
        dismissConflictModal,
      }}
    >
      {children}
    </StudiumContext.Provider>
  );
};

export const useStudium = () => {
  const context = useContext(StudiumContext);
  if (!context) {
    throw new Error('useStudium must be used within a StudiumProvider');
  }
  return context;
};
