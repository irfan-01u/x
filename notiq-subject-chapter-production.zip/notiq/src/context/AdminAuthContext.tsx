import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

export interface AdminUser {
  id: string;
  username: string;
  name: string;
  email: string;
  role: 'SUPER_ADMIN' | 'ADMIN' | 'MODERATOR';
  isInitialPassword: boolean;
  status: 'ACTIVE' | 'DISABLED';
  createdAt: string;
  lastLoginAt?: string;
}

interface AdminAuthContextType {
  adminUser: AdminUser | null;
  token: string | null;
  isAuthenticated: boolean;
  isInitialPasswordWarning: boolean;
  loading: boolean;
  error: string | null;
  permissions: string[];
  login: (username: string, password: string) => Promise<{ success: boolean; error?: string; warning?: string }>;
  logout: () => Promise<void>;
  changePassword: (currentPassword: string, newPassword: string, confirmNewPassword: string) => Promise<{ success: boolean; error?: string }>;
  clearError: () => void;
  refreshProfile: () => Promise<void>;
}

const AdminAuthContext = createContext<AdminAuthContextType | undefined>(undefined);

const TOKEN_KEY = 'studiq_admin_auth_token';

export const AdminAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [token, setToken] = useState<string | null>(() => {
    try {
      return localStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  });
  const [permissions, setPermissions] = useState<string[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isInitialPasswordWarning, setIsInitialPasswordWarning] = useState<boolean>(false);

  const fetchProfile = useCallback(async (authToken: string) => {
    try {
      const res = await fetch('/api/admin/me', {
        headers: {
          Authorization: `Bearer ${authToken}`,
        },
      });

      if (res.ok) {
        const data = await res.json();
        setAdminUser(data.user);
        setPermissions(data.permissions || []);
        setIsInitialPasswordWarning(Boolean(data.isInitialPassword));
      } else {
        // Token invalid or expired
        setAdminUser(null);
        setToken(null);
        setPermissions([]);
        try {
          localStorage.removeItem(TOKEN_KEY);
        } catch {}
      }
    } catch (err) {
      console.error('Failed to verify admin profile:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (token) {
      fetchProfile(token);
    } else {
      setLoading(false);
    }
  }, [token, fetchProfile]);

  const login = async (username: string, password: string) => {
    setError(null);
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        const errMessage = data.error || 'Failed to authenticate administrator.';
        setError(errMessage);
        return { success: false, error: errMessage };
      }

      setToken(data.token);
      setAdminUser(data.user);
      setIsInitialPasswordWarning(Boolean(data.user.isInitialPassword));
      try {
        localStorage.setItem(TOKEN_KEY, data.token);
      } catch {}

      // Refresh permissions
      await fetchProfile(data.token);

      return {
        success: true,
        warning: data.warning,
      };
    } catch (err: any) {
      const msg = err.message || 'Network error during administrator sign-in.';
      setError(msg);
      return { success: false, error: msg };
    }
  };

  const logout = async () => {
    try {
      if (token) {
        await fetch('/api/admin/logout', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
      }
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      setToken(null);
      setAdminUser(null);
      setPermissions([]);
      setIsInitialPasswordWarning(false);
      try {
        localStorage.removeItem(TOKEN_KEY);
      } catch {}
    }
  };

  const changePassword = async (
    currentPassword: string,
    newPassword: string,
    confirmNewPassword: string
  ) => {
    if (!token) return { success: false, error: 'Not authenticated.' };

    try {
      const res = await fetch('/api/admin/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          currentPassword,
          newPassword,
          confirmNewPassword,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        return { success: false, error: data.error || 'Failed to change password.' };
      }

      setIsInitialPasswordWarning(false);
      if (adminUser) {
        setAdminUser({ ...adminUser, isInitialPassword: false });
      }

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error.' };
    }
  };

  const refreshProfile = async () => {
    if (token) {
      await fetchProfile(token);
    }
  };

  return (
    <AdminAuthContext.Provider
      value={{
        adminUser,
        token,
        isAuthenticated: Boolean(adminUser && token),
        isInitialPasswordWarning,
        loading,
        error,
        permissions,
        login,
        logout,
        changePassword,
        clearError: () => setError(null),
        refreshProfile,
      }}
    >
      {children}
    </AdminAuthContext.Provider>
  );
};

export const useAdminAuth = () => {
  const context = useContext(AdminAuthContext);
  if (!context) {
    throw new Error('useAdminAuth must be used within an AdminAuthProvider');
  }
  return context;
};
