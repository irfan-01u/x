import React from 'react';
import { AlertCircle, Play, RefreshCw, X, BookOpen, Clock } from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

export const MultipleSessionConflictModal: React.FC = () => {
  const {
    conflictStopwatchSession,
    resolveConflictWithResume,
    resolveConflictWithDiscard,
    dismissConflictModal,
    subjects,
    chapters,
  } = useStudium();

  if (!conflictStopwatchSession) return null;

  const subject = subjects.find(s => s.id === conflictStopwatchSession.subjectId);
  const chapter = chapters.find(c => c.id === conflictStopwatchSession.chapterId);

  const elapsed = conflictStopwatchSession.elapsedSeconds || conflictStopwatchSession.accumulatedSeconds || 0;
  const hours = Math.floor(elapsed / 3600);
  const minutes = Math.floor((elapsed % 3600) / 60);
  const seconds = elapsed % 60;
  const formattedTime = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const startDate = new Date(conflictStopwatchSession.startTime);
  const formattedStartTime = startDate.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[var(--bg-surface)] border border-amber-500/40 rounded-2xl shadow-2xl p-6 sm:p-7 space-y-5">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                ACTIVE SESSION RESTRICTION
              </span>
              <h2 className="text-base sm:text-lg font-bold text-[var(--text-main)] mt-0.5">
                An active study session is already running.
              </h2>
            </div>
          </div>

          <button
            onClick={dismissConflictModal}
            className="p-1.5 rounded-lg text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-card)] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-[var(--text-muted)] leading-relaxed">
          NOTIQ enforces single-focus discipline. You can only maintain one active study timer session
          at a time across devices. Choose how you would like to proceed:
        </p>

        {/* Existing Session Summary Card */}
        <div className="p-4 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] space-y-2.5 text-xs">
          <div className="flex items-center justify-between border-b border-[var(--border-subtle)] pb-2">
            <span className="text-[var(--text-dim)] uppercase text-[10px] tracking-wider">Currently Active</span>
            <span className="font-mono font-bold text-amber-400">{formattedTime} elapsed</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="text-[10px] text-[var(--text-dim)] block">Started At</span>
              <span className="font-mono font-semibold text-[var(--text-main)]">{formattedStartTime}</span>
            </div>
            <div>
              <span className="text-[10px] text-[var(--text-dim)] block">Subject</span>
              <span className="font-semibold text-[var(--text-main)] truncate block">
                {subject?.name || 'General Study'}
              </span>
            </div>
            {chapter && (
              <div className="col-span-2">
                <span className="text-[10px] text-[var(--text-dim)] block">Chapter</span>
                <span className="font-semibold text-[var(--text-main)] truncate block">
                  {chapter.name}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* 3 Mandated Choice Buttons */}
        <div className="space-y-2 pt-1">
          <button
            onClick={resolveConflictWithResume}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] font-bold text-xs hover:opacity-90 active:scale-95 transition-all shadow-md shadow-[var(--accent)]/20"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Resume Existing Session</span>
          </button>

          <button
            onClick={() => resolveConflictWithDiscard()}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/25 hover:bg-rose-500/20 active:scale-95 font-semibold text-xs transition-all"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Discard & Start New</span>
          </button>

          <button
            onClick={dismissConflictModal}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-xl text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-card)] font-medium text-xs transition-colors"
          >
            <span>Cancel</span>
          </button>
        </div>
      </div>
    </div>
  );
};
