import React from 'react';
import logo from '../../assets/images/notiq-logo.png';
import logoInverse from '../../assets/images/notiq-logo-inverse.png';

interface BrandLogoProps {
  className?: string;
  inverse?: boolean;
  alt?: string;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = 'h-9 w-auto',
  inverse = false,
  alt = 'NOTIQ — Study. Track. Level Up.',
}) => (
  <img
    src={inverse ? logoInverse : logo}
    alt={alt}
    className={`object-contain ${className}`}
    draggable={false}
  />
);
