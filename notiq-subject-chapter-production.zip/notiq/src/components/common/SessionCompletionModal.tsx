import React from 'react';
import {
  Trophy,
  Award,
  Flame,
  CheckCircle2,
  Clock,
  Sparkles,
  ArrowRight,
  Share2,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

export const SessionCompletionModal: React.FC = () => {
  const { currentCompletion, clearCompletionModal, subjects, chapters, profile } = useStudium();

  if (!currentCompletion) return null;

  const {
    session,
    earnedXP,
    newLevel,
    isGoalCompleted,
    newStreak,
    rankImpact,
    unlockedAchievements,
  } = currentCompletion;

  const subject = subjects.find(s => s.id === session.subjectId);
  const chapter = chapters.find(c => c.id === session.chapterId);
  const durationMinutes = Math.max(1, Math.round(session.duration / 60));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div
        className="w-full max-w-md bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Banner with Accent Gradient */}
        <div className="relative p-6 text-center bg-gradient-to-b from-[var(--accent)]/20 via-transparent to-transparent border-b border-[var(--border-subtle)]">
          <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-[var(--accent)] text-[var(--accent-contrast)] flex items-center justify-center shadow-lg shadow-[var(--accent)]/30 animate-bounce">
            <Trophy className="w-7 h-7" />
          </div>

          <h2 className="text-xl font-extrabold text-[var(--text-main)] tracking-tight">
            Study Session Conquered!
          </h2>
          <p className="mt-1 text-xs text-[var(--text-muted)]">
            Every minute dedicated compounds toward academic mastery.
          </p>
        </div>

        {/* Breakdown Stats */}
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            {/* Duration */}
            <div className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
              <div className="flex items-center gap-1.5 text-xs text-[var(--text-muted)]">
                <Clock className="w-3.5 h-3.5 text-sky-400" />
                <span>Study Duration</span>
              </div>
              <div className="mt-1 text-lg font-bold text-[var(--text-main)] tabular-nums">
                {durationMinutes} <span className="text-xs font-normal text-[var(--text-dim)]">mins</span>
              </div>
            </div>

            {/* XP Gained */}
            <div className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
              <div className="flex items-center gap-1.5 text-xs text-[var(--text-muted)]">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Scholastic XP</span>
              </div>
              <div className="mt-1 text-lg font-bold text-amber-400 tabular-nums">
                +{earnedXP} <span className="text-xs font-normal text-[var(--text-dim)]">XP</span>
              </div>
            </div>
          </div>

          {/* Academic Context */}
          <div className="p-3.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] space-y-1.5 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-[var(--text-muted)]">Subject:</span>
              <span className="font-semibold text-[var(--text-main)] truncate max-w-[200px]">
                {subject?.name || 'General Study'}
              </span>
            </div>
            {chapter && (
              <div className="flex justify-between items-center">
                <span className="text-[var(--text-muted)]">Chapter:</span>
                <span className="font-medium text-[var(--accent)] truncate max-w-[200px]">
                  {chapter.name}
                </span>
              </div>
            )}
            <div className="flex justify-between items-center">
              <span className="text-[var(--text-muted)]">Study Mode & Type:</span>
              <span className="text-[var(--text-main)] capitalize">
                {session.timerMode} · {session.studyType}
              </span>
            </div>
          </div>

          {/* Streak & League Impact */}
          <div className="space-y-2">
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs">
              <div className="flex items-center gap-2 text-amber-400 font-semibold">
                <Flame className="w-4 h-4 fill-amber-400" />
                <span>Streak Maintained</span>
              </div>
              <span className="font-mono font-bold text-amber-300 tabular-nums">
                {newStreak} Days Active
              </span>
            </div>

            {newLevel && (
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/20 text-xs">
                <div className="flex items-center gap-2 text-purple-400 font-semibold">
                  <Award className="w-4 h-4" />
                  <span>Level Up! Ascended to Level {newLevel}</span>
                </div>
                <span className="text-[10px] uppercase font-bold text-purple-300">Scholar Rank</span>
              </div>
            )}

            {isGoalCompleted && (
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs">
                <div className="flex items-center gap-2 text-emerald-400 font-semibold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Daily Goal Crushed! (100% Complete)</span>
                </div>
                <span className="text-emerald-300 font-bold">+50 XP</span>
              </div>
            )}

            {unlockedAchievements.length > 0 && (
              <div className="p-3 rounded-xl bg-gradient-to-r from-amber-500/15 to-purple-500/15 border border-amber-500/30">
                <div className="text-[11px] font-semibold text-amber-300 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5" />
                  <span>Achievement Unlocked ({unlockedAchievements.length})</span>
                </div>
                {unlockedAchievements.map(a => (
                  <div key={a.id} className="text-xs font-bold text-[var(--text-main)]">
                    ★ {a.title}: <span className="font-normal text-[var(--text-muted)]">{a.description}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Action button */}
          <button
            onClick={clearCompletionModal}
            className="w-full py-2.5 text-xs font-semibold rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-95 active:scale-98 transition-all flex items-center justify-center gap-2 shadow-sm"
          >
            <span>Continue To Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
