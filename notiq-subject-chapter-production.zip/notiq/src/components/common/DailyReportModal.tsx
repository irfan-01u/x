import React from 'react';
import { X, Clock, BookOpen, FileText, CheckCircle2, Trophy, Flame } from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

interface DailyReportModalProps {
  dateString: string | null;
  onClose: () => void;
}

export const DailyReportModal: React.FC<DailyReportModalProps> = ({ dateString, onClose }) => {
  const { sessions, subjects, notes, dailyGoals } = useStudium();

  if (!dateString) return null;

  // Filter items for this date
  const daySessions = sessions.filter(s => s.dateString === dateString);
  const totalSeconds = daySessions.reduce((acc, s) => acc + s.duration, 0);
  const totalMinutes = Math.round(totalSeconds / 60);
  const totalHours = (totalMinutes / 60).toFixed(1);

  // Group by subject
  const subjectMinutesMap: Record<string, number> = {};
  daySessions.forEach(s => {
    subjectMinutesMap[s.subjectId] = (subjectMinutesMap[s.subjectId] || 0) + s.duration / 60;
  });

  const dayNotes = notes.filter(n => n.createdAt.startsWith(dateString));
  const goal = dailyGoals[dateString];
  const goalMet = goal ? totalMinutes >= goal.targetMinutes : totalMinutes >= 120;

  const dateFormatted = new Date(dateString + 'T12:00:00').toLocaleDateString(undefined, {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs">
      <div
        className="w-full max-w-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[var(--border-subtle)] bg-[var(--bg-card)]">
          <div>
            <div className="text-xs font-semibold text-[var(--accent)] uppercase tracking-wider">
              Daily Study Report
            </div>
            <div className="text-base font-bold text-[var(--text-main)]">{dateFormatted}</div>
          </div>
          <button onClick={onClose} className="p-1 text-[var(--text-dim)] hover:text-[var(--text-main)] rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Key Metrics */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
              <div className="text-[11px] text-[var(--text-muted)]">Study Time</div>
              <div className="mt-1 text-base font-bold text-[var(--text-main)] tabular-nums">
                {totalHours}h <span className="text-xs font-normal text-[var(--text-dim)]">({totalMinutes}m)</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
              <div className="text-[11px] text-[var(--text-muted)]">Sessions</div>
              <div className="mt-1 text-base font-bold text-[var(--text-main)] tabular-nums">
                {daySessions.length}
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
              <div className="text-[11px] text-[var(--text-muted)]">Goal Met</div>
              <div className={`mt-1 text-base font-bold flex items-center gap-1 ${goalMet ? 'text-emerald-400' : 'text-amber-400'}`}>
                {goalMet ? <CheckCircle2 className="w-4 h-4" /> : null}
                <span>{goalMet ? 'Yes' : 'Partial'}</span>
              </div>
            </div>
          </div>

          {/* Subject Breakdown */}
          <div>
            <div className="text-xs font-semibold text-[var(--text-dim)] uppercase tracking-wider mb-2">
              Time by Subject
            </div>
            {Object.keys(subjectMinutesMap).length === 0 ? (
              <div className="text-xs text-[var(--text-muted)] p-3 rounded-xl bg-[var(--bg-card)] text-center">
                No study sessions recorded on this day.
              </div>
            ) : (
              <div className="space-y-2">
                {Object.entries(subjectMinutesMap).map(([subjId, mins]) => {
                  const s = subjects.find(sub => sub.id === subjId);
                  const pct = totalMinutes > 0 ? Math.round((mins / totalMinutes) * 100) : 0;
                  return (
                    <div key={subjId} className="p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
                      <div className="flex justify-between items-center text-xs mb-1">
                        <span className="font-semibold text-[var(--text-main)]">{s?.name || 'Subject'}</span>
                        <span className="text-[var(--text-muted)] font-mono tabular-nums">
                          {Math.round(mins)}m ({pct}%)
                        </span>
                      </div>
                      <div className="w-full h-1.5 bg-[var(--bg-base)] rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${pct}%`,
                            backgroundColor: s?.accentColor || 'var(--accent)',
                          }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Sessions Log */}
          {daySessions.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-[var(--text-dim)] uppercase tracking-wider mb-2">
                Logged Sessions ({daySessions.length})
              </div>
              <div className="space-y-1.5">
                {daySessions.map((sess) => {
                  const s = subjects.find(sub => sub.id === sess.subjectId);
                  const startTimeStr = new Date(sess.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                  return (
                    <div
                      key={sess.id}
                      className="p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-xs flex items-center justify-between"
                    >
                      <div>
                        <div className="font-semibold text-[var(--text-main)]">
                          {s?.name || 'Subject'} · <span className="font-normal text-[var(--text-muted)]">{sess.studyType}</span>
                        </div>
                        {sess.taskTitle && (
                          <div className="text-[11px] text-[var(--text-dim)] mt-0.5">{sess.taskTitle}</div>
                        )}
                      </div>
                      <div className="text-right">
                        <div className="font-mono font-bold text-[var(--text-main)] tabular-nums">
                          {Math.round(sess.duration / 60)}m
                        </div>
                        <div className="text-[10px] text-[var(--text-dim)]">{startTimeStr}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Notes Created */}
          {dayNotes.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-[var(--text-dim)] uppercase tracking-wider mb-2">
                Notes Created ({dayNotes.length})
              </div>
              <div className="space-y-1">
                {dayNotes.map(n => (
                  <div key={n.id} className="p-2 rounded-lg bg-[var(--bg-card)] text-xs text-[var(--text-main)] flex items-center gap-2">
                    <FileText className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                    <span className="truncate">{n.title}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
