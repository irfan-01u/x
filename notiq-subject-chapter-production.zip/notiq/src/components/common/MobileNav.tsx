import React, { useState } from 'react';
import {
  LayoutDashboard,
  Timer,
  BookOpen,
  Trophy,
  User,
  Menu,
  X,
  Clock,
  Hourglass,
  ListTodo,
  FileText,
  Calendar,
  GraduationCap,
  RefreshCw,
  BarChart3,
  Award,
  Settings,
  ShieldAlert,
  Flame,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

interface MobileNavProps {
  activeView: string;
  onNavigate: (view: string) => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({ activeView, onNavigate }) => {
  const [isMoreOpen, setIsMoreOpen] = useState(false);
  const { activeTimer } = useStudium();

  const primaryTabs = [
    { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
    {
      id: 'timer',
      label: 'Timer',
      icon: Timer,
      badge: activeTimer.status === 'running',
    },
    { id: 'subjects', label: 'Subjects', icon: BookOpen },
    { id: 'leaderboard', label: 'Ranks', icon: Trophy },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  const secondaryTabs = [
    { id: 'pomodoro', label: 'Pomodoro Engine', icon: Clock },
    { id: 'stopwatch', label: 'Stopwatch Lab', icon: Hourglass },
    { id: 'tasks', label: 'Tasks & To-Do', icon: ListTodo },
    { id: 'notes', label: 'Notes Notebook', icon: FileText },
    { id: 'planner', label: 'Study Planner', icon: Calendar },
    { id: 'exams', label: 'Exam Tracker', icon: GraduationCap },
    { id: 'revision', label: 'Spaced Revision', icon: RefreshCw },
    { id: 'analytics', label: 'Analytics & Trends', icon: BarChart3 },
    { id: 'heatmap', label: 'Streaks & Heatmap', icon: Flame },
    { id: 'achievements', label: 'Achievements', icon: Award },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'admin', label: 'Admin Console', icon: ShieldAlert },
  ];

  return (
    <>
      {/* Mobile Drawer for More Items */}
      {isMoreOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex flex-col justify-end md:hidden">
          <div className="bg-[var(--bg-surface)] border-t border-[var(--border-subtle)] rounded-t-2xl p-4 max-h-[80vh] overflow-y-auto animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-[var(--border-subtle)] mb-3">
              <span className="text-sm font-semibold text-[var(--text-main)]">All Academic Modules</span>
              <button
                onClick={() => setIsMoreOpen(false)}
                className="p-1 text-[var(--text-muted)] hover:text-[var(--text-main)] rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {secondaryTabs.map((item) => {
                const Icon = item.icon;
                const isActive = activeView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onNavigate(item.id);
                      setIsMoreOpen(false);
                    }}
                    className={`flex items-center gap-2.5 p-3 rounded-xl text-left text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold'
                        : 'bg-[var(--bg-card)] text-[var(--text-main)] hover:bg-[var(--bg-card-hover)]'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Persistent Bottom Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[var(--bg-surface)]/95 backdrop-blur-md border-t border-[var(--border-subtle)] flex items-center justify-around py-1.5 px-2">
        {primaryTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeView === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onNavigate(tab.id)}
              className={`relative flex flex-col items-center justify-center py-1 px-3 min-w-[56px] text-[10px] font-medium transition-colors ${
                isActive ? 'text-[var(--accent)] font-semibold' : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
              }`}
            >
              <div className="relative">
                <Icon className="w-5 h-5" />
                {tab.badge && (
                  <span className="absolute -top-0.5 -right-1 w-2 h-2 rounded-full bg-[var(--accent)] animate-ping" />
                )}
              </div>
              <span className="mt-0.5">{tab.label}</span>
            </button>
          );
        })}

        {/* More Toggle */}
        <button
          onClick={() => setIsMoreOpen(true)}
          className="flex flex-col items-center justify-center py-1 px-3 min-w-[56px] text-[10px] font-medium text-[var(--text-muted)] hover:text-[var(--text-main)]"
        >
          <Menu className="w-5 h-5" />
          <span className="mt-0.5">More</span>
        </button>
      </nav>
    </>
  );
};
