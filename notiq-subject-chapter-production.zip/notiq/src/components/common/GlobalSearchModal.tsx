import React, { useState, useMemo } from 'react';
import { Search, X, BookOpen, BookmarkCheck, ListTodo, FileText, Clock, User, ArrowRight } from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

interface GlobalSearchModalProps {
  onNavigate: (view: string, detailId?: string) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({ onNavigate }) => {
  const { isSearchOpen, setSearchOpen, subjects, chapters, tasks, notes, sessions, leaderboardUsers } = useStudium();
  const [query, setQuery] = useState('');

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return null;

    const matchedSubjects = subjects.filter(s => s.name.toLowerCase().includes(q) || s.description.toLowerCase().includes(q));
    const matchedChapters = chapters.filter(c => c.name.toLowerCase().includes(q) || c.description.toLowerCase().includes(q));
    const matchedTasks = tasks.filter(t => t.title.toLowerCase().includes(q));
    const matchedNotes = notes.filter(n => n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q) || n.tags.some(t => t.toLowerCase().includes(q)));
    const matchedPeers = leaderboardUsers.filter(u => u.name.toLowerCase().includes(q) || u.username.toLowerCase().includes(q));

    return {
      subjects: matchedSubjects.slice(0, 4),
      chapters: matchedChapters.slice(0, 4),
      tasks: matchedTasks.slice(0, 4),
      notes: matchedNotes.slice(0, 4),
      peers: matchedPeers.slice(0, 4),
    };
  }, [query, subjects, chapters, tasks, notes, leaderboardUsers]);

  if (!isSearchOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/60 backdrop-blur-xs">
      <div
        className="w-full max-w-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-[var(--border-subtle)] gap-3 bg-[var(--bg-card)]">
          <Search className="w-5 h-5 text-[var(--accent)] shrink-0" />
          <input
            type="text"
            placeholder="Search academic notes, subjects, chapters, tasks, peers..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            className="w-full bg-transparent text-sm text-[var(--text-main)] placeholder-[var(--text-dim)] focus:outline-none"
          />
          {query && (
            <button onClick={() => setQuery('')} className="p-1 text-[var(--text-dim)] hover:text-[var(--text-main)]">
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => setSearchOpen(false)}
            className="text-xs px-2 py-1 bg-[var(--bg-base)] text-[var(--text-dim)] hover:text-[var(--text-main)] rounded border border-[var(--border-subtle)]"
          >
            ESC
          </button>
        </div>

        {/* Results Body */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-4">
          {!query && (
            <div className="py-8 text-center text-xs text-[var(--text-muted)] space-y-2">
              <p>Type keywords to search across your academic knowledge base.</p>
              <div className="flex items-center justify-center gap-2 text-[11px] text-[var(--text-dim)]">
                <span>Hint: Search "#physics", "Maxwell", "Knapsack", or "Exam"</span>
              </div>
            </div>
          )}

          {query && results && (
            <>
              {results.subjects.length === 0 &&
                results.chapters.length === 0 &&
                results.tasks.length === 0 &&
                results.notes.length === 0 &&
                results.peers.length === 0 && (
                  <div className="py-8 text-center text-xs text-[var(--text-dim)]">
                    No matching academic records found for "{query}".
                  </div>
                )}

              {/* Subjects */}
              {results.subjects.length > 0 && (
                <div>
                  <div className="text-[10px] font-semibold text-[var(--text-dim)] uppercase tracking-wider mb-2">
                    Subjects ({results.subjects.length})
                  </div>
                  <div className="space-y-1">
                    {results.subjects.map((s) => (
                      <button
                        key={s.id}
                        onClick={() => {
                          onNavigate('subjects', s.id);
                          setSearchOpen(false);
                        }}
                        className="w-full flex items-center justify-between p-2.5 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] text-left transition-colors group"
                      >
                        <div className="flex items-center gap-3">
                          <BookOpen className="w-4 h-4 text-[var(--accent)]" />
                          <div>
                            <div className="text-xs font-semibold text-[var(--text-main)] group-hover:text-[var(--accent)]">
                              {s.name}
                            </div>
                            <div className="text-[11px] text-[var(--text-dim)] truncate max-w-md">
                              {s.description}
                            </div>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-[var(--text-dim)] group-hover:text-[var(--text-main)]" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Chapters */}
              {results.chapters.length > 0 && (
                <div>
                  <div className="text-[10px] font-semibold text-[var(--text-dim)] uppercase tracking-wider mb-2">
                    Chapters & Syllabus ({results.chapters.length})
                  </div>
                  <div className="space-y-1">
                    {results.chapters.map((c) => (
                      <button
                        key={c.id}
                        onClick={() => {
                          onNavigate('chapters', c.id);
                          setSearchOpen(false);
                        }}
                        className="w-full flex items-center justify-between p-2.5 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] text-left transition-colors group"
                      >
                        <div className="flex items-center gap-3">
                          <BookmarkCheck className="w-4 h-4 text-emerald-400" />
                          <div>
                            <div className="text-xs font-semibold text-[var(--text-main)] group-hover:text-[var(--accent)]">
                              {c.name}
                            </div>
                            <div className="text-[11px] text-[var(--text-dim)] truncate max-w-md">
                              Status: {c.status} · Progress: {c.customProgress}%
                            </div>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-[var(--text-dim)] group-hover:text-[var(--text-main)]" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Notes */}
              {results.notes.length > 0 && (
                <div>
                  <div className="text-[10px] font-semibold text-[var(--text-dim)] uppercase tracking-wider mb-2">
                    Notes ({results.notes.length})
                  </div>
                  <div className="space-y-1">
                    {results.notes.map((n) => (
                      <button
                        key={n.id}
                        onClick={() => {
                          onNavigate('notes', n.id);
                          setSearchOpen(false);
                        }}
                        className="w-full flex items-center justify-between p-2.5 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] text-left transition-colors group"
                      >
                        <div className="flex items-center gap-3">
                          <FileText className="w-4 h-4 text-purple-400" />
                          <div>
                            <div className="text-xs font-semibold text-[var(--text-main)] group-hover:text-[var(--accent)]">
                              {n.title}
                            </div>
                            <div className="text-[11px] text-[var(--text-dim)] truncate max-w-md">
                              {n.tags.join(' ')}
                            </div>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-[var(--text-dim)] group-hover:text-[var(--text-main)]" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Tasks */}
              {results.tasks.length > 0 && (
                <div>
                  <div className="text-[10px] font-semibold text-[var(--text-dim)] uppercase tracking-wider mb-2">
                    Tasks ({results.tasks.length})
                  </div>
                  <div className="space-y-1">
                    {results.tasks.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => {
                          onNavigate('tasks', t.id);
                          setSearchOpen(false);
                        }}
                        className="w-full flex items-center justify-between p-2.5 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] text-left transition-colors group"
                      >
                        <div className="flex items-center gap-3">
                          <ListTodo className="w-4 h-4 text-amber-400" />
                          <div>
                            <div className="text-xs font-semibold text-[var(--text-main)] group-hover:text-[var(--accent)]">
                              {t.title}
                            </div>
                            <div className="text-[11px] text-[var(--text-dim)]">
                              Priority: {t.priority} · {t.estimatedMinutes}m
                            </div>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-[var(--text-dim)] group-hover:text-[var(--text-main)]" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Peers / Leaderboard */}
              {results.peers.length > 0 && (
                <div>
                  <div className="text-[10px] font-semibold text-[var(--text-dim)] uppercase tracking-wider mb-2">
                    Scholars & Peers ({results.peers.length})
                  </div>
                  <div className="space-y-1">
                    {results.peers.map((p) => (
                      <button
                        key={p.userId}
                        onClick={() => {
                          onNavigate('leaderboard');
                          setSearchOpen(false);
                        }}
                        className="w-full flex items-center justify-between p-2.5 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] text-left transition-colors group"
                      >
                        <div className="flex items-center gap-3">
                          <img src={p.avatar} alt={p.name} className="w-6 h-6 rounded-full object-cover" />
                          <div>
                            <div className="text-xs font-semibold text-[var(--text-main)] group-hover:text-[var(--accent)]">
                              {p.name} (@{p.username})
                            </div>
                            <div className="text-[11px] text-[var(--text-dim)]">
                              Rank #{p.rank} · {p.tier} League · {Math.round(p.studyMinutes / 60)}h study
                            </div>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-[var(--text-dim)] group-hover:text-[var(--text-main)]" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
