import React from 'react';
import {
  LayoutDashboard,
  Timer,
  Clock,
  Hourglass,
  BookOpen,
  BookmarkCheck,
  ListTodo,
  FileText,
  Calendar,
  GraduationCap,
  RefreshCw,
  BarChart3,
  Flame,
  Award,
  Trophy,
  FileBarChart2,
  Settings,
  ShieldAlert,
  Wifi,
  WifiOff,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';
import { BrandLogo } from './BrandLogo';

interface SidebarProps {
  activeView: string;
  onNavigate: (view: string) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  onNavigate,
  collapsed,
  onToggleCollapse,
}) => {
  const { syncStatus, triggerManualSync, streakData, activeTimer } = useStudium();

  const navSections = [
    {
      title: 'CORE STUDY',
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        {
          id: 'timer',
          label: 'Study Timer',
          icon: Timer,
          badge: activeTimer.status === 'running' && activeTimer.mode !== 'pomodoro' && activeTimer.mode !== 'stopwatch' ? 'Active' : undefined,
        },
        {
          id: 'pomodoro',
          label: 'Pomodoro Engine',
          icon: Clock,
          badge: activeTimer.status === 'running' && activeTimer.mode === 'pomodoro' ? 'Cycle' : undefined,
        },
        {
          id: 'stopwatch',
          label: 'Stopwatch Lab',
          icon: Hourglass,
          badge: activeTimer.status === 'running' && activeTimer.mode === 'stopwatch' ? 'Run' : undefined,
        },
        { id: 'subjects', label: 'Subjects', icon: BookOpen },
        { id: 'chapters', label: 'Chapter Progress', icon: BookmarkCheck },
        { id: 'tasks', label: 'Tasks & To-Do', icon: ListTodo },
      ],
    },
    {
      title: 'PROGRESS & ANALYTICS',
      items: [
        { id: 'heatmap', label: 'Streaks & Heatmap', icon: Flame, badge: `${streakData.currentStreak}d` },
        { id: 'analytics', label: 'Analytics & Insights', icon: BarChart3 },
        { id: 'achievements', label: 'Achievements', icon: Award },
        { id: 'revision', label: 'Spaced Revision', icon: RefreshCw },
        { id: 'reports', label: 'Study Reports', icon: FileBarChart2 },
      ],
    },
    {
      title: 'LEAGUE & COMPETITION',
      items: [
        { id: 'leaderboard', label: 'Weekly League & Ranks', icon: Trophy },
      ],
    },
    {
      title: 'ACADEMIC TOOLS',
      items: [
        { id: 'notes', label: 'Notes Notebook', icon: FileText },
        { id: 'planner', label: 'Study Planner', icon: Calendar },
        { id: 'exams', label: 'Exam Countdown', icon: GraduationCap },
      ],
    },
    {
      title: 'SYSTEM',
      items: [
        { id: 'settings', label: 'Personal Settings', icon: Settings },
        { id: 'admin', label: 'Admin Management', icon: ShieldAlert },
      ],
    },
  ];

  return (
    <aside
      className={`hidden md:flex flex-col bg-[var(--bg-surface)] border-r border-[var(--border-subtle)] transition-all duration-200 select-none z-20 ${
        collapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div className="flex items-center justify-between h-14 px-4 border-b border-[var(--border-subtle)]">
        {!collapsed && (
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex flex-col items-start justify-center gap-0.5 text-left group"
          >
            <BrandLogo inverse className="h-10 w-auto max-w-[150px]" />
            <span className="text-[8px] tracking-wide text-[var(--text-dim)] font-medium">Study. Track. Level Up.</span>
          </button>
        )}


        {collapsed && (
          <button
            onClick={() => onNavigate('dashboard')}
            className="w-10 h-10 mx-auto flex items-center justify-center rounded-lg overflow-hidden"
            aria-label="NOTIQ"
          >
            <BrandLogo inverse className="w-10 h-10 object-contain" />
          </button>
        )}

        <button
          onClick={onToggleCollapse}
          className="p-1.5 text-[var(--text-dim)] hover:text-[var(--text-main)] hover:bg-[var(--bg-card)] rounded-md transition-colors"
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Navigation List */}
      <div className="flex-1 overflow-y-auto px-2 py-3 space-y-4">
        {navSections.map((section, sIdx) => (
          <div key={sIdx} className="space-y-0.5">
            {!collapsed && (
              <div className="px-3 py-1 text-[10px] font-semibold tracking-wider text-[var(--text-dim)] uppercase">
                {section.title}
              </div>
            )}
            {section.items.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  title={collapsed ? item.label : undefined}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-[var(--bg-card)] text-[var(--accent)] font-semibold shadow-xs border-l-2 border-[var(--accent)]'
                      : 'text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-card)]/50'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[var(--accent)]' : 'text-[var(--text-dim)]'}`} />
                  {!collapsed && (
                    <span className="truncate flex-1 text-left">{item.label}</span>
                  )}
                  {!collapsed && item.badge && (
                    <span className="px-1.5 py-0.2 text-[10px] rounded font-mono font-medium bg-[var(--accent)]/10 text-[var(--accent)]">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Cloud Sync & Offline Status Footer */}
      <div className="p-3 border-t border-[var(--border-subtle)] bg-[var(--bg-surface)]">
        {!collapsed ? (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-[11px] text-[var(--text-muted)]">
              {syncStatus.status === 'Connected' ? (
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
              )}
              <span className="truncate">
                {syncStatus.status === 'Connected' ? 'Cloud Synced' : 'Offline Storage'}
              </span>
            </div>
            <button
              onClick={triggerManualSync}
              className="p-1 text-[var(--text-dim)] hover:text-[var(--accent)] hover:bg-[var(--bg-card)] rounded transition-colors"
              title="Sync now"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${syncStatus.status === 'Syncing' ? 'animate-spin text-[var(--accent)]' : ''}`} />
            </button>
          </div>
        ) : (
          <button
            onClick={triggerManualSync}
            className="w-full flex justify-center p-1.5 text-[var(--text-dim)] hover:text-[var(--accent)]"
            title="Cloud status"
          >
            {syncStatus.status === 'Connected' ? (
              <Wifi className="w-4 h-4 text-emerald-400" />
            ) : (
              <WifiOff className="w-4 h-4 text-amber-400" />
            )}
          </button>
        )}
      </div>
    </aside>
  );
};
