import React, { useEffect, useState } from 'react';
import { Clock, Play, CheckCircle2, X, AlertTriangle, BookOpen, Layers } from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

export const ActiveStopwatchRecoveryModal: React.FC = () => {
  const {
    recoveredStopwatchSession,
    resumeRecoveredStopwatch,
    finishRecoveredStopwatch,
    cancelRecoveredStopwatch,
    dismissRecoveryModal,
    subjects,
    chapters,
  } = useStudium();

  const [liveElapsed, setLiveElapsed] = useState(0);

  useEffect(() => {
    if (!recoveredStopwatchSession) return;

    // Calculate initial elapsed based on server timestamps
    const now = Date.now();
    const baseElapsed =
      recoveredStopwatchSession.elapsedSeconds ||
      recoveredStopwatchSession.accumulatedSeconds ||
      Math.max(0, Math.floor((now - recoveredStopwatchSession.startTime) / 1000));
    setLiveElapsed(baseElapsed);

    // Live tick if running
    if (recoveredStopwatchSession.status === 'running') {
      const interval = setInterval(() => {
        setLiveElapsed(prev => prev + 1);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [recoveredStopwatchSession]);

  if (!recoveredStopwatchSession) return null;

  const subject = subjects.find(s => s.id === recoveredStopwatchSession.subjectId);
  const chapter = chapters.find(c => c.id === recoveredStopwatchSession.chapterId);

  const hours = Math.floor(liveElapsed / 3600);
  const minutes = Math.floor((liveElapsed % 3600) / 60);
  const seconds = liveElapsed % 60;
  const formattedElapsed = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const startDate = new Date(recoveredStopwatchSession.startTime);
  const formattedStartTime = startDate.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
  const formattedStartDate = startDate.toLocaleDateString([], {
    month: 'short',
    day: 'numeric',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[var(--bg-surface)] border border-[var(--accent)]/30 rounded-2xl shadow-2xl p-6 sm:p-7 space-y-6">
        {/* Header with dismiss */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold">
              <Clock className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  SERVER RECOVERY
                </span>
                <span className="text-[10px] font-mono text-[var(--text-dim)]">
                  {recoveredStopwatchSession.status.toUpperCase()}
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-[var(--text-main)] mt-0.5">
                Active Stopwatch Found
              </h2>
            </div>
          </div>

          <button
            onClick={dismissRecoveryModal}
            className="p-1.5 rounded-lg text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-card)] transition-colors"
            title="Dismiss recovery prompt"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-[var(--text-muted)] leading-relaxed">
          An ongoing academic study session was preserved on the server. Your timer continued
          accurately based on server wall-clock timestamps while you were away.
        </p>

        {/* Live Metrics Showcase */}
        <div className="p-4 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] space-y-3">
          <div className="flex items-center justify-between border-b border-[var(--border-subtle)] pb-2.5">
            <span className="text-xs text-[var(--text-muted)]">Elapsed Wall-Clock Time:</span>
            <span className="font-mono font-bold text-2xl text-[var(--accent)] tabular-nums">
              {formattedElapsed}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-[10px] text-[var(--text-dim)] uppercase block">Start Time</span>
              <span className="font-semibold text-[var(--text-main)] font-mono">
                {formattedStartDate} at {formattedStartTime}
              </span>
            </div>

            <div>
              <span className="text-[10px] text-[var(--text-dim)] uppercase block">Subject</span>
              <span className="font-semibold text-[var(--text-main)] flex items-center gap-1.5 truncate">
                <BookOpen className="w-3.5 h-3.5 text-[var(--accent)] shrink-0" />
                <span className="truncate">{subject?.name || 'General Study'}</span>
              </span>
            </div>

            {chapter && (
              <div className="col-span-2">
                <span className="text-[10px] text-[var(--text-dim)] uppercase block">Chapter</span>
                <span className="font-semibold text-[var(--text-main)] flex items-center gap-1.5 truncate">
                  <Layers className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                  <span className="truncate">{chapter.name}</span>
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="grid grid-cols-3 gap-2.5 pt-1">
          <button
            onClick={resumeRecoveredStopwatch}
            className="flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] font-bold text-xs hover:opacity-90 active:scale-95 transition-all shadow-md shadow-[var(--accent)]/20"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Resume</span>
          </button>

          <button
            onClick={finishRecoveredStopwatch}
            className="flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20 active:scale-95 font-bold text-xs transition-all"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Finish</span>
          </button>

          <button
            onClick={cancelRecoveredStopwatch}
            className="flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-[var(--bg-card)] text-rose-400 border border-rose-500/20 hover:bg-rose-500/10 active:scale-95 font-semibold text-xs transition-all"
          >
            <X className="w-4 h-4" />
            <span>Cancel</span>
          </button>
        </div>
      </div>
    </div>
  );
};
