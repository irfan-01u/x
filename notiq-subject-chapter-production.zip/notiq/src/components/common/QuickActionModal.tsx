import React, { useState } from 'react';
import { X, Clock, Flame, Hourglass, FileText, ListTodo, Plus, Check } from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

interface QuickActionModalProps {
  onNavigate: (view: string) => void;
}

export const QuickActionModal: React.FC<QuickActionModalProps> = ({ onNavigate }) => {
  const {
    isQuickActionOpen,
    setQuickActionOpen,
    quickStart,
    startTimer,
    addNote,
    addTask,
    subjects,
  } = useStudium();

  const [activeTab, setActiveTab] = useState<'launcher' | 'quickNote' | 'quickTask'>('launcher');

  // Quick note form state
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [noteSubj, setNoteSubj] = useState(subjects[0]?.id || '');

  // Quick task form state
  const [taskTitle, setTaskTitle] = useState('');
  const [taskSubj, setTaskSubj] = useState(subjects[0]?.id || '');
  const [taskEst, setTaskEst] = useState(30);

  if (!isQuickActionOpen) return null;

  const handleCreateNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle.trim()) return;
    addNote({
      title: noteTitle,
      content: noteContent,
      subjectId: noteSubj,
      tags: ['#quicknote'],
      folder: 'Quick Captures',
      isPinned: false,
      isFavorite: false,
      isArchived: false,
    });
    setNoteTitle('');
    setNoteContent('');
    setQuickActionOpen(false);
    onNavigate('notes');
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;
    addTask({
      title: taskTitle,
      subjectId: taskSubj,
      priority: 'Medium',
      estimatedMinutes: taskEst,
      completed: false,
      order: 0,
      scheduledDate: new Date().toISOString().slice(0, 10),
    });
    setTaskTitle('');
    setQuickActionOpen(false);
    onNavigate('tasks');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div
        className="w-full max-w-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[var(--border-subtle)] bg-[var(--bg-card)]">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-[var(--text-main)]">Quick Actions</span>
            <span className="text-[11px] text-[var(--text-dim)]">· Instant Study Launch</span>
          </div>
          <button
            onClick={() => {
              setQuickActionOpen(false);
              setActiveTab('launcher');
            }}
            className="p-1 text-[var(--text-dim)] hover:text-[var(--text-main)] rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Tabs */}
        {activeTab === 'launcher' && (
          <div className="p-5 space-y-4">
            <div className="text-xs font-semibold text-[var(--text-dim)] uppercase tracking-wider">
              1-Click Timer Presets
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => {
                  quickStart(25, 'pomodoro');
                  onNavigate('pomodoro');
                }}
                className="flex items-center gap-3 p-3.5 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] border border-[var(--border-subtle)] hover:border-[var(--border-active)] transition-all text-left group"
              >
                <div className="w-9 h-9 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold text-sm shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-[var(--text-main)] group-hover:text-[var(--accent)]">
                    25m Pomodoro
                  </div>
                  <div className="text-[11px] text-[var(--text-dim)]">Standard focus interval</div>
                </div>
              </button>

              <button
                onClick={() => {
                  quickStart(50, 'pomodoro');
                  onNavigate('pomodoro');
                }}
                className="flex items-center gap-3 p-3.5 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] border border-[var(--border-subtle)] hover:border-[var(--border-active)] transition-all text-left group"
              >
                <div className="w-9 h-9 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center font-bold text-sm shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-[var(--text-main)] group-hover:text-[var(--accent)]">
                    50m Pomodoro
                  </div>
                  <div className="text-[11px] text-[var(--text-dim)]">Double cycle focus</div>
                </div>
              </button>

              <button
                onClick={() => {
                  quickStart(90, 'deepwork');
                  onNavigate('timer');
                }}
                className="flex items-center gap-3 p-3.5 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] border border-[var(--border-subtle)] hover:border-[var(--border-active)] transition-all text-left group"
              >
                <div className="w-9 h-9 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center font-bold text-sm shrink-0">
                  <Flame className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-[var(--text-main)] group-hover:text-[var(--accent)]">
                    90m Deep Work
                  </div>
                  <div className="text-[11px] text-[var(--text-dim)]">Ultradian flow block</div>
                </div>
              </button>

              <button
                onClick={() => {
                  startTimer({ mode: 'stopwatch', targetDuration: 0, elapsedSeconds: 0 });
                  setQuickActionOpen(false);
                  onNavigate('stopwatch');
                }}
                className="flex items-center gap-3 p-3.5 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] border border-[var(--border-subtle)] hover:border-[var(--border-active)] transition-all text-left group"
              >
                <div className="w-9 h-9 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold text-sm shrink-0">
                  <Hourglass className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-[var(--text-main)] group-hover:text-[var(--accent)]">
                    Start Stopwatch
                  </div>
                  <div className="text-[11px] text-[var(--text-dim)]">Lap timing & count up</div>
                </div>
              </button>
            </div>

            <div className="pt-3 border-t border-[var(--border-subtle)]">
              <div className="text-xs font-semibold text-[var(--text-dim)] uppercase tracking-wider mb-2">
                Quick Capture
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setActiveTab('quickNote')}
                  className="flex items-center gap-2.5 p-3 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] text-xs font-medium text-[var(--text-main)] transition-colors border border-[var(--border-subtle)]"
                >
                  <FileText className="w-4 h-4 text-purple-400" />
                  <span>Create Quick Note</span>
                </button>
                <button
                  onClick={() => setActiveTab('quickTask')}
                  className="flex items-center gap-2.5 p-3 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] text-xs font-medium text-[var(--text-main)] transition-colors border border-[var(--border-subtle)]"
                >
                  <ListTodo className="w-4 h-4 text-emerald-400" />
                  <span>Add Study Task</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Quick Note Tab */}
        {activeTab === 'quickNote' && (
          <form onSubmit={handleCreateNote} className="p-5 space-y-3">
            <div className="flex items-center justify-between text-xs text-[var(--text-muted)]">
              <span className="font-semibold text-[var(--text-main)]">Capture Academic Note</span>
              <button
                type="button"
                onClick={() => setActiveTab('launcher')}
                className="text-[var(--accent)] hover:underline"
              >
                ← Back
              </button>
            </div>

            <div>
              <label className="block text-[11px] text-[var(--text-muted)] mb-1">Subject</label>
              <select
                value={noteSubj}
                onChange={(e) => setNoteSubj(e.target.value)}
                className="w-full text-xs p-2 rounded-lg bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] focus:outline-none"
              >
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] text-[var(--text-muted)] mb-1">Title</label>
              <input
                type="text"
                value={noteTitle}
                onChange={(e) => setNoteTitle(e.target.value)}
                placeholder="e.g. Stokes Theorem Formula"
                autoFocus
                className="w-full text-xs p-2.5 rounded-lg bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] text-[var(--text-muted)] mb-1">Notes / Formula</label>
              <textarea
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                rows={3}
                placeholder="Write your note markdown..."
                className="w-full text-xs p-2.5 rounded-lg bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] focus:outline-none resize-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setActiveTab('launcher')}
                className="px-3 py-1.5 text-xs text-[var(--text-muted)] hover:bg-[var(--bg-card)] rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!noteTitle.trim()}
                className="px-4 py-1.5 text-xs font-medium text-white bg-[var(--accent)] hover:opacity-90 disabled:opacity-50 rounded-lg"
              >
                Save Note
              </button>
            </div>
          </form>
        )}

        {/* Quick Task Tab */}
        {activeTab === 'quickTask' && (
          <form onSubmit={handleCreateTask} className="p-5 space-y-3">
            <div className="flex items-center justify-between text-xs text-[var(--text-muted)]">
              <span className="font-semibold text-[var(--text-main)]">Add Study Task</span>
              <button
                type="button"
                onClick={() => setActiveTab('launcher')}
                className="text-[var(--accent)] hover:underline"
              >
                ← Back
              </button>
            </div>

            <div>
              <label className="block text-[11px] text-[var(--text-muted)] mb-1">Subject</label>
              <select
                value={taskSubj}
                onChange={(e) => setTaskSubj(e.target.value)}
                className="w-full text-xs p-2 rounded-lg bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] focus:outline-none"
              >
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] text-[var(--text-muted)] mb-1">Task Title</label>
              <input
                type="text"
                value={taskTitle}
                onChange={(e) => setTaskTitle(e.target.value)}
                placeholder="e.g. Solve 5 problems on Dijkstra's algorithm"
                autoFocus
                className="w-full text-xs p-2.5 rounded-lg bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] text-[var(--text-muted)] mb-1">
                Estimated Duration ({taskEst}m)
              </label>
              <input
                type="range"
                min="10"
                max="120"
                step="5"
                value={taskEst}
                onChange={(e) => setTaskEst(parseInt(e.target.value))}
                className="w-full accent-[var(--accent)]"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setActiveTab('launcher')}
                className="px-3 py-1.5 text-xs text-[var(--text-muted)] hover:bg-[var(--bg-card)] rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!taskTitle.trim()}
                className="px-4 py-1.5 text-xs font-medium text-white bg-[var(--accent)] hover:opacity-90 disabled:opacity-50 rounded-lg"
              >
                Add Task
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
