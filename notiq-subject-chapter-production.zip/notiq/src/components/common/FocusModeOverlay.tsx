import React from 'react';
import {
  Minimize2,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  Plus,
  Minus,
  Headphones,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

export const FocusModeOverlay: React.FC = () => {
  const {
    isFocusMode,
    setFocusMode,
    activeTimer,
    pauseTimer,
    resumeTimer,
    finishTimerSession,
    cancelTimerSession,
    adjustTimerTime,
    subjects,
    chapters,
    ambientPlaying,
    toggleAmbientSound,
  } = useStudium();

  if (!isFocusMode) return null;

  const subject = subjects.find(s => s.id === activeTimer.subjectId);
  const chapter = chapters.find(c => c.id === activeTimer.chapterId);

  // Time calculations
  let displaySeconds = 0;
  let progressPercent = 0;

  if (activeTimer.mode === 'countup' || activeTimer.mode === 'stopwatch') {
    displaySeconds = activeTimer.elapsedSeconds;
    progressPercent = Math.min(100, (displaySeconds % 3600) / 36);
  } else {
    displaySeconds = Math.max(0, activeTimer.targetDuration - activeTimer.elapsedSeconds);
    progressPercent = activeTimer.targetDuration > 0
      ? Math.min(100, Math.round((activeTimer.elapsedSeconds / activeTimer.targetDuration) * 100))
      : 0;
  }

  const hours = Math.floor(displaySeconds / 3600);
  const minutes = Math.floor((displaySeconds % 3600) / 60);
  const seconds = displaySeconds % 60;

  const formattedTime = hours > 0
    ? `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
    : `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  return (
    <div className="fixed inset-0 z-50 bg-[var(--bg-base)] flex flex-col justify-between p-6 sm:p-12 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div
            className="w-3 h-3 rounded-full"
            style={{ backgroundColor: subject?.accentColor || 'var(--accent)' }}
          />
          <div>
            <div className="text-sm font-semibold text-[var(--text-main)]">
              {subject?.name || 'Academic Deep Work'}
            </div>
            {chapter && (
              <div className="text-xs text-[var(--text-muted)]">{chapter.name}</div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Ambient sound toggle */}
          <button
            onClick={() => toggleAmbientSound('rain')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
              ambientPlaying
                ? 'bg-[var(--accent)] text-white border-[var(--accent)]'
                : 'bg-[var(--bg-card)] text-[var(--text-muted)] border-[var(--border-subtle)] hover:text-[var(--text-main)]'
            }`}
          >
            <Headphones className="w-3.5 h-3.5" />
            <span>{ambientPlaying ? 'Rain Sound (On)' : 'Focus Noise'}</span>
          </button>

          {/* Exit Focus */}
          <button
            onClick={() => setFocusMode(false)}
            className="p-2 text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-card)] rounded-lg transition-colors"
            title="Exit Zen Focus Mode"
          >
            <Minimize2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Giant Central Timer */}
      <div className="flex flex-col items-center justify-center my-auto">
        {/* Mode Tag */}
        <div className="text-xs uppercase tracking-widest font-semibold text-[var(--text-dim)] mb-4">
          {activeTimer.mode === 'pomodoro'
            ? `${activeTimer.pomodoro.phase === 'focus' ? 'Focus Interval' : 'Rest Break'} · Cycle ${activeTimer.pomodoro.cycle}/${activeTimer.pomodoro.totalCycles}`
            : `${activeTimer.studyType} · ${activeTimer.mode.toUpperCase()}`}
        </div>

        {/* Display Timer */}
        <div className="text-7xl sm:text-9xl font-mono font-bold tracking-tighter text-[var(--text-main)] tabular-nums select-none mb-6">
          {formattedTime}
        </div>

        {/* Circular / Linear Progress Indicator */}
        <div className="w-64 sm:w-80 h-1.5 bg-[var(--bg-card)] rounded-full overflow-hidden mb-8">
          <div
            className="h-full bg-[var(--accent)] transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Active Task (if specified) */}
        {activeTimer.taskTitle && (
          <div className="max-w-md text-center text-xs text-[var(--text-muted)] bg-[var(--bg-card)] px-4 py-2 rounded-xl border border-[var(--border-subtle)] mb-8">
            <span className="font-semibold text-[var(--text-main)]">Focusing on:</span>{' '}
            {activeTimer.taskTitle}
          </div>
        )}

        {/* Minimal Controls */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => adjustTimerTime(-300)}
            className="p-2.5 rounded-xl bg-[var(--bg-card)] text-[var(--text-muted)] hover:text-[var(--text-main)] border border-[var(--border-subtle)] transition-colors"
            title="Subtract 5 minutes"
          >
            <Minus className="w-4 h-4" />
          </button>

          {activeTimer.status === 'running' ? (
            <button
              onClick={pauseTimer}
              className="p-4 rounded-2xl bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 active:scale-95 transition-all shadow-lg shadow-[var(--accent)]/20"
              title="Pause Session"
            >
              <Pause className="w-7 h-7" />
            </button>
          ) : (
            <button
              onClick={resumeTimer}
              className="p-4 rounded-2xl bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 active:scale-95 transition-all shadow-lg shadow-[var(--accent)]/20"
              title="Resume Session"
            >
              <Play className="w-7 h-7 fill-current ml-0.5" />
            </button>
          )}

          <button
            onClick={() => adjustTimerTime(300)}
            className="p-2.5 rounded-xl bg-[var(--bg-card)] text-[var(--text-muted)] hover:text-[var(--text-main)] border border-[var(--border-subtle)] transition-colors"
            title="Add 5 minutes"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {/* Bottom Actions */}
        <div className="flex items-center gap-3 mt-6">
          <button
            onClick={() => {
              finishTimerSession();
              setFocusMode(false);
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20 transition-colors"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Finish & Record</span>
          </button>

          <button
            onClick={() => {
              cancelTimerSession();
              setFocusMode(false);
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-medium text-[var(--text-dim)] hover:text-red-400 transition-colors"
          >
            <span>Cancel</span>
          </button>
        </div>
      </div>

      {/* Footer Info */}
      <div className="text-center text-[11px] text-[var(--text-dim)]">
        Press <kbd className="px-1.5 py-0.5 font-mono bg-[var(--bg-card)] border border-[var(--border-subtle)] rounded">Esc</kbd> to exit Focus Mode
      </div>
    </div>
  );
};
