import React, { useState } from 'react';
import {
  Search,
  Plus,
  Headphones,
  Bell,
  Maximize2,
  Trophy,
  Flame,
  CheckCircle2,
  Trash2,
  X,
  Volume2,
  VolumeX,
  User,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';
import { BrandLogo } from './BrandLogo';

interface HeaderProps {
  activeView: string;
  onNavigate: (view: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ activeView, onNavigate }) => {
  const {
    profile,
    streakData,
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    clearNotification,
    setSearchOpen,
    setQuickActionOpen,
    setFocusMode,
    ambientPlaying,
    toggleAmbientSound,
    settings,
    updateSettings,
    setAmbientVolume,
  } = useStudium();

  const [isNotifDropdownOpen, setIsNotifDropdownOpen] = useState(false);
  const [isAudioDropdownOpen, setIsAudioDropdownOpen] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  const viewTitles: Record<string, string> = {
    dashboard: 'Dashboard',
    timer: 'Study Timer',
    pomodoro: 'Pomodoro Engine',
    stopwatch: 'Stopwatch Lab',
    subjects: 'Subject Tracking',
    chapters: 'Chapter Progress',
    tasks: 'Task Manager',
    notes: 'Academic Notes',
    planner: 'Study Planner',
    exams: 'Exam Tracker',
    revision: 'Spaced Revision',
    analytics: 'Analytics & Insights',
    heatmap: 'Study Heatmap',
    achievements: 'Achievements',
    leaderboard: 'Leaderboard & League',
    reports: 'Study Reports',
    profile: 'Student Profile',
    settings: 'Personal Settings',
    admin: 'Platform Management',
  };

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between px-4 lg:px-8 py-3 bg-[var(--bg-surface)] border-b border-[var(--border-subtle)] backdrop-blur-md">
      {/* Zone 1: Contextual Breadcrumb & Title */}
      <div className="flex items-center gap-3 min-w-0">
        <div className="flex items-center gap-2 text-sm text-[var(--text-muted)]">
          <BrandLogo inverse className="h-7 w-auto hidden sm:block" />
          <span className="hidden sm:inline" aria-hidden="true">/</span>
          <span className="font-medium text-[var(--text-main)] truncate">
            {viewTitles[activeView] || 'Overview'}
          </span>
        </div>

        {/* Level badge */}
        <button
          onClick={() => onNavigate('profile')}
          className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-md bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--accent)] hover:border-[var(--border-active)] transition-colors whitespace-nowrap"
          title="Student Level & XP"
        >
          <span className="text-[10px] tracking-wider text-[var(--text-muted)]">LVL</span>
          <span className="tabular-nums font-bold">{profile.level}</span>
        </button>

        {/* Streak pill */}
        <button
          onClick={() => onNavigate('heatmap')}
          className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-md bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/15 transition-colors whitespace-nowrap"
          title="Current Study Streak"
        >
          <Flame className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
          <span className="tabular-nums font-bold">{streakData.currentStreak}d</span>
        </button>
      </div>

      {/* Zone 2: Global Search Trigger */}
      <div className="hidden lg:flex items-center mx-4 flex-1 max-w-md">
        <button
          onClick={() => setSearchOpen(true)}
          className="w-full flex items-center justify-between px-3.5 py-1.5 text-xs text-[var(--text-muted)] bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] border border-[var(--border-subtle)] hover:border-[var(--border-active)] rounded-lg transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <Search className="w-3.5 h-3.5 text-[var(--text-dim)]" />
            <span>Search subjects, chapters, notes, tasks...</span>
          </div>
          <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono bg-[var(--bg-base)] text-[var(--text-dim)] border border-[var(--border-subtle)] rounded">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Zone 3: Actions & Quick Tools */}
      <div className="flex items-center gap-2">
        {/* Mobile Search button */}
        <button
          onClick={() => setSearchOpen(true)}
          className="lg:hidden p-2 text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-card)] rounded-lg transition-colors"
          title="Search (Ctrl+K)"
        >
          <Search className="w-4 h-4" />
        </button>

        {/* Quick Launch Action Button */}
        <button
          onClick={() => setQuickActionOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[var(--accent-contrast)] bg-[var(--accent)] hover:opacity-90 active:scale-95 rounded-lg shadow-sm transition-all whitespace-nowrap"
          title="Quick Start Timer or Add Item"
        >
          <Plus className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Quick Action</span>
        </button>

        {/* Fullscreen Zen Focus Mode */}
        <button
          onClick={() => setFocusMode(true)}
          className="p-2 text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-card)] rounded-lg transition-colors"
          title="Enter Zen Focus Mode"
        >
          <Maximize2 className="w-4 h-4" />
        </button>

        {/* Ambient Focus Audio Menu */}
        <div className="relative">
          <button
            onClick={() => {
              setIsAudioDropdownOpen(!isAudioDropdownOpen);
              setIsNotifDropdownOpen(false);
            }}
            className={`p-2 rounded-lg transition-colors ${
              ambientPlaying
                ? 'text-[var(--accent)] bg-[var(--accent-glow)]'
                : 'text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-card)]'
            }`}
            title="Ambient Study Audio"
          >
            <Headphones className="w-4 h-4" />
          </button>

          {isAudioDropdownOpen && (
            <div className="absolute right-0 mt-2 w-72 p-3 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-xl shadow-xl z-50 animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-[var(--border-subtle)]">
                <span className="text-xs font-semibold text-[var(--text-main)]">Focus Soundscapes</span>
                <span className="text-[10px] text-[var(--text-muted)]">Web Audio Synthesizer</span>
              </div>

              <div className="space-y-1 mb-3">
                {[
                  { id: 'rain', label: 'Lofi Soft Rain', desc: 'Relaxing precipitation filter' },
                  { id: 'whitenoise', label: 'Deep White Noise', desc: 'Uniform mask for vocal chatter' },
                  { id: 'binaural', label: 'Binaural Alpha (40Hz)', desc: 'Stereo focus wave frequencies' },
                  { id: 'drone', label: 'Warm Ambient Drone', desc: 'Resonant harmonic chord' },
                ].map((sound) => {
                  const isCur = ambientPlaying === sound.id;
                  return (
                    <button
                      key={sound.id}
                      onClick={() => toggleAmbientSound(sound.id as 'rain' | 'whitenoise' | 'binaural' | 'drone')}
                      className={`w-full text-left p-2 rounded-lg text-xs transition-colors flex items-center justify-between ${
                        isCur
                          ? 'bg-[var(--accent)] text-white font-medium'
                          : 'hover:bg-[var(--bg-card)] text-[var(--text-main)]'
                      }`}
                    >
                      <div>
                        <div className="font-medium">{sound.label}</div>
                        <div className={`text-[10px] ${isCur ? 'text-white/80' : 'text-[var(--text-muted)]'}`}>
                          {sound.desc}
                        </div>
                      </div>
                      {isCur && <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded">Active</span>}
                    </button>
                  );
                })}
              </div>

              {/* Volume Slider */}
              <div className="pt-2 border-t border-[var(--border-subtle)]">
                <div className="flex items-center justify-between text-[11px] text-[var(--text-muted)] mb-1">
                  <span>Volume</span>
                  <span>{Math.round(settings.masterVolume * 100)}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <VolumeX className="w-3.5 h-3.5 text-[var(--text-dim)]" />
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={settings.masterVolume}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      updateSettings({ masterVolume: val });
                      setAmbientVolume(val * 0.4);
                    }}
                    className="w-full h-1 bg-[var(--bg-card)] accent-[var(--accent)] rounded-lg cursor-pointer"
                  />
                  <Volume2 className="w-3.5 h-3.5 text-[var(--text-dim)]" />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Notifications Dropdown */}
        <div className="relative">
          <button
            onClick={() => {
              setIsNotifDropdownOpen(!isNotifDropdownOpen);
              setIsAudioDropdownOpen(false);
            }}
            className="relative p-2 text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-card)] rounded-lg transition-colors"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-500" />
            )}
          </button>

          {isNotifDropdownOpen && (
            <div className="absolute right-0 mt-2 w-80 max-h-96 overflow-y-auto p-3 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-xl shadow-xl z-50">
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-[var(--border-subtle)]">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-semibold text-[var(--text-main)]">Notifications</span>
                  {unreadCount > 0 && (
                    <span className="text-[10px] px-1.5 py-0.2 text-emerald-400 bg-emerald-500/10 rounded font-mono">
                      {unreadCount} new
                    </span>
                  )}
                </div>
                {unreadCount > 0 && (
                  <button
                    onClick={markAllNotificationsAsRead}
                    className="text-[11px] text-[var(--accent)] hover:underline"
                  >
                    Mark all read
                  </button>
                )}
              </div>

              {notifications.length === 0 ? (
                <div className="text-center py-6 text-xs text-[var(--text-muted)]">
                  No notifications
                </div>
              ) : (
                <div className="space-y-2">
                  {notifications.slice(0, 8).map((notif) => (
                    <div
                      key={notif.id}
                      onClick={() => markNotificationAsRead(notif.id)}
                      className={`p-2.5 rounded-lg text-xs border transition-colors cursor-pointer ${
                        notif.read
                          ? 'bg-[var(--bg-card)]/50 border-transparent text-[var(--text-muted)]'
                          : 'bg-[var(--bg-card)] border-[var(--border-subtle)] text-[var(--text-main)]'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <span className="font-semibold text-xs leading-snug">{notif.title}</span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            clearNotification(notif.id);
                          }}
                          className="text-[var(--text-dim)] hover:text-red-400"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                      <p className="mt-1 text-[11px] text-[var(--text-muted)] leading-relaxed">
                        {notif.message}
                      </p>
                      <div className="mt-1.5 text-[9px] text-[var(--text-dim)]">
                        {new Date(notif.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* User Profile Mini Trigger */}
        <button
          onClick={() => onNavigate('profile')}
          className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-lg hover:bg-[var(--bg-card)] transition-colors"
          title="Open Profile"
        >
          {profile.avatar ? <img src={profile.avatar} alt={profile.name} className="w-7 h-7 rounded-full object-cover border border-[var(--border-subtle)]" referrerPolicy="no-referrer" /> : <span className="w-7 h-7 rounded-full bg-[var(--bg-card)] border border-[var(--border-subtle)] flex items-center justify-center"><User className="w-3.5 h-3.5 text-[var(--text-dim)]" /></span>}
          <span className="text-xs font-medium text-[var(--text-main)] hidden xl:inline max-w-[100px] truncate">
            {profile.name}
          </span>
        </button>
      </div>
    </header>
  );
};
