import React, { useState, useMemo } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  X,
  Plus,
  Minus,
  Maximize2,
  Filter,
  Search,
  Clock,
  Flame,
  BookOpen,
  BookmarkCheck,
  Tag,
  Trash2,
  Sliders,
  ChevronDown,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';
import { TimerMode, StudyType, Difficulty, StudySession } from '../../types';

export const TimerView: React.FC = () => {
  const {
    activeTimer,
    startTimer,
    pauseTimer,
    resumeTimer,
    resetTimer,
    finishTimerSession,
    cancelTimerSession,
    adjustTimerTime,
    setFocusMode,
    subjects,
    chapters,
    sessions,
    deleteSession,
  } = useStudium();

  // Mode and preset selection
  const [selectedPresetMinutes, setSelectedPresetMinutes] = useState<number>(25);
  const [customMinutesInput, setCustomMinutesInput] = useState<string>('45');
  const [activeTab, setActiveTab] = useState<'timer' | 'history'>('timer');

  // History search and filter state
  const [historySearch, setHistorySearch] = useState('');
  const [historySubjectFilter, setHistorySubjectFilter] = useState('all');
  const [historyTypeFilter, setHistoryTypeFilter] = useState('all');
  const [historySort, setHistorySort] = useState<'newest' | 'longest' | 'shortest'>('newest');

  // Timer setup form state
  const [setupSubjectId, setSetupSubjectId] = useState(activeTimer.subjectId || subjects[0]?.id || '');
  const [setupChapterId, setSetupChapterId] = useState<string>(activeTimer.chapterId || '');
  const [setupStudyType, setSetupStudyType] = useState<StudyType>(activeTimer.studyType || 'Problem Solving');
  const [setupDifficulty, setSetupDifficulty] = useState<Difficulty>(activeTimer.difficulty || 'Medium');
  const [setupTaskTitle, setSetupTaskTitle] = useState(activeTimer.taskTitle || '');
  const [setupNote, setSetupNote] = useState(activeTimer.note || '');
  const [setupTag, setSetupTag] = useState('#deepwork');

  // Filter chapters by selected subject
  const availableChapters = useMemo(() => {
    return chapters.filter(c => c.subjectId === setupSubjectId);
  }, [chapters, setupSubjectId]);

  // Timer displays
  let displaySeconds = 0;
  let progressPct = 0;

  if (activeTimer.mode === 'countup') {
    displaySeconds = activeTimer.elapsedSeconds;
    progressPct = Math.min(100, (displaySeconds % 3600) / 36);
  } else {
    displaySeconds = Math.max(0, activeTimer.targetDuration - activeTimer.elapsedSeconds);
    progressPct = activeTimer.targetDuration > 0
      ? Math.min(100, Math.round((activeTimer.elapsedSeconds / activeTimer.targetDuration) * 100))
      : 0;
  }

  const hours = Math.floor(displaySeconds / 3600);
  const minutes = Math.floor((displaySeconds % 3600) / 60);
  const seconds = displaySeconds % 60;
  const formattedTime = hours > 0
    ? `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
    : `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const handleStartSession = () => {
    startTimer({
      subjectId: setupSubjectId,
      chapterId: setupChapterId || undefined,
      studyType: setupStudyType,
      difficulty: setupDifficulty,
      taskTitle: setupTaskTitle,
      note: setupNote,
      tags: [setupTag],
    });
  };

  const handleApplyPreset = (minutes: number, mode: TimerMode = 'countdown') => {
    setSelectedPresetMinutes(minutes);
    startTimer({
      mode,
      targetDuration: minutes * 60,
      elapsedSeconds: 0,
      subjectId: setupSubjectId,
      chapterId: setupChapterId || undefined,
      studyType: setupStudyType,
      difficulty: setupDifficulty,
      taskTitle: setupTaskTitle,
      note: setupNote,
      tags: [setupTag],
    });
  };

  // Filtered session history
  const filteredSessions = useMemo(() => {
    return sessions
      .filter((s) => {
        if (historySubjectFilter !== 'all' && s.subjectId !== historySubjectFilter) return false;
        if (historyTypeFilter !== 'all' && s.studyType !== historyTypeFilter) return false;
        if (historySearch.trim()) {
          const q = historySearch.toLowerCase();
          const subjName = subjects.find(sub => sub.id === s.subjectId)?.name.toLowerCase() || '';
          const matchNote = s.note?.toLowerCase().includes(q) || false;
          const matchTask = s.taskTitle?.toLowerCase().includes(q) || false;
          const matchTag = s.tags.some(t => t.toLowerCase().includes(q));
          if (!subjName.includes(q) && !matchNote && !matchTask && !matchTag) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (historySort === 'longest') return b.duration - a.duration;
        if (historySort === 'shortest') return a.duration - b.duration;
        return new Date(b.startTime).getTime() - new Date(a.startTime).getTime();
      });
  }, [sessions, historySubjectFilter, historyTypeFilter, historySearch, historySort, subjects]);

  const activeSubject = subjects.find(s => s.id === activeTimer.subjectId);
  const activeChapter = chapters.find(c => c.id === activeTimer.chapterId);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto">
      {/* View Mode Switcher Header */}
      <div className="flex items-center justify-between border-b border-[var(--border-subtle)] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
            Academic Study Timer
          </h1>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Precision wall-clock timing engine with automatic streak and syllabus updates.
          </p>
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-xl text-xs">
          <button
            onClick={() => setActiveTab('timer')}
            className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
              activeTab === 'timer'
                ? 'bg-[var(--accent)] text-[var(--accent-contrast)] shadow-xs'
                : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
            }`}
          >
            Timer Engine
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
              activeTab === 'history'
                ? 'bg-[var(--accent)] text-[var(--accent-contrast)] shadow-xs'
                : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
            }`}
          >
            Session History ({sessions.length})
          </button>
        </div>
      </div>

      {activeTab === 'timer' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Timer Dial & Controls */}
          <div className="lg:col-span-7 flex flex-col items-center justify-center p-6 sm:p-10 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs relative">
            {/* Top row indicators */}
            <div className="w-full flex items-center justify-between text-xs text-[var(--text-muted)] mb-6">
              <div className="flex items-center gap-2">
                <div
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: activeSubject?.accentColor || 'var(--accent)' }}
                />
                <span className="font-semibold text-[var(--text-main)]">
                  {activeSubject?.name || 'General Study'}
                </span>
                {activeChapter && (
                  <span className="text-[11px] text-[var(--text-dim)] truncate max-w-[150px]">
                    · {activeChapter.name}
                  </span>
                )}
              </div>

              <button
                onClick={() => setFocusMode(true)}
                className="flex items-center gap-1 text-[11px] text-[var(--accent)] hover:underline"
                title="Zen Fullscreen"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>Zen Focus</span>
              </button>
            </div>

            {/* Timer Mode Pills */}
            <div className="flex items-center gap-1.5 p-1 bg-[var(--bg-card)] rounded-xl border border-[var(--border-subtle)] mb-6 text-xs">
              {(['countdown', 'countup', 'deepwork'] as TimerMode[]).map((mode) => (
                <button
                  key={mode}
                  onClick={() => {
                    if (activeTimer.status === 'idle') {
                      const dur = mode === 'deepwork' ? 90 * 60 : 25 * 60;
                      startTimer({ mode, targetDuration: dur, elapsedSeconds: 0 });
                    }
                  }}
                  className={`px-3 py-1 rounded-lg capitalize transition-colors ${
                    activeTimer.mode === mode
                      ? 'bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold'
                      : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
                  }`}
                >
                  {mode === 'deepwork' ? 'Deep Work (90m)' : mode}
                </button>
              ))}
            </div>

            {/* Massive Chronometer Display */}
            <div className="text-6xl sm:text-8xl font-mono font-bold tracking-tight text-[var(--text-main)] tabular-nums select-none mb-6">
              {formattedTime}
            </div>

            {/* Linear Progress Bar */}
            <div className="w-full max-w-md h-2 bg-[var(--bg-card)] rounded-full overflow-hidden mb-6">
              <div
                className="h-full bg-[var(--accent)] transition-all duration-300"
                style={{ width: `${progressPct}%` }}
              />
            </div>

            {/* Primary Running Controls */}
            <div className="flex items-center gap-3 mb-6">
              {/* Subtract 5m */}
              <button
                onClick={() => adjustTimerTime(-300)}
                className="p-3 rounded-xl bg-[var(--bg-card)] text-[var(--text-muted)] hover:text-[var(--text-main)] border border-[var(--border-subtle)] transition-colors"
                title="Subtract 5 mins"
              >
                <Minus className="w-4 h-4" />
              </button>

              {/* Start / Pause / Resume */}
              {activeTimer.status === 'idle' && (
                <button
                  onClick={handleStartSession}
                  className="px-8 py-3.5 rounded-2xl bg-[var(--accent)] text-[var(--accent-contrast)] font-bold text-sm hover:opacity-90 active:scale-95 transition-all shadow-md shadow-[var(--accent)]/20 flex items-center gap-2"
                >
                  <Play className="w-5 h-5 fill-current" />
                  <span>Start Session</span>
                </button>
              )}

              {activeTimer.status === 'running' && (
                <button
                  onClick={pauseTimer}
                  className="px-8 py-3.5 rounded-2xl bg-[var(--accent)] text-[var(--accent-contrast)] font-bold text-sm hover:opacity-90 active:scale-95 transition-all shadow-md shadow-[var(--accent)]/20 flex items-center gap-2"
                >
                  <Pause className="w-5 h-5" />
                  <span>Pause Timer</span>
                </button>
              )}

              {activeTimer.status === 'paused' && (
                <button
                  onClick={resumeTimer}
                  className="px-8 py-3.5 rounded-2xl bg-[var(--accent)] text-[var(--accent-contrast)] font-bold text-sm hover:opacity-90 active:scale-95 transition-all shadow-md shadow-[var(--accent)]/20 flex items-center gap-2"
                >
                  <Play className="w-5 h-5 fill-current" />
                  <span>Resume Timer</span>
                </button>
              )}

              {/* Add 5m */}
              <button
                onClick={() => adjustTimerTime(300)}
                className="p-3 rounded-xl bg-[var(--bg-card)] text-[var(--text-muted)] hover:text-[var(--text-main)] border border-[var(--border-subtle)] transition-colors"
                title="Add 5 mins"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Finish & Cancel Actions */}
            {activeTimer.status !== 'idle' && (
              <div className="flex items-center gap-3">
                <button
                  onClick={() => finishTimerSession(false)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20 transition-colors"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Complete & Record</span>
                </button>

                <button
                  onClick={resetTimer}
                  className="p-2 text-[var(--text-dim)] hover:text-[var(--text-main)] rounded-lg"
                  title="Reset timer"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>

                <button
                  onClick={cancelTimerSession}
                  className="px-3 py-2 rounded-xl text-xs text-[var(--text-dim)] hover:text-red-400 transition-colors"
                >
                  Cancel
                </button>
              </div>
            )}

            {/* Quick Preset Buttons */}
            <div className="w-full pt-6 mt-6 border-t border-[var(--border-subtle)]">
              <div className="text-[11px] font-semibold text-[var(--text-dim)] uppercase tracking-wider mb-2.5">
                Standard Interval Presets
              </div>
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                {[15, 25, 30, 45, 50, 60, 90].map((mins) => (
                  <button
                    key={mins}
                    onClick={() => handleApplyPreset(mins)}
                    className={`py-1.5 px-2 rounded-lg text-xs font-mono font-medium border transition-colors ${
                      selectedPresetMinutes === mins
                        ? 'bg-[var(--accent)] text-[var(--accent-contrast)] border-[var(--accent)]'
                        : 'bg-[var(--bg-card)] text-[var(--text-muted)] border-[var(--border-subtle)] hover:border-[var(--border-active)]'
                    }`}
                  >
                    {mins}m
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Session Metadata Setup */}
          <div className="lg:col-span-5 p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs space-y-4">
            <div>
              <h2 className="text-base font-bold text-[var(--text-main)]">Session Configuration</h2>
              <p className="text-xs text-[var(--text-muted)]">
                Link this session to subjects, chapters, and tasks to update syllabus analytics.
              </p>
            </div>

            {/* Subject Dropdown */}
            <div>
              <label className="block text-xs font-medium text-[var(--text-muted)] mb-1">
                Target Subject *
              </label>
              <select
                value={setupSubjectId}
                onChange={(e) => {
                  setSetupSubjectId(e.target.value);
                  setSetupChapterId('');
                }}
                className="w-full text-xs p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] focus:outline-none"
              >
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.priority} Priority)
                  </option>
                ))}
              </select>
            </div>

            {/* Chapter Dropdown */}
            <div>
              <label className="block text-xs font-medium text-[var(--text-muted)] mb-1">
                Syllabus Chapter (Optional)
              </label>
              <select
                value={setupChapterId}
                onChange={(e) => setSetupChapterId(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] focus:outline-none"
              >
                <option value="">-- No specific chapter --</option>
                {availableChapters.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.customProgress}% complete)
                  </option>
                ))}
              </select>
            </div>

            {/* Study Type Selection */}
            <div>
              <label className="block text-xs font-medium text-[var(--text-muted)] mb-1">
                Pedagogical Study Type
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {(
                  [
                    'Learning',
                    'Revision',
                    'Problem Solving',
                    'Practice',
                    'Reading',
                    'Lecture',
                    'Mock Test',
                    'Assignment',
                  ] as StudyType[]
                ).map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setSetupStudyType(type)}
                    className={`p-2 rounded-lg text-xs text-left transition-colors border ${
                      setupStudyType === type
                        ? 'bg-[var(--accent)] text-[var(--accent-contrast)] font-medium border-[var(--accent)]'
                        : 'bg-[var(--bg-card)] text-[var(--text-muted)] border-[var(--border-subtle)] hover:text-[var(--text-main)]'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            {/* Cognitive Difficulty */}
            <div>
              <label className="block text-xs font-medium text-[var(--text-muted)] mb-1">
                Cognitive Difficulty
              </label>
              <div className="grid grid-cols-4 gap-2">
                {(['Easy', 'Medium', 'Hard', 'Extreme'] as Difficulty[]).map((diff) => (
                  <button
                    key={diff}
                    type="button"
                    onClick={() => setSetupDifficulty(diff)}
                    className={`py-1.5 text-xs text-center rounded-lg border font-medium transition-colors ${
                      setupDifficulty === diff
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                        : 'bg-[var(--bg-card)] text-[var(--text-muted)] border-[var(--border-subtle)]'
                    }`}
                  >
                    {diff}
                  </button>
                ))}
              </div>
            </div>

            {/* Optional Task Title */}
            <div>
              <label className="block text-xs font-medium text-[var(--text-muted)] mb-1">
                Specific Task / Intended Objective
              </label>
              <input
                type="text"
                placeholder="e.g. Derive Maxwell-Ampere wave equation"
                value={setupTaskTitle}
                onChange={(e) => setSetupTaskTitle(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] focus:outline-none"
              />
            </div>

            {/* Tag Selection */}
            <div>
              <label className="block text-xs font-medium text-[var(--text-muted)] mb-1">
                Session Tag
              </label>
              <div className="flex gap-1.5 flex-wrap">
                {['#deepwork', '#exam', '#problem-solving', '#revision', '#practice', '#code'].map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setSetupTag(t)}
                    className={`px-2.5 py-1 rounded-md text-xs font-mono transition-colors ${
                      setupTag === t
                        ? 'bg-[var(--accent)] text-[var(--accent-contrast)] font-bold'
                        : 'bg-[var(--bg-card)] text-[var(--text-dim)] hover:text-[var(--text-main)]'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* History Tab */}
      {activeTab === 'history' && (
        <div className="space-y-4 p-5 sm:p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)]">
          {/* History Search & Filters */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pb-3 border-b border-[var(--border-subtle)]">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-[var(--text-dim)] absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search history by task, note, tag..."
                value={historySearch}
                onChange={(e) => setHistorySearch(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-2 rounded-lg bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={historySubjectFilter}
                onChange={(e) => setHistorySubjectFilter(e.target.value)}
                className="text-xs p-2 rounded-lg bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
              >
                <option value="all">All Subjects</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>

              <select
                value={historySort}
                onChange={(e) => setHistorySort(e.target.value as 'newest' | 'longest' | 'shortest')}
                className="text-xs p-2 rounded-lg bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
              >
                <option value="newest">Newest First</option>
                <option value="longest">Longest Duration</option>
                <option value="shortest">Shortest Duration</option>
              </select>
            </div>
          </div>

          {/* Session List Table */}
          {filteredSessions.length === 0 ? (
            <div className="text-center py-12 text-xs text-[var(--text-muted)]">
              No matching study sessions recorded.
            </div>
          ) : (
            <div className="space-y-2">
              {filteredSessions.map((s) => {
                const subj = subjects.find(sub => sub.id === s.subjectId);
                const chap = chapters.find(c => c.id === s.chapterId);
                const startFormatted = new Date(s.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                return (
                  <div
                    key={s.id}
                    className="p-3.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] flex items-center justify-between gap-4 text-xs group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: subj?.accentColor || 'var(--accent)' }}
                      />
                      <div className="min-w-0">
                        <div className="font-semibold text-[var(--text-main)] truncate">
                          {subj?.name || 'Subject'}{' '}
                          {chap && <span className="text-[var(--text-muted)] font-normal">/ {chap.name}</span>}
                        </div>
                        <div className="text-[11px] text-[var(--text-dim)] flex items-center gap-2 mt-0.5">
                          <span>{s.dateString} at {startFormatted}</span>
                          <span>·</span>
                          <span>{s.studyType}</span>
                          {s.taskTitle && (
                            <>
                              <span>·</span>
                              <span className="truncate max-w-[200px]">{s.taskTitle}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 shrink-0">
                      <div className="text-right">
                        <div className="font-mono font-bold text-[var(--text-main)] tabular-nums">
                          {Math.round(s.duration / 60)} mins
                        </div>
                        <div className="text-[10px] text-[var(--text-dim)] uppercase">
                          {s.timerMode}
                        </div>
                      </div>

                      <button
                        onClick={() => deleteSession(s.id)}
                        className="p-1.5 text-[var(--text-dim)] hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Delete record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
