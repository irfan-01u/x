import React, { useState, useMemo } from 'react';
import {
  BookmarkCheck,
  Plus,
  CheckCircle2,
  Clock,
  Calendar,
  AlertTriangle,
  RotateCcw,
  Edit3,
  Trash2,
  X,
  Play,
  CheckSquare,
  Square,
  Search,
  Filter,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';
import { Chapter, ChapterStatus, Priority } from '../../types';

interface ChaptersViewProps {
  selectedChapterId?: string;
  onNavigate: (view: string) => void;
}

export const ChaptersView: React.FC<ChaptersViewProps> = ({ selectedChapterId, onNavigate }) => {
  const {
    chapters,
    subjects,
    sessions,
    addChapter,
    updateChapter,
    deleteChapter,
    markChapterCompleted,
    toggleChecklistItem,
    addChecklistItem,
    removeChecklistItem,
    markChapterRevisionCompleted,
    startTimer,
  } = useStudium();

  const [activeChapterId, setActiveChapterId] = useState<string>(
    selectedChapterId || chapters[0]?.id || ''
  );
  const [subjectFilter, setSubjectFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingChapter, setEditingChapter] = useState<Chapter | null>(null);
  const [newTopicInput, setNewTopicInput] = useState('');

  // Form state
  const [formData, setFormData] = useState({
    subjectId: subjects[0]?.id || '',
    name: '',
    description: '',
    priority: 'High' as Priority,
    targetHours: 0,
    deadline: '',
    status: 'Not Started' as ChapterStatus,
    customProgress: 0,
    notes: '',
  });

  // Filtered chapters list
  const filteredChapters = useMemo(() => {
    return chapters.filter((c) => {
      if (subjectFilter !== 'all' && c.subjectId !== subjectFilter) return false;
      if (statusFilter !== 'all' && c.status !== statusFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        if (!c.name.toLowerCase().includes(q) && !c.description.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [chapters, subjectFilter, statusFilter, searchQuery]);

  const activeChapter = chapters.find(c => c.id === activeChapterId) || filteredChapters[0] || chapters[0];
  const activeSubject = subjects.find(s => s.id === activeChapter?.subjectId);

  // Chapter study session statistics
  const chapterStats = useMemo(() => {
    if (!activeChapter) return null;
    const cSessions = sessions.filter(s => s.chapterId === activeChapter.id);
    const totalMinutes = Math.round(cSessions.reduce((acc, s) => acc + s.duration, 0) / 60);
    const avgMinutes = cSessions.length > 0 ? Math.round(totalMinutes / cSessions.length) : 0;
    const lastSession = cSessions[0];

    // Deadline check
    let daysRemaining: number | null = null;
    let isOverdue = false;
    if (activeChapter.deadline) {
      const now = new Date().getTime();
      const dead = new Date(activeChapter.deadline).getTime();
      daysRemaining = Math.ceil((dead - now) / (1000 * 60 * 60 * 24));
      if (daysRemaining < 0) isOverdue = true;
    }

    return {
      totalMinutes,
      avgMinutes,
      sessionCount: cSessions.length,
      lastStudied: lastSession?.dateString || 'Never',
      daysRemaining,
      isOverdue,
      recentSessions: cSessions.slice(0, 4),
    };
  }, [activeChapter, sessions]);

  const handleOpenCreate = () => {
    setFormData({
      subjectId: subjects[0]?.id || '',
      name: '',
      description: '',
      priority: 'High',
      targetHours: 0,
      deadline: '',
      status: 'Not Started',
      customProgress: 0,
      notes: '',
    });
    setEditingChapter(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (chap: Chapter) => {
    setFormData({
      subjectId: chap.subjectId,
      name: chap.name,
      description: chap.description,
      priority: chap.priority,
      targetHours: chap.targetHours,
      deadline: chap.deadline || '',
      status: chap.status,
      customProgress: chap.customProgress,
      notes: chap.notes || '',
    });
    setEditingChapter(chap);
    setIsModalOpen(true);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    if (editingChapter) {
      updateChapter(editingChapter.id, formData);
    } else {
      addChapter({
        ...formData,
        checklist: [],
        order: chapters.length,
        revisionCount: 0,
        revisionRequired: false,
      });
    }
    setIsModalOpen(false);
  };

  const handleAddTopic = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTopicInput.trim() || !activeChapter) return;
    addChecklistItem(activeChapter.id, newTopicInput.trim());
    setNewTopicInput('');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[var(--border-subtle)] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
            Chapter & Syllabus Progress
          </h1>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Breakdown your syllabus into micro-topics with auto-progress tracking and revision intervals.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 shadow-xs transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Add Chapter</span>
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Search className="w-4 h-4 text-[var(--text-dim)] ml-2" />
          <input
            type="text"
            placeholder="Search chapters..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-transparent text-xs text-[var(--text-main)] placeholder-[var(--text-dim)] focus:outline-none w-48"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={subjectFilter}
            onChange={(e) => setSubjectFilter(e.target.value)}
            className="p-1.5 rounded-lg bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] text-xs"
          >
            <option value="all">All Subjects</option>
            {subjects.map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="p-1.5 rounded-lg bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] text-xs"
          >
            <option value="all">All Statuses</option>
            <option value="Not Started">Not Started</option>
            <option value="In Progress">In Progress</option>
            <option value="Revision">Revision</option>
            <option value="Completed">Completed</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Chapters Cards */}
        <div className="lg:col-span-5 space-y-2.5 max-h-[75vh] overflow-y-auto">
          {filteredChapters.length === 0 ? (
            <div className="p-8 text-center text-xs text-[var(--text-muted)] bg-[var(--bg-surface)] rounded-2xl">
              No matching chapters found.
            </div>
          ) : (
            filteredChapters.map((c) => {
              const isSelected = activeChapter?.id === c.id;
              const s = subjects.find(sub => sub.id === c.subjectId);
              const completedCount = c.checklist.filter(i => i.completed).length;

              return (
                <div
                  key={c.id}
                  onClick={() => setActiveChapterId(c.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[var(--bg-card)] border-[var(--accent)] shadow-sm'
                      : 'bg-[var(--bg-surface)] border-[var(--border-subtle)] hover:bg-[var(--bg-card)]'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-[10px] font-semibold text-[var(--text-muted)] uppercase tracking-wider">
                        {s?.name || 'Subject'}
                      </div>
                      <div className="font-bold text-sm text-[var(--text-main)] mt-0.5">{c.name}</div>
                    </div>
                    <span className="font-mono font-bold text-xs text-[var(--accent)] tabular-nums">
                      {c.customProgress}%
                    </span>
                  </div>

                  <p className="mt-1 text-xs text-[var(--text-dim)] line-clamp-1">{c.description}</p>

                  <div className="mt-3 w-full h-1.5 bg-[var(--bg-base)] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[var(--accent)] rounded-full transition-all"
                      style={{ width: `${c.customProgress}%` }}
                    />
                  </div>

                  <div className="mt-2.5 flex items-center justify-between text-[11px] text-[var(--text-dim)]">
                    <span>{c.checklist.length > 0 ? `${completedCount}/${c.checklist.length} subtopics` : 'No subtopics'}</span>
                    <span className="capitalize">{c.status}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Right Column: Active Chapter Detail & Subtopics Checklist */}
        {activeChapter && chapterStats && (
          <div className="lg:col-span-7 space-y-6">
            {/* Chapter Header Card */}
            <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <span className="text-xs font-semibold text-[var(--accent)] uppercase tracking-wider">
                    {activeSubject?.name || 'Subject'}
                  </span>
                  <h2 className="text-xl font-bold text-[var(--text-main)] mt-0.5">{activeChapter.name}</h2>
                  <p className="text-xs text-[var(--text-muted)] mt-1">{activeChapter.description}</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      startTimer({
                        subjectId: activeChapter.subjectId,
                        chapterId: activeChapter.id,
                        targetDuration: 25 * 60,
                        elapsedSeconds: 0,
                      });
                      onNavigate('timer');
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 transition-all"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Study Chapter</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => markChapterCompleted(activeChapter.id, activeChapter.status !== 'Completed')}
                    className="px-2.5 py-1.5 rounded-lg border border-[var(--border-subtle)] text-[11px] font-semibold hover:bg-[var(--bg-card)]"
                  >
                    {activeChapter.status === 'Completed' ? 'Mark In Progress' : 'Mark Completed'}
                  </button>

                  <button
                    onClick={() => handleOpenEdit(activeChapter)}
                    className="p-2 rounded-lg bg-[var(--bg-card)] text-[var(--text-muted)] hover:text-[var(--text-main)] border border-[var(--border-subtle)]"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Status and revision indicators */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                <div className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
                  <span className="text-[11px] text-[var(--text-muted)]">Time Logged</span>
                  <div className="mt-1 font-mono font-bold text-base text-[var(--text-main)]">
                    {Math.round(chapterStats.totalMinutes / 60)}h {chapterStats.totalMinutes % 60}m
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
                  <span className="text-[11px] text-[var(--text-muted)]">Progress</span>
                  <div className="mt-1 font-mono font-bold text-base text-[var(--accent)]">
                    {activeChapter.customProgress}%
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
                  <span className="text-[11px] text-[var(--text-muted)]">Revision Count</span>
                  <div className="mt-1 font-mono font-bold text-base text-purple-400">
                    {activeChapter.revisionCount}x
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
                  <span className="text-[11px] text-[var(--text-muted)]">Deadline</span>
                  <div className={`mt-1 font-mono font-bold text-xs ${chapterStats.isOverdue ? 'text-red-400' : 'text-amber-400'}`}>
                    {chapterStats.daysRemaining !== null
                      ? chapterStats.isOverdue
                        ? 'Overdue'
                        : `${chapterStats.daysRemaining}d remaining`
                      : 'None'}
                  </div>
                </div>
              </div>

              {/* Spaced Revision Trigger */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 text-xs">
                <div>
                  <span className="font-semibold text-purple-300">Spaced Repetition System</span>
                  <div className="text-[11px] text-[var(--text-dim)]">
                    {activeChapter.nextRevisionDate ? `Next due: ${activeChapter.nextRevisionDate}` : 'No revision scheduled'}
                  </div>
                </div>
                <button
                  onClick={() => markChapterRevisionCompleted(activeChapter.id)}
                  className="px-3 py-1.5 rounded-lg bg-purple-500/20 text-purple-300 hover:bg-purple-500/30 font-medium transition-colors"
                >
                  Mark Revision Done
                </button>
              </div>
            </div>

            {/* Subtopics Checklist with Automatic Progress Calculation */}
            <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-[var(--text-main)]">Chapter Topics (Optional)</h3>
                  <span className="text-xs text-[var(--text-muted)]">
                    Topics are optional. Add them only if you want detailed progress tracking.
                  </span>
                </div>
                <span className="font-mono text-xs font-bold text-[var(--text-dim)]">
                  {activeChapter.checklist.filter(i => i.completed).length}/{activeChapter.checklist.length} Completed
                </span>
              </div>

              <div className="space-y-2">
                {activeChapter.checklist.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => toggleChecklistItem(activeChapter.id, item.id)}
                    className={`flex items-center justify-between p-3 rounded-xl text-xs cursor-pointer border transition-colors ${
                      item.completed
                        ? 'bg-[var(--bg-card)]/40 border-transparent text-[var(--text-dim)] line-through'
                        : 'bg-[var(--bg-card)] border-[var(--border-subtle)] text-[var(--text-main)] hover:border-[var(--border-active)]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-4 h-4 rounded-md flex items-center justify-center shrink-0 border ${
                          item.completed
                            ? 'bg-[var(--accent)] border-[var(--accent)] text-[var(--accent-contrast)]'
                            : 'border-[var(--text-dim)]'
                        }`}
                      >
                        {item.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                      </div>
                      <span>{item.title}</span>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        removeChecklistItem(activeChapter.id, item.id);
                      }}
                      className="text-[var(--text-dim)] hover:text-red-400 p-1"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Add subtopic form */}
              <form onSubmit={handleAddTopic} className="flex gap-2 pt-2">
                <input
                  type="text"
                  placeholder="Add optional topic or theorem..."
                  value={newTopicInput}
                  onChange={(e) => setNewTopicInput(e.target.value)}
                  className="flex-1 text-xs px-3 py-2 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] placeholder-[var(--text-dim)] focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={!newTopicInput.trim()}
                  className="px-4 py-2 text-xs font-semibold rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 disabled:opacity-50"
                >
                  Add Topic
                </button>
              </form>
            </div>
          </div>
        )}
      </div>

      {/* Chapter Create/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-2xl shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-[var(--text-main)]">
                {editingChapter ? 'Edit Chapter' : 'Register Syllabus Chapter'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-[var(--text-dim)] hover:text-[var(--text-main)]">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveForm} className="space-y-3 text-xs">
              <div>
                <label className="block text-[var(--text-muted)] mb-1">Parent Subject</label>
                <select
                  value={formData.subjectId}
                  onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                >
                  {subjects.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[var(--text-muted)] mb-1">Chapter Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Wave Optics & Maxwell Equations"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                />
              </div>

              <div>
                <label className="block text-[var(--text-muted)] mb-1">Description</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Key concepts covered in this chapter..."
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[var(--text-muted)] mb-1">Target Hours</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={formData.targetHours}
                    onChange={(e) => setFormData({ ...formData, targetHours: parseInt(e.target.value) || 0 })}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                  />
                </div>

                <div>
                  <label className="block text-[var(--text-muted)] mb-1">Deadline Date</label>
                  <input
                    type="date"
                    value={formData.deadline}
                    onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[var(--border-subtle)]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-[var(--text-muted)] hover:bg-[var(--bg-card)]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold hover:opacity-90"
                >
                  Save Chapter
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
