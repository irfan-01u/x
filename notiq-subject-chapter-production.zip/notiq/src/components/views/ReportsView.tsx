import React, { useState, useMemo } from 'react';
import {
  FileBarChart2,
  Calendar,
  Clock,
  Printer,
  Download,
  Flame,
  Trophy,
  CheckCircle2,
  Award,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

export const ReportsView: React.FC = () => {
  const { sessions, subjects, streakData, profile, achievements } = useStudium();

  const [reportType, setReportType] = useState<'daily' | 'weekly' | 'monthly'>('weekly');

  const reportData = useMemo(() => {
    const now = new Date();
    let cutoff = new Date(now);
    if (reportType === 'daily') cutoff.setDate(now.getDate() - 1);
    if (reportType === 'weekly') cutoff.setDate(now.getDate() - 7);
    if (reportType === 'monthly') cutoff.setDate(now.getDate() - 30);

    const cutoffStr = cutoff.toISOString().slice(0, 10);
    const inRangeSessions = sessions.filter(s => s.dateString >= cutoffStr);

    const totalSeconds = inRangeSessions.reduce((acc, s) => acc + s.duration, 0);
    const totalMinutes = Math.round(totalSeconds / 60);
    const totalHours = Number((totalMinutes / 60).toFixed(1));

    const pomoCount = inRangeSessions.filter(s => s.timerMode === 'pomodoro').length;

    // By subject
    const subjectMap: Record<string, number> = {};
    inRangeSessions.forEach(s => {
      subjectMap[s.subjectId] = (subjectMap[s.subjectId] || 0) + s.duration / 60;
    });

    const subjectList = Object.entries(subjectMap).map(([id, mins]) => {
      const s = subjects.find(sub => sub.id === id);
      return {
        name: s?.name || 'Subject',
        minutes: Math.round(mins),
        hours: Number((mins / 60).toFixed(1)),
        percent: totalMinutes > 0 ? Math.round((mins / totalMinutes) * 100) : 0,
      };
    }).sort((a, b) => b.minutes - a.minutes);

    return {
      totalHours,
      totalMinutes,
      sessionCount: inRangeSessions.length,
      pomoCount,
      subjectList,
      generatedDate: now.toLocaleDateString(undefined, {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      }),
    };
  }, [sessions, reportType, subjects]);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[var(--border-subtle)] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
            Academic Performance Reports
          </h1>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Audit-grade summaries of your dedicated study time for parents, advisors, or personal ledgers.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex bg-[var(--bg-surface)] p-1 rounded-xl border border-[var(--border-subtle)] text-xs">
            {(['daily', 'weekly', 'monthly'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setReportType(t)}
                className={`px-3 py-1 rounded-lg capitalize transition-colors ${
                  reportType === t
                    ? 'bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold shadow-xs'
                    : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-[var(--bg-surface)] hover:bg-[var(--bg-card)] border border-[var(--border-subtle)] transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Print / PDF</span>
          </button>
        </div>
      </div>

      {/* Printable Report Document Card */}
      <div className="p-8 sm:p-10 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-sm space-y-6 print:bg-white print:text-black print:border-none">
        {/* Document Header */}
        <div className="flex items-start justify-between pb-6 border-b border-[var(--border-subtle)]">
          <div>
            <div className="text-xs font-extrabold tracking-widest text-[var(--accent)] uppercase">
              NOTIQ ACADEMIC REPORT
            </div>
            <h2 className="text-2xl font-extrabold text-[var(--text-main)] mt-1 capitalize">
              {reportType} Scholastic Statement
            </h2>
            <div className="text-xs text-[var(--text-dim)] mt-0.5">Generated {reportData.generatedDate}</div>
          </div>

          <div className="text-right text-xs text-[var(--text-muted)]">
            <div className="font-bold text-[var(--text-main)]">{profile.name}</div>
            <div>@{profile.username}</div>
            <div>Level {profile.level} Scholar</div>
          </div>
        </div>

        {/* Executive Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
            <span className="text-xs text-[var(--text-muted)]">Total Study Hours</span>
            <div className="mt-1 font-mono font-bold text-2xl text-[var(--text-main)]">
              {reportData.totalHours}h
            </div>
            <span className="text-[10px] text-[var(--text-dim)]">{reportData.totalMinutes} minutes total</span>
          </div>

          <div className="p-4 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
            <span className="text-xs text-[var(--text-muted)]">Total Sessions</span>
            <div className="mt-1 font-mono font-bold text-2xl text-emerald-400">
              {reportData.sessionCount}
            </div>
            <span className="text-[10px] text-[var(--text-dim)]">{reportData.pomoCount} Pomodoros</span>
          </div>

          <div className="p-4 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
            <span className="text-xs text-[var(--text-muted)]">Streak Preserved</span>
            <div className="mt-1 font-mono font-bold text-2xl text-amber-400">
              {streakData.currentStreak}d
            </div>
            <span className="text-[10px] text-[var(--text-dim)]">Consecutive active days</span>
          </div>

          <div className="p-4 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
            <span className="text-xs text-[var(--text-muted)]">League Standing</span>
            <div className="mt-1 font-mono font-bold text-2xl text-purple-400">
              No ranking yet
            </div>
            <span className="text-[10px] text-[var(--text-dim)]">Study to enter the leaderboard</span>
          </div>
        </div>

        {/* Subject Breakdown Table */}
        <div className="space-y-3 pt-2">
          <h3 className="text-sm font-bold text-[var(--text-main)]">Domain Allocation Statement</h3>

          <div className="border border-[var(--border-subtle)] rounded-xl overflow-hidden">
            <table className="w-full text-xs text-left">
              <thead className="bg-[var(--bg-card)] border-b border-[var(--border-subtle)] text-[var(--text-dim)]">
                <tr>
                  <th className="py-2.5 px-4 font-semibold">Academic Subject</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Minutes</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Hours</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Share</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--border-subtle)]">
                {reportData.subjectList.map((s) => (
                  <tr key={s.name} className="hover:bg-[var(--bg-card)]/40 transition-colors">
                    <td className="py-2.5 px-4 font-medium text-[var(--text-main)]">{s.name}</td>
                    <td className="py-2.5 px-4 text-right font-mono text-[var(--text-muted)]">{s.minutes}m</td>
                    <td className="py-2.5 px-4 text-right font-mono text-[var(--text-main)] font-bold">{s.hours}h</td>
                    <td className="py-2.5 px-4 text-right font-mono text-[var(--accent)] font-semibold">{s.percent}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Academic Integrity Verification */}
        <div className="pt-6 border-t border-[var(--border-subtle)] flex items-center justify-between text-xs text-[var(--text-dim)]">
          <span>Validated via NOTIQ Wall-Clock Verification Engine</span>
          <span>Status: Verified Authentic</span>
        </div>
      </div>
    </div>
  );
};
