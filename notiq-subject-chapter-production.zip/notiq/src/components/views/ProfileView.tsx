import React, { useEffect, useRef, useState } from 'react';
import {
  User,
  Flame,
  Trophy,
  Award,
  Sparkles,
  Clock,
  Shield,
  Edit3,
  Check,
  Eye,
  EyeOff,
  BookOpen,
  Camera,
  Trash2,
  ZoomIn,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

export const ProfileView: React.FC = () => {
  const { profile, updateProfile, streakData, sessions, achievements, subjects, dailyLeaderboard } = useStudium();

  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({ ...profile });
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [zoom, setZoom] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [savingAvatar, setSavingAvatar] = useState(false);
  const [avatarMessage, setAvatarMessage] = useState('');
  const [avatarError, setAvatarError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const previewImageRef = useRef<HTMLImageElement>(null);
  const cropRef = useRef<HTMLDivElement>(null);

  useEffect(() => () => { if (selectedImage) URL.revokeObjectURL(selectedImage); }, [selectedImage]);
  const chooseImage = (file?: File) => {
    setAvatarError(''); setAvatarMessage(''); if (!file) return;
    if (!['image/jpeg','image/png','image/webp'].includes(file.type)) return setAvatarError('Invalid file type. Use JPG, JPEG, PNG, or WEBP.');
    if (file.size > 5 * 1024 * 1024) return setAvatarError('File too large. Maximum size is 5MB.');
    if (selectedImage) URL.revokeObjectURL(selectedImage);
    setImageFile(file); setSelectedImage(URL.createObjectURL(file)); setZoom(1); setPosition({ x: 0, y: 0 });
  };
  const onPointerDown = (e: React.PointerEvent) => { if (!selectedImage) return; setDragging(true); setDragStart({ x: e.clientX-position.x, y: e.clientY-position.y }); (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); };
  const onPointerMove = (e: React.PointerEvent) => { if (dragging) setPosition({ x: e.clientX-dragStart.x, y: e.clientY-dragStart.y }); };
  const onPointerUp = () => setDragging(false);
  const uploadAvatar = async () => {
    if (!imageFile || !selectedImage || !previewImageRef.current || !cropRef.current) return;
    setSavingAvatar(true); setAvatarError(''); setAvatarMessage('Uploading...');
    try {
      const img=previewImageRef.current; await new Promise<void>((resolve,reject)=>{ if(img.complete) resolve(); else {img.onload=()=>resolve(); img.onerror=()=>reject(new Error('Image preview failed.'));} });
      const size=512, canvas=document.createElement('canvas'); canvas.width=size; canvas.height=size; const ctx=canvas.getContext('2d'); if(!ctx) throw new Error('Canvas is unavailable.');
      const box=cropRef.current.getBoundingClientRect(), scale=Math.max(size/img.naturalWidth,size/img.naturalHeight)*zoom, drawW=img.naturalWidth*scale, drawH=img.naturalHeight*scale, ratio=size/box.width;
      ctx.fillStyle='#111'; ctx.fillRect(0,0,size,size); ctx.drawImage(img,(size-drawW)/2+position.x*ratio,(size-drawH)/2+position.y*ratio,drawW,drawH);
      const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('Could not prepare image.')),'image/jpeg',0.9));
      const form=new FormData(); form.append('avatar',blob,'profile.jpg'); form.append('userId',profile.id); form.append('deviceId',profile.deviceId||profile.id);
      const res=await fetch('/api/platform/profile/avatar',{method:'POST',body:form}), data=await res.json().catch(()=>({})); if(!res.ok) throw new Error(data.error||'Upload failed.');
      setFormData(prev=>({...prev,avatar:data.avatarUrl})); updateProfile({avatar:data.avatarUrl}); setAvatarMessage('Upload successful'); if(selectedImage) URL.revokeObjectURL(selectedImage); setSelectedImage(null); setImageFile(null);
    } catch(err) { setAvatarError(err instanceof Error?err.message:'Upload failed.'); setAvatarMessage(''); } finally { setSavingAvatar(false); }
  };
  const removeAvatar = async () => {
    if(!profile.avatar || !window.confirm('Remove your profile picture?')) return;
    setSavingAvatar(true); setAvatarError(''); setAvatarMessage('Saving...');
    try {
      const res=await fetch('/api/platform/profile/avatar',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({userId:profile.id,deviceId:profile.deviceId||profile.id,avatar:profile.avatar})}), data=await res.json().catch(()=>({})); if(!res.ok) throw new Error(data.error||'Could not remove photo.');
      setFormData(prev=>({...prev,avatar:''})); updateProfile({avatar:''}); setAvatarMessage('Photo removed');
    } catch(err) { setAvatarError(err instanceof Error?err.message:'Could not remove photo.'); setAvatarMessage(''); } finally { setSavingAvatar(false); }
  };

  const totalStudyMinutes = Math.round(sessions.reduce((acc, s) => acc + s.duration, 0) / 60);
  const totalHours = (totalStudyMinutes / 60).toFixed(1);

  // Pinned achievements
  const pinnedAchievements = achievements.filter(a => profile.pinnedAchievementIds.includes(a.id));

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile(formData);
    setIsEditing(false);
  };

  const handleTogglePrivacy = (key: keyof typeof profile.privacy) => {
    updateProfile({
      privacy: {
        ...profile.privacy,
        [key]: !profile.privacy[key],
      },
    });
  };


  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl mx-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between border-b border-[var(--border-subtle)] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
            Student Academic Profile
          </h1>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Your scholastic passport, level milestones, pinned trophies, and privacy configuration.
          </p>
        </div>

        <button
          onClick={() => {
            if (isEditing) {
              setFormData({ ...profile });
              setIsEditing(false);
            } else {
              setIsEditing(true);
            }
          }}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[var(--bg-surface)] hover:bg-[var(--bg-card)] border border-[var(--border-subtle)] transition-colors"
        >
          <Edit3 className="w-4 h-4" />
          <span>{isEditing ? 'Cancel' : 'Edit Profile'}</span>
        </button>
      </div>

      {/* Main Profile Showcase Card */}
      <div className="p-6 sm:p-8 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 text-center sm:text-left">
          <div className="w-24 h-24 rounded-2xl border-2 border-[var(--accent)] shadow-md flex items-center justify-center bg-[var(--bg-card)]">
            {profile.avatar ? (
              <img src={profile.avatar} alt={profile.name} className="w-full h-full rounded-2xl object-cover" />
            ) : (
              <User className="w-10 h-10 text-[var(--text-dim)]" />
            )}
          </div>

          <div className="flex-1 space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-xl font-extrabold text-[var(--text-main)]">{profile.name}</h2>
                <div className="text-xs text-[var(--text-dim)] font-mono">@{profile.username}</div>
              </div>

              {/* Scholar Level Pill */}
              <div className="p-2 px-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] flex items-center gap-2 self-center sm:self-auto">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span className="text-xs font-bold text-[var(--text-main)]">Level {profile.level} Scholar</span>
                <span className="text-[10px] text-[var(--text-dim)] font-mono">({profile.xp.toLocaleString()} XP)</span>
              </div>
            </div>

            <p className="text-xs text-[var(--text-muted)] leading-relaxed max-w-2xl">
              {profile.bio}
            </p>

            <div className="pt-2 flex items-center gap-4 text-xs text-[var(--text-dim)] flex-wrap">
              <span>Goal: {profile.dailyGoalMinutes > 0 ? `${profile.dailyGoalMinutes / 60}h/day` : 'Not Set'}</span>
              <span>·</span>
              <span>Primary Exam: {profile.examDate || 'None scheduled'}</span>
              <span>·</span>
              <span>League: {streakData.currentStreak > 0 ? 'Active' : 'Not Ranked'}</span>
            </div>
          </div>
        </div>

        {/* Edit Form */}
        {isEditing && (
          <form onSubmit={handleSaveProfile} className="pt-4 border-t border-[var(--border-subtle)] space-y-4 text-xs animate-in fade-in duration-150">
            <div className="font-bold text-sm text-[var(--text-main)]">Edit Profile Details</div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[var(--text-muted)] mb-1">Display Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                />
              </div>

              <div>
                <label className="block text-[var(--text-muted)] mb-1">Username Handle</label>
                <input
                  type="text"
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-[var(--text-muted)] mb-1">Academic Bio</label>
              <textarea
                rows={2}
                value={formData.bio}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] resize-none"
              />
            </div>

            <div className="pt-1">
              <label className="block text-[var(--text-muted)] mb-2">Profile Picture</label>
              <div className="flex flex-wrap items-center gap-3">
                <div className="w-16 h-16 rounded-full overflow-hidden border border-[var(--border-subtle)] bg-[var(--bg-card)] flex items-center justify-center shrink-0">{formData.avatar ? <img src={formData.avatar} alt="Current profile" className="w-full h-full object-cover" /> : <User className="w-7 h-7 text-[var(--text-dim)]" />}</div>
                <div className="flex gap-2 flex-wrap">
                  <button type="button" onClick={()=>fileInputRef.current?.click()} className="px-3 py-2 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] font-semibold flex items-center gap-2"><Camera className="w-4 h-4"/> Upload / Change Photo</button>
                  {formData.avatar && <button type="button" onClick={removeAvatar} disabled={savingAvatar} className="px-3 py-2 rounded-xl border border-red-500/30 text-red-400 font-semibold flex items-center gap-2"><Trash2 className="w-4 h-4"/> Remove Photo</button>}
                </div>
                <input ref={fileInputRef} type="file" className="hidden" accept="image/jpeg,image/png,image/webp" capture="environment" onChange={e=>chooseImage(e.target.files?.[0])}/>
              </div>
              <p className="text-[11px] text-[var(--text-dim)] mt-2">JPG, JPEG, PNG or WEBP · max 5MB</p>
              {avatarError && <p className="text-[11px] text-red-400 mt-2">{avatarError}</p>}
              {avatarMessage && <p className="text-[11px] text-emerald-400 mt-2">{avatarMessage}</p>}
              {selectedImage && <div className="mt-4 p-3 rounded-2xl bg-[var(--bg-card)] border border-[var(--border-subtle)]"><div className="flex items-center gap-2 mb-3 text-xs font-semibold"><ZoomIn className="w-4 h-4"/> Crop & Preview</div><div className="flex flex-col sm:flex-row gap-4 items-center"><div ref={cropRef} className="relative w-56 h-56 rounded-full overflow-hidden bg-black touch-none cursor-grab active:cursor-grabbing" onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp} onPointerCancel={onPointerUp}><img ref={previewImageRef} src={selectedImage} alt="Preview" className="absolute left-1/2 top-1/2 max-w-none select-none pointer-events-none" style={{transform:`translate(calc(-50% + ${position.x}px), calc(-50% + ${position.y}px)) scale(${zoom})`}}/></div><div className="w-full sm:max-w-xs space-y-3"><label className="text-[11px] text-[var(--text-muted)] block">Zoom</label><input type="range" min="1" max="3" step="0.05" value={zoom} onChange={e=>setZoom(Number(e.target.value))} className="w-full"/><div className="flex gap-2"><button type="button" onClick={()=>{setSelectedImage(null);setImageFile(null)}} className="px-3 py-2 rounded-xl border border-[var(--border-subtle)]">Cancel</button><button type="button" onClick={uploadAvatar} disabled={savingAvatar} className="px-3 py-2 rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold">{savingAvatar?'Uploading...':'Save / Apply'}</button></div></div></div></div>}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 rounded-xl text-[var(--text-muted)] hover:bg-[var(--bg-card)]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold"
              >
                Save Changes
              </button>
            </div>
          </form>
        )}

        {/* Academic Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="p-3.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
            <span className="text-[11px] text-[var(--text-muted)]">All-Time Study</span>
            <div className="mt-1 font-mono font-bold text-xl text-[var(--text-main)]">
              {totalHours}h
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
            <span className="text-[11px] text-[var(--text-muted)]">Active Streak</span>
            <div className="mt-1 font-mono font-bold text-xl text-amber-400">
              {streakData.currentStreak} Days
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
            <span className="text-[11px] text-[var(--text-muted)]">Total Sessions</span>
            <div className="mt-1 font-mono font-bold text-xl text-emerald-400">
              {sessions.length}
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
            <span className="text-[11px] text-[var(--text-muted)]">League Rank</span>
            <div className="mt-1 font-mono font-bold text-xl text-purple-400">
              {dailyLeaderboard?.currentUser?.rank ? `#${dailyLeaderboard.currentUser.rank}` : 'No ranking yet'}
            </div>
          </div>
        </div>
      </div>

      {/* Pinned Showcase Badges (3 Pinned) */}
      <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-[var(--text-main)]">Featured Trophy Showcase</h3>
          <span className="text-xs text-[var(--text-dim)]">{pinnedAchievements.length} / 3 pinned</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {pinnedAchievements.map((ach) => (
            <div
              key={ach.id}
              className="p-4 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold shrink-0">
                <Award className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="font-bold text-xs text-[var(--text-main)] truncate">{ach.title}</div>
                <div className="text-[10px] text-[var(--text-dim)] truncate">{ach.description}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Privacy Settings Panel */}
      <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
        <h3 className="text-base font-bold text-[var(--text-main)]">Profile Visibility & Privacy Controls</h3>

        <div className="space-y-3 text-xs">
          <label className="flex items-center justify-between p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] cursor-pointer">
            <div>
              <div className="font-semibold text-[var(--text-main)]">Public Profile Visibility</div>
              <div className="text-[11px] text-[var(--text-dim)]">Allow other cohort students to view your public achievements and stats</div>
            </div>
            <input
              type="checkbox"
              checked={profile.privacy.isPublic}
              onChange={() => handleTogglePrivacy('isPublic')}
              className="accent-[var(--accent)] w-4 h-4"
            />
          </label>

          <label className="flex items-center justify-between p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] cursor-pointer">
            <div>
              <div className="font-semibold text-[var(--text-main)]">Display on Global Leaderboard</div>
              <div className="text-[11px] text-[var(--text-dim)]">Show your study time and rank in weekly leagues</div>
            </div>
            <input
              type="checkbox"
              checked={profile.privacy.showOnLeaderboard}
              onChange={() => handleTogglePrivacy('showOnLeaderboard')}
              className="accent-[var(--accent)] w-4 h-4"
            />
          </label>

          <label className="flex items-center justify-between p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] cursor-pointer">
            <div>
              <div className="font-semibold text-[var(--text-main)]">Show Real Name on Podium</div>
              <div className="text-[11px] text-[var(--text-dim)]">Use your full name instead of only your username handle</div>
            </div>
            <input
              type="checkbox"
              checked={profile.privacy.showRealName}
              onChange={() => handleTogglePrivacy('showRealName')}
              className="accent-[var(--accent)] w-4 h-4"
            />
          </label>
        </div>
      </div>
    </div>
  );
};
