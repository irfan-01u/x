import React, { useState } from 'react';
import {
  Settings,
  Palette,
  Volume2,
  VolumeX,
  Clock,
  Shield,
  Download,
  Upload,
  Trash2,
  Check,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

export const SettingsView: React.FC = () => {
  const {
    settings,
    updateSettings,
    exportDataJSON,
    importDataJSON,
    resetAllData,
  } = useStudium();

  const [importStatus, setImportStatus] = useState<string | null>(null);

  const handleDownloadJSON = () => {
    const jsonStr = exportDataJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `notiq_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const success = importDataJSON(text);
      if (success) {
        setImportStatus('Academic data restored successfully!');
      } else {
        setImportStatus('Invalid backup JSON format.');
      }
      setTimeout(() => setImportStatus(null), 3000);
    };
    reader.readAsText(file);
  };

  const handleResetData = () => {
    if (confirm('Are you sure you want to reset all data to default? This will clear sessions and custom notes.')) {
      resetAllData();
      alert('NOTIQ data reset to factory state.');
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="border-b border-[var(--border-subtle)] pb-4">
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
          Personal Preferences & System Settings
        </h1>
        <p className="text-xs text-[var(--text-muted)] mt-0.5">
          Customize UI aesthetics, soundscapes, timer defaults, accessibility, and local database backup.
        </p>
      </div>

      {/* Appearance & Themes */}
      <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
        <div className="flex items-center gap-2">
          <Palette className="w-5 h-5 text-[var(--accent)]" />
          <h2 className="text-base font-bold text-[var(--text-main)]">Visual Appearance & Theme</h2>
        </div>

        <div className="space-y-4 text-xs">
          {/* Theme Mode */}
          <div>
            <label className="block text-[var(--text-muted)] mb-2">Display Theme</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {[
                { id: 'dark', label: 'Gen-Z Dark', desc: 'Obsidian slate background' },
                { id: 'cyber', label: 'Cyber Mode', desc: 'Neo-matrix cyan contrast' },
                { id: 'light', label: 'Crisp Light', desc: 'Clean porcelain canvas' },
                { id: 'system', label: 'System Auto', desc: 'Follows OS preference' },
              ].map((th) => (
                <button
                  key={th.id}
                  onClick={() => updateSettings({ theme: th.id as any })}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    settings.theme === th.id
                      ? 'bg-[var(--accent)] text-[var(--accent-contrast)] border-[var(--accent)] font-semibold shadow-xs'
                      : 'bg-[var(--bg-card)] border-[var(--border-subtle)] text-[var(--text-main)] hover:border-[var(--border-active)]'
                  }`}
                >
                  <div className="font-bold">{th.label}</div>
                  <div className={`text-[10px] ${settings.theme === th.id ? 'opacity-80' : 'text-[var(--text-dim)]'}`}>
                    {th.desc}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Accent Color */}
          <div>
            <label className="block text-[var(--text-muted)] mb-2">Accent Highlight Palette</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {[
                { id: 'mint', label: 'Emerald Mint', color: '#10b981' },
                { id: 'violet', label: 'Electric Violet', color: '#8b5cf6' },
                { id: 'blue', label: 'Cyan Blue', color: '#0ea5e9' },
                { id: 'amber', label: 'Solar Amber', color: '#f59e0b' },
              ].map((acc) => (
                <button
                  key={acc.id}
                  onClick={() => updateSettings({ accent: acc.id as any })}
                  className={`p-3 rounded-xl border text-left transition-all flex items-center gap-3 ${
                    settings.accent === acc.id
                      ? 'bg-[var(--bg-card)] border-[var(--accent)] ring-1 ring-[var(--accent)]'
                      : 'bg-[var(--bg-card)] border-[var(--border-subtle)]'
                  }`}
                >
                  <div className="w-5 h-5 rounded-full shrink-0" style={{ backgroundColor: acc.color }} />
                  <div>
                    <div className="font-semibold text-[var(--text-main)]">{acc.label}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Audio & Synthesizer Settings */}
      <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
        <div className="flex items-center gap-2">
          <Volume2 className="w-5 h-5 text-emerald-400" />
          <h2 className="text-base font-bold text-[var(--text-main)]">Acoustic & Synthesizer Feedback</h2>
        </div>

        <div className="space-y-4 text-xs">
          <label className="flex items-center justify-between p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] cursor-pointer">
            <div>
              <div className="font-semibold text-[var(--text-main)]">Enable Audio Chimes & Fanfares</div>
              <div className="text-[11px] text-[var(--text-dim)]">Play melodic chimes on session start, complete, and breaks</div>
            </div>
            <input
              type="checkbox"
              checked={settings.soundEnabled}
              onChange={(e) => updateSettings({ soundEnabled: e.target.checked })}
              className="accent-[var(--accent)] w-4 h-4"
            />
          </label>

          <div>
            <div className="flex justify-between items-center text-[var(--text-muted)] mb-1">
              <span>Master Volume</span>
              <span className="font-mono">{Math.round(settings.masterVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={settings.masterVolume}
              onChange={(e) => updateSettings({ masterVolume: parseFloat(e.target.value) })}
              className="w-full accent-[var(--accent)]"
            />
          </div>
        </div>
      </div>

      {/* Study Habits & Streak Defaults */}
      <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-sky-400" />
          <h2 className="text-base font-bold text-[var(--text-main)]">Timer Defaults & Habit Rules</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block text-[var(--text-muted)] mb-1">
              Streak Requirement Threshold ({settings.streakRequirementMinutes} mins/day)
            </label>
            <input
              type="number"
              min="10"
              max="120"
              value={settings.streakRequirementMinutes}
              onChange={(e) => updateSettings({ streakRequirementMinutes: parseInt(e.target.value) || 20 })}
              className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] font-mono"
            />
          </div>

          <div>
            <label className="block text-[var(--text-muted)] mb-1">
              Default Timer Preset ({settings.defaultTimerPreset} mins)
            </label>
            <input
              type="number"
              min="5"
              max="120"
              value={settings.defaultTimerPreset}
              onChange={(e) => updateSettings({ defaultTimerPreset: parseInt(e.target.value) || 25 })}
              className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] font-mono"
            />
          </div>
        </div>
      </div>

      {/* Data Management & Export / Import */}
      <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
        <h2 className="text-base font-bold text-[var(--text-main)]">Data Backup, Export & Portability</h2>
        <p className="text-xs text-[var(--text-muted)]">
          Export your entire academic database (sessions, subjects, chapters, notes, achievements) as JSON.
        </p>

        {importStatus && (
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
            {importStatus}
          </div>
        )}

        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={handleDownloadJSON}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 transition-all shadow-xs"
          >
            <Download className="w-4 h-4" />
            <span>Export Database (JSON)</span>
          </button>

          <label className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] hover:border-[var(--accent)] text-[var(--text-main)] transition-colors cursor-pointer">
            <Upload className="w-4 h-4" />
            <span>Restore Backup</span>
            <input type="file" accept=".json" onChange={handleFileUpload} className="hidden" />
          </label>

          <button
            onClick={handleResetData}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 transition-colors ml-auto"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset All Data</span>
          </button>
        </div>
      </div>
    </div>
  );
};
