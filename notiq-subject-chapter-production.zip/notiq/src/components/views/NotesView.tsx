import React, { useState, useMemo, useEffect } from 'react';
import {
  FileText,
  Plus,
  Pin,
  Star,
  Archive,
  Trash2,
  Copy,
  Search,
  Filter,
  Check,
  Folder,
  Tag,
  Bold,
  Italic,
  Heading1,
  Heading2,
  List,
  CheckSquare,
  Quote,
  Code,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';
import { Note } from '../../types';

interface NotesViewProps {
  selectedNoteId?: string;
}

export const NotesView: React.FC<NotesViewProps> = ({ selectedNoteId }) => {
  const { notes, subjects, chapters, addNote, updateNote, deleteNote, duplicateNote, syncStatus } = useStudium();

  const [activeNoteId, setActiveNoteId] = useState<string>(
    selectedNoteId || notes[0]?.id || ''
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState('all');
  const [selectedFolderFilter, setSelectedFolderFilter] = useState('all');
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'Saved' | 'Saving' | 'Offline'>('Saved');

  // Active note details
  const activeNote = notes.find(n => n.id === activeNoteId) || notes[0];

  // Editor state for active note
  const [editTitle, setEditTitle] = useState(activeNote?.title || '');
  const [editContent, setEditContent] = useState(activeNote?.content || '');
  const [editSubjectId, setEditSubjectId] = useState(activeNote?.subjectId || '');
  const [editChapterId, setEditChapterId] = useState(activeNote?.chapterId || '');
  const [editFolder, setEditFolder] = useState(activeNote?.folder || 'General');
  const [editTagsInput, setEditTagsInput] = useState(activeNote?.tags.join(' ') || '');

  // Sync editor fields when activeNote changes
  useEffect(() => {
    if (activeNote) {
      setEditTitle(activeNote.title);
      setEditContent(activeNote.content);
      setEditSubjectId(activeNote.subjectId || '');
      setEditChapterId(activeNote.chapterId || '');
      setEditFolder(activeNote.folder || 'General');
      setEditTagsInput(activeNote.tags.join(' '));
    }
  }, [activeNote?.id]);

  // Debounced autosave
  useEffect(() => {
    if (!activeNote) return;
    if (
      editTitle === activeNote.title &&
      editContent === activeNote.content &&
      editSubjectId === (activeNote.subjectId || '') &&
      editChapterId === (activeNote.chapterId || '') &&
      editFolder === activeNote.folder &&
      editTagsInput === activeNote.tags.join(' ')
    ) {
      return;
    }

    setSaveStatus('Saving');
    const timer = setTimeout(() => {
      const tagsArray = editTagsInput.split(' ').map(t => t.trim()).filter(Boolean);
      updateNote(activeNote.id, {
        title: editTitle,
        content: editContent,
        subjectId: editSubjectId || undefined,
        chapterId: editChapterId || undefined,
        folder: editFolder,
        tags: tagsArray,
      });
      setSaveStatus(syncStatus.status === 'Offline' ? 'Offline' : 'Saved');
    }, 700);

    return () => clearTimeout(timer);
  }, [editTitle, editContent, editSubjectId, editChapterId, editFolder, editTagsInput]);

  // Unique folders
  const allFolders = useMemo(() => {
    const set = new Set<string>();
    notes.forEach(n => { if (n.folder) set.add(n.folder); });
    return Array.from(set);
  }, [notes]);

  // Filtered notes list
  const filteredNotes = useMemo(() => {
    return notes
      .filter((n) => {
        if (showFavoritesOnly && !n.isFavorite) return false;
        if (selectedSubjectFilter !== 'all' && n.subjectId !== selectedSubjectFilter) return false;
        if (selectedFolderFilter !== 'all' && n.folder !== selectedFolderFilter) return false;
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = n.title.toLowerCase().includes(q);
          const matchContent = n.content.toLowerCase().includes(q);
          const matchTags = n.tags.some(t => t.toLowerCase().includes(q));
          if (!matchTitle && !matchContent && !matchTags) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
        return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
      });
  }, [notes, showFavoritesOnly, selectedSubjectFilter, selectedFolderFilter, searchQuery]);

  const handleCreateNewNote = () => {
    const newNoteId = `note-${Date.now()}`;
    addNote({
      title: 'Untitled Academic Note',
      content: '# New Research Note\n\nBegin drafting key insights, formulas, or summaries...',
      subjectId: subjects[0]?.id,
      tags: ['#study'],
      folder: 'General',
      isPinned: false,
      isFavorite: false,
      isArchived: false,
    });
    setActiveNoteId(newNoteId);
  };

  // Markdown format insertion helper
  const insertFormatting = (prefix: string, suffix = '') => {
    setEditContent(prev => prev + `\n${prefix}Text${suffix}`);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[var(--border-subtle)] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
            Academic Notes & Blueprints
          </h1>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Full-featured Markdown notebook with subject taxonomy, pinned tags, and instant autosave.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-xs text-[var(--text-dim)]">
            <span
              className={`w-2 h-2 rounded-full ${
                saveStatus === 'Saving'
                  ? 'bg-amber-400 animate-ping'
                  : saveStatus === 'Offline'
                  ? 'bg-orange-400'
                  : 'bg-emerald-400'
              }`}
            />
            <span>{saveStatus}</span>
          </div>

          <button
            onClick={handleCreateNewNote}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 shadow-xs transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>New Note</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[600px]">
        {/* Left Column: Notes List & Filter Sidebar */}
        <div className="lg:col-span-4 space-y-3">
          {/* Search & Favorites Filter */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-3.5 h-3.5 text-[var(--text-dim)] absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search title, content, tag..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-xs pl-8 pr-3 py-1.5 rounded-xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-[var(--text-main)] focus:outline-none"
              />
            </div>

            <button
              onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
              className={`p-2 rounded-xl border transition-colors ${
                showFavoritesOnly
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
                  : 'bg-[var(--bg-surface)] border-[var(--border-subtle)] text-[var(--text-muted)]'
              }`}
              title="Show Favorites Only"
            >
              <Star className="w-3.5 h-3.5 fill-current" />
            </button>
          </div>

          {/* Subject & Folder Dropdown */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <select
              value={selectedSubjectFilter}
              onChange={(e) => setSelectedSubjectFilter(e.target.value)}
              className="p-1.5 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-[var(--text-main)] truncate"
            >
              <option value="all">All Subjects</option>
              {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>

            <select
              value={selectedFolderFilter}
              onChange={(e) => setSelectedFolderFilter(e.target.value)}
              className="p-1.5 rounded-lg bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-[var(--text-main)] truncate"
            >
              <option value="all">All Folders</option>
              {allFolders.map(f => <option key={f} value={f}>{f}</option>)}
            </select>
          </div>

          {/* Notes Cards List */}
          <div className="space-y-2 max-h-[65vh] overflow-y-auto pr-1">
            {filteredNotes.length === 0 ? (
              <div className="text-center py-12 text-xs text-[var(--text-muted)] bg-[var(--bg-surface)] rounded-2xl">
                No matching notes found.
              </div>
            ) : (
              filteredNotes.map((note) => {
                const isSelected = activeNote?.id === note.id;
                const subj = subjects.find(s => s.id === note.subjectId);

                return (
                  <div
                    key={note.id}
                    onClick={() => setActiveNoteId(note.id)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[var(--bg-card)] border-[var(--accent)] shadow-xs'
                        : 'bg-[var(--bg-surface)] border-[var(--border-subtle)] hover:bg-[var(--bg-card)]'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="font-semibold text-xs text-[var(--text-main)] line-clamp-1">
                        {note.title || 'Untitled Note'}
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        {note.isPinned && <Pin className="w-3 h-3 text-[var(--accent)] fill-current" />}
                        {note.isFavorite && <Star className="w-3 h-3 text-amber-400 fill-current" />}
                      </div>
                    </div>

                    <p className="mt-1 text-[11px] text-[var(--text-dim)] line-clamp-2 leading-relaxed">
                      {note.content.replace(/[#*`>]/g, '')}
                    </p>

                    <div className="mt-2.5 flex items-center justify-between text-[10px] text-[var(--text-dim)] pt-2 border-t border-[var(--border-subtle)]">
                      <span className="truncate max-w-[120px] font-medium text-[var(--text-muted)]">
                        {subj?.name || 'General'}
                      </span>
                      <span>
                        {new Date(note.updatedAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Active Note Editor */}
        {activeNote ? (
          <div className="lg:col-span-8 flex flex-col p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs space-y-4">
            {/* Note Editor Header Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[var(--border-subtle)]">
              <input
                type="text"
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                placeholder="Note Title..."
                className="text-lg font-bold bg-transparent text-[var(--text-main)] focus:outline-none w-full"
              />

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => updateNote(activeNote.id, { isPinned: !activeNote.isPinned })}
                  className={`p-2 rounded-lg border transition-colors ${
                    activeNote.isPinned
                      ? 'bg-[var(--accent)]/15 border-[var(--accent)]/30 text-[var(--accent)]'
                      : 'bg-[var(--bg-card)] border-[var(--border-subtle)] text-[var(--text-muted)]'
                  }`}
                  title="Pin note"
                >
                  <Pin className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => updateNote(activeNote.id, { isFavorite: !activeNote.isFavorite })}
                  className={`p-2 rounded-lg border transition-colors ${
                    activeNote.isFavorite
                      ? 'bg-amber-500/15 border-amber-500/30 text-amber-400'
                      : 'bg-[var(--bg-card)] border-[var(--border-subtle)] text-[var(--text-muted)]'
                  }`}
                  title="Favorite note"
                >
                  <Star className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => duplicateNote(activeNote.id)}
                  className="p-2 rounded-lg bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-muted)] hover:text-[var(--text-main)]"
                  title="Duplicate note"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => {
                    if (confirm('Delete this note?')) deleteNote(activeNote.id);
                  }}
                  className="p-2 rounded-lg bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-muted)] hover:text-red-400"
                  title="Delete note"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Note Meta Settings (Subject, Folder, Tags) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              <select
                value={editSubjectId}
                onChange={(e) => setEditSubjectId(e.target.value)}
                className="p-2 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
              >
                <option value="">-- No Subject Assigned --</option>
                {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>

              <input
                type="text"
                placeholder="Folder (e.g. Theory)"
                value={editFolder}
                onChange={(e) => setEditFolder(e.target.value)}
                className="p-2 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
              />

              <input
                type="text"
                placeholder="Tags #exam #formula"
                value={editTagsInput}
                onChange={(e) => setEditTagsInput(e.target.value)}
                className="p-2 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] font-mono text-[11px]"
              />
            </div>

            {/* Markdown Toolbar */}
            <div className="flex items-center gap-1 p-1 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] flex-wrap">
              <button
                type="button"
                onClick={() => insertFormatting('# ')}
                className="p-1.5 text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-surface)] rounded-md"
                title="H1 Heading"
              >
                <Heading1 className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => insertFormatting('## ')}
                className="p-1.5 text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-surface)] rounded-md"
                title="H2 Heading"
              >
                <Heading2 className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => insertFormatting('**', '**')}
                className="p-1.5 text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-surface)] rounded-md"
                title="Bold"
              >
                <Bold className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => insertFormatting('*', '*')}
                className="p-1.5 text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-surface)] rounded-md"
                title="Italic"
              >
                <Italic className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => insertFormatting('- ')}
                className="p-1.5 text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-surface)] rounded-md"
                title="Bullet List"
              >
                <List className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => insertFormatting('> ')}
                className="p-1.5 text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-surface)] rounded-md"
                title="Blockquote"
              >
                <Quote className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => insertFormatting('```\n', '\n```')}
                className="p-1.5 text-[var(--text-muted)] hover:text-[var(--text-main)] hover:bg-[var(--bg-surface)] rounded-md"
                title="Code Block"
              >
                <Code className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Content Textarea */}
            <textarea
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              placeholder="Draft your academic notes here using Markdown..."
              className="w-full flex-1 min-h-[350px] p-4 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-xs text-[var(--text-main)] font-mono leading-relaxed focus:outline-none resize-none"
            />
          </div>
        ) : (
          <div className="lg:col-span-8 flex items-center justify-center p-12 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs text-[var(--text-muted)]">
            Select a note or create a new one to begin.
          </div>
        )}
      </div>
    </div>
  );
};
