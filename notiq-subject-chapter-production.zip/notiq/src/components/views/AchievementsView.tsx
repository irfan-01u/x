import React, { useState, useMemo } from 'react';
import {
  Award,
  Pin,
  Clock,
  Flame,
  Target,
  CheckCircle2,
  Sparkles,
  BookOpen,
  Lock,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';
import { AchievementCategory } from '../../types';

export const AchievementsView: React.FC = () => {
  const { achievements, profile, togglePinAchievement, sessions, streakData } = useStudium();

  const [activeCategory, setActiveCategory] = useState<AchievementCategory | 'ALL'>('ALL');

  const categories: Array<{ id: AchievementCategory | 'ALL'; label: string }> = [
    { id: 'ALL', label: 'All Badges' },
    { id: 'TIME', label: 'Study Time' },
    { id: 'STREAK', label: 'Habit Streaks' },
    { id: 'POMODORO', label: 'Pomodoro' },
    { id: 'CONSISTENCY', label: 'Consistency' },
    { id: 'SUBJECT', label: 'Subject Conquered' },
    { id: 'SPECIAL', label: 'Special Feats' },
  ];

  const totalStudyHours = useMemo(() => {
    return Number((sessions.reduce((acc, s) => acc + s.duration, 0) / 3600).toFixed(1));
  }, [sessions]);

  const totalPomodoros = useMemo(() => {
    return sessions.filter(s => s.timerMode === 'pomodoro').length;
  }, [sessions]);

  const filteredAchievements = useMemo(() => {
    return achievements.filter(a => {
      if (activeCategory === 'ALL') return true;
      return a.category === activeCategory;
    });
  }, [achievements, activeCategory]);

  const unlockedCount = achievements.filter(a => a.unlocked).length;

  const getProgressValues = (ach: typeof achievements[0]) => {
    if (ach.unlocked) return { current: ach.targetValue, pct: 100 };

    let current = 0;
    if (ach.category === 'TIME') current = totalStudyHours;
    if (ach.category === 'POMODORO') current = totalPomodoros;
    if (ach.category === 'STREAK') current = streakData.currentStreak;

    const pct = Math.min(99, Math.round((current / ach.targetValue) * 100));
    return { current: Math.round(current), pct };
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[var(--border-subtle)] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
            Academic Achievements & Showcase
          </h1>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Earn verified scholastic badges through disciplined consistency. Pin up to 3 badges to your profile.
          </p>
        </div>

        <div className="p-2.5 px-4 rounded-xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs font-mono font-bold flex items-center gap-2">
          <Award className="w-4 h-4 text-amber-400" />
          <span>{unlockedCount} / {achievements.length} Unlocked</span>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors border ${
              activeCategory === cat.id
                ? 'bg-[var(--accent)] text-[var(--accent-contrast)] border-[var(--accent)] font-semibold shadow-xs'
                : 'bg-[var(--bg-surface)] border-[var(--border-subtle)] text-[var(--text-muted)] hover:text-[var(--text-main)]'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Badges Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAchievements.map((ach) => {
          const isPinned = profile.pinnedAchievementIds.includes(ach.id);
          const { current, pct } = getProgressValues(ach);

          return (
            <div
              key={ach.id}
              className={`p-5 rounded-2xl border transition-all space-y-3 relative overflow-hidden ${
                ach.unlocked
                  ? 'bg-[var(--bg-surface)] border-[var(--border-subtle)] shadow-xs'
                  : 'bg-[var(--bg-surface)]/50 border-[var(--border-subtle)]/50 opacity-75'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      ach.unlocked
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20 shadow-xs'
                        : 'bg-[var(--bg-card)] text-[var(--text-dim)] border border-[var(--border-subtle)]'
                    }`}
                  >
                    {ach.unlocked ? <Award className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
                  </div>

                  <div>
                    <h3 className="font-bold text-sm text-[var(--text-main)]">{ach.title}</h3>
                    <span className="text-[10px] text-[var(--text-dim)] uppercase font-mono">
                      {ach.category}
                    </span>
                  </div>
                </div>

                {ach.unlocked && (
                  <button
                    onClick={() => togglePinAchievement(ach.id)}
                    className={`p-1.5 rounded-lg border transition-colors ${
                      isPinned
                        ? 'bg-[var(--accent)] border-[var(--accent)] text-[var(--accent-contrast)]'
                        : 'bg-[var(--bg-card)] border-[var(--border-subtle)] text-[var(--text-dim)] hover:text-[var(--text-main)]'
                    }`}
                    title={isPinned ? 'Unpin from profile' : 'Pin to profile showcase'}
                  >
                    <Pin className="w-3.5 h-3.5 fill-current" />
                  </button>
                )}
              </div>

              <p className="text-xs text-[var(--text-muted)] leading-relaxed">{ach.description}</p>

              {/* Progress bar */}
              <div className="space-y-1.5 pt-2 border-t border-[var(--border-subtle)]">
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-[var(--text-dim)]">Progress</span>
                  <span className="font-mono text-[var(--text-main)] font-semibold tabular-nums">
                    {ach.unlocked ? 'Unlocked' : `${current} / ${ach.targetValue} ${ach.unit} (${pct}%)`}
                  </span>
                </div>
                <div className="w-full h-1.5 bg-[var(--bg-card)] rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      ach.unlocked ? 'bg-amber-400' : 'bg-[var(--accent)]'
                    }`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>

              {ach.unlockedAt && (
                <div className="text-[10px] text-[var(--text-dim)] pt-1">
                  Unlocked {new Date(ach.unlockedAt).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
