import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  TrendingUp,
  Clock,
  Flame,
  Award,
  Calendar,
  PieChart,
  CheckCircle2,
  Trophy,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

export const AnalyticsView: React.FC = () => {
  const { sessions, subjects, streakData, dailyGoals } = useStudium();

  const [timeRange, setTimeRange] = useState<'today' | '7d' | '30d' | '90d' | 'all'>('30d');

  // Filter sessions by range
  const filteredSessions = useMemo(() => {
    const today = new Date();
    const todayStr = today.toISOString().slice(0, 10);

    if (timeRange === 'today') {
      return sessions.filter(s => s.dateString === todayStr);
    }

    const daysMap = { '7d': 7, '30d': 30, '90d': 90, 'all': 9999 };
    const cutoffDays = daysMap[timeRange];
    const cutoffDate = new Date(today);
    cutoffDate.setDate(today.getDate() - cutoffDays);
    const cutoffStr = cutoffDate.toISOString().slice(0, 10);

    return sessions.filter(s => s.dateString >= cutoffStr);
  }, [sessions, timeRange]);

  // Core metrics calculation
  const metrics = useMemo(() => {
    const totalDurationSeconds = filteredSessions.reduce((acc, s) => acc + s.duration, 0);
    const totalHours = Number((totalDurationSeconds / 3600).toFixed(1));
    const totalMinutes = Math.round(totalDurationSeconds / 60);

    const sessionCount = filteredSessions.length;
    const pomodoroCount = filteredSessions.filter(s => s.timerMode === 'pomodoro').length;

    // Distinct dates
    const distinctDates = new Set(filteredSessions.map(s => s.dateString));
    const activeDaysCount = distinctDates.size;
    const avgDailyMinutes = activeDaysCount > 0 ? Math.round(totalMinutes / activeDaysCount) : 0;

    // Durations
    const durations = filteredSessions.map(s => s.duration);
    const longestSeconds = durations.length > 0 ? Math.max(...durations) : 0;
    const shortestSeconds = durations.length > 0 ? Math.min(...durations) : 0;
    const avgSessionMinutes = sessionCount > 0 ? Math.round(totalMinutes / sessionCount) : 0;

    // Subject breakdown
    const subjectMap: Record<string, number> = {};
    filteredSessions.forEach(s => {
      subjectMap[s.subjectId] = (subjectMap[s.subjectId] || 0) + s.duration / 60;
    });

    const subjectBreakdown = Object.entries(subjectMap).map(([subjId, mins]) => {
      const s = subjects.find(sub => sub.id === subjId);
      return {
        id: subjId,
        name: s?.name || 'Unknown',
        accentColor: s?.accentColor || '#38bdf8',
        minutes: Math.round(mins),
        hours: Number((mins / 60).toFixed(1)),
        percent: totalMinutes > 0 ? Math.round((mins / totalMinutes) * 100) : 0,
      };
    }).sort((a, b) => b.minutes - a.minutes);

    // Study by hour of day (0-23)
    const hourDistribution = Array(24).fill(0);
    filteredSessions.forEach(s => {
      const hour = new Date(s.startTime).getHours();
      hourDistribution[hour] += Math.round(s.duration / 60);
    });

    // Most productive hour
    let peakHour = 0;
    let peakHourMins = 0;
    hourDistribution.forEach((m, h) => {
      if (m > peakHourMins) {
        peakHourMins = m;
        peakHour = h;
      }
    });

    // Study by day of week (Sun-Sat)
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const dayDistribution = Array(7).fill(0);
    filteredSessions.forEach(s => {
      const day = new Date(s.dateString + 'T12:00:00').getDay();
      dayDistribution[day] += Math.round(s.duration / 60);
    });

    let peakDayIdx = 0;
    let peakDayMins = 0;
    dayDistribution.forEach((m, idx) => {
      if (m > peakDayMins) {
        peakDayMins = m;
        peakDayIdx = idx;
      }
    });

    // Personal records
    const allDurations = sessions.map(s => s.duration);
    const allTimeLongest = allDurations.length > 0 ? Math.round(Math.max(...allDurations) / 60) : 0;

    // Most in one day
    const dayTotals: Record<string, number> = {};
    sessions.forEach(s => {
      dayTotals[s.dateString] = (dayTotals[s.dateString] || 0) + s.duration / 60;
    });
    const maxOneDayMins = Math.round(Math.max(0, ...Object.values(dayTotals)));

    return {
      totalHours,
      totalMinutes,
      sessionCount,
      pomodoroCount,
      avgDailyMinutes,
      avgSessionMinutes,
      longestMinutes: Math.round(longestSeconds / 60),
      shortestMinutes: Math.round(shortestSeconds / 60),
      subjectBreakdown,
      hourDistribution,
      dayDistribution,
      dayNames,
      peakHour,
      peakDayName: dayNames[peakDayIdx],
      mostStudiedSubject: subjectBreakdown[0]?.name || 'N/A',
      allTimeLongest,
      maxOneDayMins,
    };
  }, [filteredSessions, subjects, sessions]);

  // Max value for hourly chart scaling
  const maxHourValue = Math.max(1, ...metrics.hourDistribution);
  const maxDayValue = Math.max(1, ...metrics.dayDistribution);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[var(--border-subtle)] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
            Academic Analytics & Patterns
          </h1>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Empirical telemetry on focus sessions, chronotype peaks, and subject distributions.
          </p>
        </div>

        {/* Time range selector */}
        <div className="flex items-center bg-[var(--bg-surface)] p-1 rounded-xl border border-[var(--border-subtle)] text-xs">
          {(['today', '7d', '30d', '90d', 'all'] as const).map((r) => (
            <button
              key={r}
              onClick={() => setTimeRange(r)}
              className={`px-3 py-1 rounded-lg uppercase transition-colors ${
                timeRange === r
                  ? 'bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold shadow-xs'
                  : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs">
          <span className="text-xs text-[var(--text-muted)]">Total Study Time</span>
          <div className="mt-2 text-2xl font-bold font-mono text-[var(--text-main)] tabular-nums">
            {metrics.totalHours} <span className="text-xs font-normal text-[var(--text-dim)]">hours</span>
          </div>
          <span className="text-[10px] text-[var(--text-dim)]">{metrics.totalMinutes} total minutes</span>
        </div>

        <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs">
          <span className="text-xs text-[var(--text-muted)]">Daily Average</span>
          <div className="mt-2 text-2xl font-bold font-mono text-emerald-400 tabular-nums">
            {Math.floor(metrics.avgDailyMinutes / 60)}h {metrics.avgDailyMinutes % 60}m
          </div>
          <span className="text-[10px] text-[var(--text-dim)]">active study days</span>
        </div>

        <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs">
          <span className="text-xs text-[var(--text-muted)]">Total Sessions</span>
          <div className="mt-2 text-2xl font-bold font-mono text-purple-400 tabular-nums">
            {metrics.sessionCount}
          </div>
          <span className="text-[10px] text-[var(--text-dim)]">{metrics.pomodoroCount} pomodoro blocks</span>
        </div>

        <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs">
          <span className="text-xs text-[var(--text-muted)]">Avg Session Length</span>
          <div className="mt-2 text-2xl font-bold font-mono text-amber-400 tabular-nums">
            {metrics.avgSessionMinutes} <span className="text-xs font-normal text-[var(--text-dim)]">mins</span>
          </div>
          <span className="text-[10px] text-[var(--text-dim)]">longest: {metrics.longestMinutes}m</span>
        </div>
      </div>

      {/* Row: Subject Distribution & Productivity Patterns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Subject Breakdown */}
        <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
          <h2 className="text-base font-bold text-[var(--text-main)]">Subject Allocation Breakdown</h2>

          <div className="space-y-3">
            {metrics.subjectBreakdown.map((s) => (
              <div key={s.id} className="space-y-1">
                <div className="flex justify-between items-center text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: s.accentColor }} />
                    <span className="font-semibold text-[var(--text-main)]">{s.name}</span>
                  </div>
                  <span className="font-mono text-[var(--text-muted)] tabular-nums">
                    {s.hours}h ({s.percent}%)
                  </span>
                </div>
                <div className="w-full h-2 bg-[var(--bg-card)] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{ width: `${s.percent}%`, backgroundColor: s.accentColor }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Productivity Patterns & Chronotype Insights */}
        <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
          <h2 className="text-base font-bold text-[var(--text-main)]">Cognitive Productivity Patterns</h2>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
              <span className="text-[var(--text-muted)]">Peak Chronotype Hour</span>
              <div className="mt-1 font-mono font-bold text-lg text-[var(--accent)]">
                {metrics.peakHour}:00 – {metrics.peakHour + 1}:00
              </div>
              <span className="text-[10px] text-[var(--text-dim)]">Highest retention output</span>
            </div>

            <div className="p-3.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
              <span className="text-[var(--text-muted)]">Most Productive Day</span>
              <div className="mt-1 font-mono font-bold text-lg text-emerald-400">
                {metrics.peakDayName}
              </div>
              <span className="text-[10px] text-[var(--text-dim)]">Greatest weekly focus</span>
            </div>

            <div className="p-3.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
              <span className="text-[var(--text-muted)]">Leading Academic Domain</span>
              <div className="mt-1 font-mono font-bold text-sm text-purple-400 truncate">
                {metrics.mostStudiedSubject}
              </div>
              <span className="text-[10px] text-[var(--text-dim)]">Most studied domain</span>
            </div>

            <div className="p-3.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
              <span className="text-[var(--text-muted)]">Single-Day High Score</span>
              <div className="mt-1 font-mono font-bold text-lg text-amber-400">
                {Math.floor(metrics.maxOneDayMins / 60)}h {metrics.maxOneDayMins % 60}m
              </div>
              <span className="text-[10px] text-[var(--text-dim)]">Peak daily endurance</span>
            </div>
          </div>
        </div>
      </div>

      {/* Row: Chronological Hourly Distribution & Day of Week Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Hourly Distribution (0 to 23) */}
        <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-[var(--text-main)]">Study Distribution by Hour (00:00 - 23:00)</h2>
            <span className="text-xs text-[var(--text-dim)]">Minutes per hour</span>
          </div>

          <div className="h-40 flex items-end gap-1 pt-6">
            {metrics.hourDistribution.map((mins, hour) => {
              const heightPct = Math.round((mins / maxHourValue) * 100);
              const isPeak = hour === metrics.peakHour && mins > 0;
              return (
                <div key={hour} className="flex-1 flex flex-col items-center h-full justify-end group relative">
                  <div
                    className={`w-full rounded-t transition-all ${
                      isPeak
                        ? 'bg-[var(--accent)] shadow-xs'
                        : mins > 0
                        ? 'bg-[var(--accent)]/50 hover:bg-[var(--accent)]'
                        : 'bg-[var(--bg-card)]'
                    }`}
                    style={{ height: `${Math.max(4, heightPct)}%` }}
                  />
                  {hour % 4 === 0 && (
                    <span className="text-[9px] text-[var(--text-dim)] mt-1 font-mono">{hour}h</span>
                  )}

                  {/* Tooltip */}
                  <div className="absolute bottom-full mb-1 hidden group-hover:block z-20 pointer-events-none">
                    <div className="bg-neutral-900 border border-neutral-700 text-white text-[10px] px-1.5 py-0.5 rounded shadow">
                      {hour}:00 - {mins}m
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Day of Week Distribution (Sun - Sat) */}
        <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-[var(--text-main)]">Study Distribution by Day of Week</h2>
            <span className="text-xs text-[var(--text-dim)]">Weekly volume</span>
          </div>

          <div className="h-40 flex items-end gap-3 pt-6">
            {metrics.dayDistribution.map((mins, dayIdx) => {
              const heightPct = Math.round((mins / maxDayValue) * 100);
              const isPeak = metrics.dayNames[dayIdx] === metrics.peakDayName && mins > 0;
              return (
                <div key={dayIdx} className="flex-1 flex flex-col items-center h-full justify-end group relative">
                  <div
                    className={`w-full rounded-t-lg transition-all ${
                      isPeak
                        ? 'bg-emerald-400'
                        : mins > 0
                        ? 'bg-emerald-600/70 hover:bg-emerald-500'
                        : 'bg-[var(--bg-card)]'
                    }`}
                    style={{ height: `${Math.max(6, heightPct)}%` }}
                  />
                  <span className="text-[10px] text-[var(--text-muted)] mt-1 font-semibold">
                    {metrics.dayNames[dayIdx]}
                  </span>

                  {/* Tooltip */}
                  <div className="absolute bottom-full mb-1 hidden group-hover:block z-20 pointer-events-none">
                    <div className="bg-neutral-900 border border-neutral-700 text-white text-[10px] px-1.5 py-0.5 rounded shadow">
                      {Math.round(mins / 60)}h {mins % 60}m
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
