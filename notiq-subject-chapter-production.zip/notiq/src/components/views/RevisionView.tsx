import React, { useMemo } from 'react';
import {
  RefreshCw,
  Clock,
  CheckCircle2,
  Calendar,
  AlertCircle,
  Play,
  RotateCcw,
  BookOpen,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

export const RevisionView: React.FC<{ onNavigate: (view: string) => void }> = ({ onNavigate }) => {
  const { chapters, subjects, markChapterRevisionCompleted, startTimer } = useStudium();

  const todayStr = new Date().toISOString().slice(0, 10);

  // Group chapters by revision status
  const { dueToday, upcoming, completedRevisions } = useMemo(() => {
    const dueTodayList = chapters.filter(c => {
      if (c.revisionRequired) return true;
      if (c.nextRevisionDate && c.nextRevisionDate <= todayStr) return true;
      return false;
    });

    const upcomingList = chapters.filter(c => {
      if (!c.nextRevisionDate) return false;
      return c.nextRevisionDate > todayStr && !c.revisionRequired;
    });

    const completedList = chapters.filter(c => c.revisionCount > 0);

    return {
      dueToday: dueTodayList,
      upcoming: upcomingList,
      completedRevisions: completedList,
    };
  }, [chapters, todayStr]);

  const intervals = [1, 3, 7, 14, 30];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[var(--border-subtle)] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
            Spaced Repetition & Revision System
          </h1>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Optimize memory consolidation with logarithmic spaced repetition intervals (1d, 3d, 7d, 14d, 30d).
          </p>
        </div>
      </div>

      {/* Spaced Intervals Concept Bar */}
      <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs">
        <div className="text-xs font-semibold text-[var(--text-dim)] uppercase tracking-wider mb-2">
          Ebbinghaus Retention Curve Schedule
        </div>
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          {intervals.map((days, idx) => (
            <div
              key={days}
              className="flex items-center gap-2 p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] shrink-0"
            >
              <div className="w-5 h-5 rounded-full bg-[var(--accent)] text-[var(--accent-contrast)] flex items-center justify-center font-bold text-[10px]">
                {idx + 1}
              </div>
              <div>
                <div className="font-semibold text-[var(--text-main)]">{days} Day Interval</div>
                <div className="text-[10px] text-[var(--text-dim)]">Tier {idx + 1} Recall</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Due Today Queue */}
      <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400" />
            <h2 className="text-base font-bold text-[var(--text-main)]">
              Chapters Due for Revision ({dueToday.length})
            </h2>
          </div>
          {dueToday.length > 0 && (
            <span className="text-xs px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 font-medium">
              Action Required
            </span>
          )}
        </div>

        {dueToday.length === 0 ? (
          <div className="text-center py-10 text-xs text-[var(--text-muted)] bg-[var(--bg-card)] rounded-xl">
            All revision items are up to date! Great retention work.
          </div>
        ) : (
          <div className="space-y-2.5">
            {dueToday.map((c) => {
              const subj = subjects.find(s => s.id === c.subjectId);
              return (
                <div
                  key={c.id}
                  className="p-4 rounded-xl bg-[var(--bg-card)] border border-amber-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-[var(--text-main)]">{c.name}</span>
                      <span className="text-[10px] text-[var(--text-dim)]">
                        ({subj?.name})
                      </span>
                    </div>
                    <div className="text-[11px] text-[var(--text-muted)] mt-1 flex items-center gap-3">
                      <span>Completed {c.revisionCount} revisions</span>
                      <span>·</span>
                      <span>Last: {c.lastRevisionDate || 'Never'}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <button
                      onClick={() => {
                        startTimer({
                          subjectId: c.subjectId,
                          chapterId: c.id,
                          studyType: 'Revision',
                          targetDuration: 25 * 60,
                          elapsedSeconds: 0,
                        });
                        onNavigate('timer');
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 font-semibold"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Start Revision</span>
                    </button>

                    <button
                      onClick={() => markChapterRevisionCompleted(c.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20 font-medium"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Mark Done</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Upcoming Revision Schedule */}
      <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
        <h2 className="text-base font-bold text-[var(--text-main)]">Upcoming Revision Queue ({upcoming.length})</h2>

        {upcoming.length === 0 ? (
          <div className="text-center py-6 text-xs text-[var(--text-muted)] bg-[var(--bg-card)] rounded-xl">
            No upcoming spaced repetitions currently queued.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {upcoming.map((c) => {
              const subj = subjects.find(s => s.id === c.subjectId);
              return (
                <div
                  key={c.id}
                  className="p-3.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-xs space-y-1.5"
                >
                  <div className="font-semibold text-[var(--text-main)] truncate">{c.name}</div>
                  <div className="text-[11px] text-[var(--text-dim)]">{subj?.name}</div>
                  <div className="flex items-center justify-between text-[11px] text-[var(--accent)] pt-1 border-t border-[var(--border-subtle)] font-mono">
                    <span>Due: {c.nextRevisionDate}</span>
                    <span>Iteration #{c.revisionCount + 1}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
