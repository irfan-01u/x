import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  Plus,
  Edit3,
  Trash2,
  Archive,
  RotateCcw,
  Clock,
  BookmarkCheck,
  FileText,
  TrendingUp,
  X,
  Check,
  AlertCircle,
  Play,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';
import { Subject, Priority, SubjectStatus } from '../../types';

interface SubjectsViewProps {
  selectedSubjectId?: string;
  onNavigate: (view: string, detailId?: string) => void;
}

export const SubjectsView: React.FC<SubjectsViewProps> = ({ selectedSubjectId, onNavigate }) => {
  const {
    subjects,
    chapters,
    sessions,
    notes,
    addSubject,
    updateSubject,
    deleteSubject,
    startTimer,
  } = useStudium();

  const [activeSubjectId, setActiveSubjectId] = useState<string>(
    selectedSubjectId || subjects[0]?.id || ''
  );
  const [filterStatus, setFilterStatus] = useState<'All' | 'Active' | 'Archived'>('Active');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    accentColor: '#38bdf8',
    targetHours: 0,
    priority: 'High' as Priority,
    status: 'Active' as SubjectStatus,
    icon: 'BookOpen',
  });

  // Filtered subjects list
  const filteredSubjects = useMemo(() => {
    return subjects.filter((s) => {
      if (filterStatus === 'Active') return s.status === 'Active' || s.status === 'Paused';
      if (filterStatus === 'Archived') return s.status === 'Archived';
      return true;
    });
  }, [subjects, filterStatus]);

  // Selected subject details
  const activeSubject = subjects.find(s => s.id === activeSubjectId) || filteredSubjects[0] || subjects[0];

  // Subject statistics derived from Source of Truth (sessions, chapters, notes)
  const subjectStats = useMemo(() => {
    if (!activeSubject) return null;
    const sSessions = sessions.filter(s => s.subjectId === activeSubject.id);
    const totalSeconds = sSessions.reduce((acc, s) => acc + s.duration, 0);
    const totalMinutes = Math.round(totalSeconds / 60);
    const totalHours = Number((totalMinutes / 60).toFixed(1));

    // Today
    const todayStr = new Date().toISOString().slice(0, 10);
    const todaySeconds = sSessions.filter(s => s.dateString === todayStr).reduce((acc, s) => acc + s.duration, 0);

    // This week
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    const weekAgoStr = weekAgo.toISOString().slice(0, 10);
    const weekSeconds = sSessions.filter(s => s.dateString >= weekAgoStr).reduce((acc, s) => acc + s.duration, 0);

    // Chapters
    const sChapters = chapters.filter(c => c.subjectId === activeSubject.id);
    const completedChapters = sChapters.filter(c => c.status === 'Completed').length;
    const progressPct = sChapters.length > 0 ? Math.round((completedChapters / sChapters.length) * 100) : 0;

    // Notes
    const sNotes = notes.filter(n => n.subjectId === activeSubject.id);

    // Average session
    const avgSessionMins = sSessions.length > 0 ? Math.round(totalMinutes / sSessions.length) : 0;

    return {
      totalHours,
      totalMinutes,
      todayMinutes: Math.round(todaySeconds / 60),
      weekMinutes: Math.round(weekSeconds / 60),
      sessionCount: sSessions.length,
      chaptersCount: sChapters.length,
      completedChapters,
      progressPct,
      notesCount: sNotes.length,
      avgSessionMins,
      chapters: sChapters,
      notes: sNotes,
      recentSessions: sSessions.slice(0, 5),
    };
  }, [activeSubject, chapters, notes, sessions]);

  const handleOpenCreate = () => {
    setFormData({
      name: '',
      description: '',
      accentColor: '#38bdf8',
      targetHours: 0,
      priority: 'High',
      status: 'Active',
      icon: 'BookOpen',
    });
    setEditingSubject(null);
    setIsCreateModalOpen(true);
  };

  const handleOpenEdit = (subj: Subject) => {
    setFormData({
      name: subj.name,
      description: subj.description,
      accentColor: subj.accentColor,
      targetHours: subj.targetHours,
      priority: subj.priority,
      status: subj.status,
      icon: subj.icon,
    });
    setEditingSubject(subj);
    setIsCreateModalOpen(true);
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    if (editingSubject) {
      updateSubject(editingSubject.id, formData);
    } else {
      addSubject(formData);
    }
    setIsCreateModalOpen(false);
  };

  const priorityColors: Record<Priority, string> = {
    Low: 'text-neutral-400 bg-neutral-800/50',
    Medium: 'text-sky-400 bg-sky-950/40 border border-sky-800/30',
    High: 'text-amber-400 bg-amber-950/40 border border-amber-800/30',
    Critical: 'text-rose-400 bg-rose-950/40 border border-rose-800/30',
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[var(--border-subtle)] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
            Academic Subject Tracking
          </h1>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Architect your syllabus structure, set semester target hours, and view chapter analytics.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex bg-[var(--bg-surface)] p-1 rounded-xl border border-[var(--border-subtle)] text-xs">
            {(['Active', 'Archived', 'All'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  filterStatus === st
                    ? 'bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold'
                    : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          <button
            onClick={handleOpenCreate}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 transition-all shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>New Subject</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Subjects List */}
        <div className="lg:col-span-4 space-y-2.5">
          {filteredSubjects.map((s) => {
            const isSelected = activeSubject?.id === s.id;
            const sSessions = sessions.filter(sess => sess.subjectId === s.id);
            const totalMins = Math.round(sSessions.reduce((acc, sess) => acc + sess.duration, 0) / 60);

            return (
              <div
                key={s.id}
                onClick={() => setActiveSubjectId(s.id)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[var(--bg-card)] border-[var(--accent)] shadow-sm'
                    : 'bg-[var(--bg-surface)] border-[var(--border-subtle)] hover:bg-[var(--bg-card)]'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-3.5 h-3.5 rounded-full shrink-0"
                      style={{ backgroundColor: s.accentColor }}
                    />
                    <div className="font-bold text-sm text-[var(--text-main)]">{s.name}</div>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${priorityColors[s.priority]}`}>
                    {s.priority}
                  </span>
                </div>

                <p className="mt-1 text-xs text-[var(--text-muted)] line-clamp-2">{s.description}</p>

                <div className="mt-3 flex items-center justify-between text-[11px] text-[var(--text-dim)] pt-2 border-t border-[var(--border-subtle)]">
                  <span>Target: {s.targetHours}h</span>
                  <span className="font-mono text-[var(--text-main)] font-semibold">
                    {Math.round(totalMins / 60)}h logged
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Detailed Dashboard for Selected Subject */}
        {activeSubject && subjectStats && (
          <div className="lg:col-span-8 space-y-6">
            {/* Subject Overview Card */}
            <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-5 h-5 rounded-lg"
                    style={{ backgroundColor: activeSubject.accentColor }}
                  />
                  <div>
                    <h2 className="text-xl font-bold text-[var(--text-main)]">{activeSubject.name}</h2>
                    <span className="text-xs text-[var(--text-muted)]">{activeSubject.description}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      startTimer({
                        subjectId: activeSubject.id,
                        targetDuration: 25 * 60,
                        elapsedSeconds: 0,
                      });
                      onNavigate('timer');
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 transition-all"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Study This</span>
                  </button>

                  <button
                    onClick={() => handleOpenEdit(activeSubject)}
                    className="p-2 rounded-lg bg-[var(--bg-card)] text-[var(--text-muted)] hover:text-[var(--text-main)] border border-[var(--border-subtle)] transition-colors"
                    title="Edit subject"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => {
                      if (confirm(`Archive ${activeSubject.name}?`)) {
                        updateSubject(activeSubject.id, {
                          status: activeSubject.status === 'Archived' ? 'Active' : 'Archived',
                        });
                      }
                    }}
                    className="p-2 rounded-lg bg-[var(--bg-card)] text-[var(--text-muted)] hover:text-amber-400 border border-[var(--border-subtle)] transition-colors"
                    title="Archive subject"
                  >
                    <Archive className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* KPI Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                <div className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
                  <span className="text-[11px] text-[var(--text-muted)]">Total Study Time</span>
                  <div className="mt-1 font-mono font-bold text-lg text-[var(--text-main)]">
                    {subjectStats.totalHours}h
                  </div>
                  <span className="text-[10px] text-[var(--text-dim)]">of {activeSubject.targetHours}h target</span>
                </div>

                <div className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
                  <span className="text-[11px] text-[var(--text-muted)]">This Week</span>
                  <div className="mt-1 font-mono font-bold text-lg text-emerald-400">
                    {Math.round(subjectStats.weekMinutes / 60)}h {subjectStats.weekMinutes % 60}m
                  </div>
                  <span className="text-[10px] text-[var(--text-dim)]">past 7 days</span>
                </div>

                <div className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
                  <span className="text-[11px] text-[var(--text-muted)]">Syllabus Progress</span>
                  <div className="mt-1 font-mono font-bold text-lg text-purple-400">
                    {subjectStats.progressPct}%
                  </div>
                  <span className="text-[10px] text-[var(--text-dim)]">
                    {subjectStats.completedChapters}/{subjectStats.chaptersCount} chapters
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
                  <span className="text-[11px] text-[var(--text-muted)]">Total Sessions</span>
                  <div className="mt-1 font-mono font-bold text-lg text-amber-400">
                    {subjectStats.sessionCount}
                  </div>
                  <span className="text-[10px] text-[var(--text-dim)]">avg {subjectStats.avgSessionMins}m / session</span>
                </div>
              </div>
            </div>

            {/* Chapters In This Subject */}
            <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-[var(--text-main)]">
                  Syllabus Chapters ({subjectStats.chapters.length})
                </h3>
                <button
                  onClick={() => onNavigate('chapters')}
                  className="text-xs text-[var(--accent)] hover:underline"
                >
                  Manage Chapters
                </button>
              </div>

              {subjectStats.chapters.length === 0 ? (
                <div className="text-center py-6 text-xs text-[var(--text-muted)]">
                  No chapters registered for this subject yet.
                </div>
              ) : (
                <div className="space-y-2">
                  {subjectStats.chapters.map((c) => (
                    <div
                      key={c.id}
                      onClick={() => onNavigate('chapters', c.id)}
                      className="p-3 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] border border-[var(--border-subtle)] flex items-center justify-between text-xs cursor-pointer transition-colors"
                    >
                      <div>
                        <div className="font-semibold text-[var(--text-main)]">{c.name}</div>
                        <div className="text-[11px] text-[var(--text-dim)]">
                          Status: {c.status} · {c.checklist.filter(i => i.completed).length}/{c.checklist.length} Topics
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-mono font-bold text-[var(--accent)]">{c.customProgress}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Academic Notes Linked to Subject */}
            <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-[var(--text-main)]">
                  Subject Notebook ({subjectStats.notes.length})
                </h3>
                <button
                  onClick={() => onNavigate('notes')}
                  className="text-xs text-[var(--accent)] hover:underline"
                >
                  Open Notebook
                </button>
              </div>

              {subjectStats.notes.length === 0 ? (
                <div className="text-center py-6 text-xs text-[var(--text-muted)]">
                  No notes filed under this subject yet.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {subjectStats.notes.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => onNavigate('notes', n.id)}
                      className="p-3 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] border border-[var(--border-subtle)] cursor-pointer text-xs space-y-1 transition-colors"
                    >
                      <div className="font-semibold text-[var(--text-main)] truncate">{n.title}</div>
                      <div className="text-[10px] text-[var(--text-dim)] font-mono truncate">
                        {n.tags.join(' ')}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Create / Edit Subject Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-2xl shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-[var(--text-main)]">
                {editingSubject ? 'Edit Academic Subject' : 'Register New Subject'}
              </h3>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1 text-[var(--text-dim)] hover:text-[var(--text-main)]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="space-y-3 text-xs">
              <div>
                <label className="block text-[var(--text-muted)] mb-1">Subject Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Organic Chemistry"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                />
              </div>

              <div>
                <label className="block text-[var(--text-muted)] mb-1">Description / Syllabus Focus</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Core principles of stereochemistry and mechanisms"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[var(--text-muted)] mb-1">Target Hours</label>
                  <input
                    type="number"
                    min="5"
                    max="500"
                    value={formData.targetHours}
                    onChange={(e) => setFormData({ ...formData, targetHours: parseInt(e.target.value) || 0 })}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                  />
                </div>

                <div>
                  <label className="block text-[var(--text-muted)] mb-1">Priority</label>
                  <select
                    value={formData.priority}
                    onChange={(e) => setFormData({ ...formData, priority: e.target.value as Priority })}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Critical">Critical</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[var(--text-muted)] mb-1">Accent Theme Color</label>
                <div className="flex gap-2">
                  {['#38bdf8', '#10b981', '#a855f7', '#f59e0b', '#ec4899', '#ef4444'].map((col) => (
                    <button
                      key={col}
                      type="button"
                      onClick={() => setFormData({ ...formData, accentColor: col })}
                      className={`w-7 h-7 rounded-full border-2 transition-transform ${
                        formData.accentColor === col ? 'scale-110 border-white' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: col }}
                    />
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[var(--border-subtle)]">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-[var(--text-muted)] hover:bg-[var(--bg-card)]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold hover:opacity-90"
                >
                  {editingSubject ? 'Update Subject' : 'Save Subject'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
