import React, { useState, useMemo } from 'react';
import {
  Play,
  Flame,
  Trophy,
  Target,
  Clock,
  BookOpen,
  Calendar,
  CheckCircle2,
  Plus,
  Sliders,
  Sparkles,
  ArrowRight,
  TrendingUp,
  FileText,
  AlertCircle,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';
import { DailyReportModal } from '../common/DailyReportModal';

interface DashboardViewProps {
  onNavigate: (view: string, detailId?: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate }) => {
  const {
    sessions,
    subjects,
    chapters,
    tasks,
    exams,
    profile,
    streakData,
    dailyGoals,
    updateDailyGoalTarget,
    addGoalTask,
    toggleGoalTask,
    quickStart,
    activeTimer,
    settings,
    updateSettings,
    dailyLeaderboard,
    deleteSession,
  } = useStudium();

  const [selectedReportDate, setSelectedReportDate] = useState<string | null>(null);
  const [newGoalTaskText, setNewGoalTaskText] = useState('');
  const [isCustomizeOpen, setIsCustomizeOpen] = useState(false);

  const todayStr = new Date().toISOString().slice(0, 10);
  const currentGoal = dailyGoals[todayStr] || {
    dateString: todayStr,
    targetMinutes: 0,
    targetPomodoros: 0,
    targetSessions: 0,
    targetChapters: 0,
    targetTasks: 0,
    tasks: [],
  };
  const hasDailyGoal = currentGoal.targetMinutes > 0;

  // Derive today's study minutes
  const todaySessions = useMemo(() => {
    return sessions.filter(s => s.dateString === todayStr);
  }, [sessions, todayStr]);

  const todayMinutes = useMemo(() => {
    return Math.round(todaySessions.reduce((acc, s) => acc + s.duration, 0) / 60);
  }, [todaySessions]);

  // Derive weekly study minutes
  const weekMinutes = useMemo(() => {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    const oneWeekAgoStr = oneWeekAgo.toISOString().slice(0, 10);
    return Math.round(
      sessions
        .filter(s => s.dateString >= oneWeekAgoStr)
        .reduce((acc, s) => acc + s.duration, 0) / 60
    );
  }, [sessions]);

  // Goal progress percentage
  const goalProgressPct = hasDailyGoal
    ? Math.min(100, Math.round((todayMinutes / currentGoal.targetMinutes) * 100))
    : 0;

  // User rank & nearby rivals
  const currentUserEntry = dailyLeaderboard?.currentUser || null;
  const currentRank = currentUserEntry?.rank || null;
  const minToOvertake = currentUserEntry?.nextRankGapMinutes || 0;

  // Next upcoming exam
  const nextExam = useMemo(() => {
    const sorted = [...exams].sort((a, b) => new Date(a.examDate).getTime() - new Date(b.examDate).getTime());
    return sorted[0];
  }, [exams]);

  const examDaysRemaining = useMemo(() => {
    if (!nextExam) return null;
    const examD = new Date(nextExam.examDate).getTime();
    const nowD = new Date().getTime();
    return Math.max(0, Math.ceil((examD - nowD) / (1000 * 60 * 60 * 24)));
  }, [nextExam]);

  // 35-day miniature heatmap calculation
  const miniHeatmapDays = useMemo(() => {
    const days: Array<{ dateStr: string; minutes: number }> = [];
    const dateMap: Record<string, number> = {};
    sessions.forEach(s => {
      dateMap[s.dateString] = (dateMap[s.dateString] || 0) + s.duration / 60;
    });

    for (let i = 34; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const str = d.toISOString().slice(0, 10);
      days.push({
        dateStr: str,
        minutes: Math.round(dateMap[str] || 0),
      });
    }
    return days;
  }, [sessions]);

  const handleAddGoalTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoalTaskText.trim()) return;
    addGoalTask(newGoalTaskText.trim());
    setNewGoalTaskText('');
  };

  const getHeatmapColor = (mins: number) => {
    if (mins === 0) return 'bg-[var(--bg-card)] border border-[var(--border-subtle)]';
    if (mins < 30) return 'bg-emerald-950/70 border border-emerald-800/40 text-emerald-400';
    if (mins < 60) return 'bg-emerald-800 border border-emerald-700 text-emerald-200';
    if (mins < 120) return 'bg-emerald-600 border border-emerald-500 text-white';
    return 'bg-emerald-400 border border-emerald-300 text-neutral-950';
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner / Today's Focus */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-5 rounded-2xl bg-[var(--bg-card)] border border-[var(--border-subtle)] shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--accent)]">
              Welcome Back, {profile.name}
            </span>
            <span className="text-[var(--text-dim)]">·</span>
            <span className="text-xs text-[var(--text-muted)]">
              {new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)] mt-0.5">
            {profile.studyTarget || 'Focus on Core Academic Milestones'}
          </h1>
        </div>

        {/* Dashboard Layout Switcher */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-[var(--bg-surface)] p-1 rounded-lg border border-[var(--border-subtle)] text-xs">
            <button
              onClick={() => updateSettings({ dashboardLayout: 'minimal' })}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                settings.dashboardLayout === 'minimal'
                  ? 'bg-[var(--bg-card)] text-[var(--text-main)] font-semibold shadow-xs'
                  : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
              }`}
            >
              Minimal
            </button>
            <button
              onClick={() => updateSettings({ dashboardLayout: 'standard' })}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                settings.dashboardLayout === 'standard'
                  ? 'bg-[var(--bg-card)] text-[var(--text-main)] font-semibold shadow-xs'
                  : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
              }`}
            >
              Standard
            </button>
            <button
              onClick={() => updateSettings({ dashboardLayout: 'detailed' })}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                settings.dashboardLayout === 'detailed'
                  ? 'bg-[var(--bg-card)] text-[var(--text-main)] font-semibold shadow-xs'
                  : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
              }`}
            >
              Detailed
            </button>
          </div>

          <button
            onClick={() => setIsCustomizeOpen(!isCustomizeOpen)}
            className="p-2 text-[var(--text-muted)] hover:text-[var(--text-main)] bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-lg transition-colors"
            title="Toggle Dashboard Widgets"
          >
            <Sliders className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Widget Customization Tray */}
      {isCustomizeOpen && (
        <div className="p-4 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] animate-in fade-in duration-150">
          <div className="text-xs font-semibold text-[var(--text-main)] mb-2">Visible Dashboard Widgets</div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            {[
              { id: 'dailyGoal', label: 'Daily Goal & Tasks' },
              { id: 'studyStats', label: 'Core Metrics Grid' },
              { id: 'weeklyLeague', label: 'League & Rank' },
              { id: 'streak', label: 'Streak Card' },
              { id: 'heatmap', label: 'Mini Heatmap' },
              { id: 'subjects', label: 'Subject Progress' },
              { id: 'recentSessions', label: 'Recent Sessions' },
              { id: 'tasks', label: 'Tasks To-Do' },
              { id: 'upcomingExam', label: 'Exam Countdown' },
            ].map((w) => {
              const enabled = settings.enabledWidgets[w.id] !== false;
              return (
                <button
                  key={w.id}
                  onClick={() =>
                    updateSettings({
                      enabledWidgets: {
                        ...settings.enabledWidgets,
                        [w.id]: !enabled,
                      },
                    })
                  }
                  className={`p-2 rounded-lg text-left border transition-colors flex items-center justify-between ${
                    enabled
                      ? 'bg-[var(--accent)]/10 border-[var(--accent)]/30 text-[var(--accent)] font-medium'
                      : 'bg-[var(--bg-surface)] border-[var(--border-subtle)] text-[var(--text-muted)]'
                  }`}
                >
                  <span className="truncate">{w.label}</span>
                  <span className="text-[10px]">{enabled ? '✓' : '✕'}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Primary KPI Grid (Core Metrics) */}
      {(settings.enabledWidgets.studyStats !== false || settings.dashboardLayout === 'minimal') && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {/* Today's Study Time */}
          <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-[var(--text-muted)]">Today's Focus</span>
              <Clock className="w-4 h-4 text-sky-400" />
            </div>
            <div className="mt-2 text-2xl font-bold font-mono text-[var(--text-main)] tabular-nums">
              {Math.floor(todayMinutes / 60)}h {todayMinutes % 60}m
            </div>
            <div className="mt-1 text-[11px] text-[var(--text-dim)]">
              {todaySessions.length} session{todaySessions.length !== 1 ? 's' : ''} logged today
            </div>
          </div>

          {/* Daily Streak */}
          <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-[var(--text-muted)]">Study Streak</span>
              <Flame className="w-4 h-4 text-amber-400 fill-amber-400" />
            </div>
            <div className="mt-2 text-2xl font-bold font-mono text-amber-400 tabular-nums">
              {streakData.currentStreak} <span className="text-sm font-sans font-medium text-[var(--text-muted)]">days</span>
            </div>
            <div className="mt-1 text-[11px] text-[var(--text-dim)]">
              Longest: {streakData.longestStreak} days
            </div>
          </div>

          {/* Weekly League Position */}
          <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-[var(--text-muted)]">NOTIQ League</span>
              <Trophy className="w-4 h-4 text-amber-400" />
            </div>
            <div className="mt-2 text-2xl font-bold font-mono text-[var(--text-main)] tabular-nums">
              {currentRank ? `#${currentRank}` : '—'} {currentUserEntry?.rankMovement ? <span className="text-xs font-sans text-emerald-400 font-semibold">{currentUserEntry.rankMovement > 0 ? `↑ ${currentUserEntry.rankMovement}` : `↓ ${Math.abs(currentUserEntry.rankMovement)}`}</span> : null}
            </div>
            <div className="mt-1 text-[11px] text-[var(--text-dim)] truncate">
              {currentRank && currentRank > 1 ? `${minToOvertake}m to #${currentRank - 1}` : currentRank === 1 ? 'You are currently #1' : 'Start studying to enter the leaderboard'}
            </div>
          </div>

          {/* Scholastic Level & XP */}
          <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-[var(--text-muted)]">Scholar XP</span>
              <Sparkles className="w-4 h-4 text-purple-400" />
            </div>
            <div className="mt-2 text-2xl font-bold font-mono text-purple-400 tabular-nums">
              {profile.xp.toLocaleString()} <span className="text-xs font-sans font-medium text-[var(--text-muted)]">XP</span>
            </div>
            <div className="mt-1 text-[11px] text-[var(--text-dim)]">
              Level {profile.level} Scholar
            </div>
          </div>
        </div>
      )}

      {/* Main 2-Column Split: Daily Goal & Active Session Launcher */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Daily Goal & Tasks */}
        {(settings.enabledWidgets.dailyGoal !== false || settings.dashboardLayout === 'minimal') && (
          <div className="lg:col-span-2 p-5 sm:p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-[var(--text-dim)] uppercase tracking-wider">
                  Target Discipline
                </span>
                <h2 className="text-base font-bold text-[var(--text-main)]">Daily Study Target</h2>
              </div>

              {/* Quick Goal Preset Buttons */}
              <div className="flex items-center gap-1.5 text-xs">
                {[60, 120, 180, 240].map((mins) => (
                  <button
                    key={mins}
                    onClick={() => updateDailyGoalTarget(mins)}
                    className={`px-2 py-1 rounded-md transition-colors ${
                      currentGoal.targetMinutes === mins
                        ? 'bg-[var(--accent)] text-[var(--accent-contrast)] font-bold'
                        : 'bg-[var(--bg-card)] text-[var(--text-muted)] hover:text-[var(--text-main)]'
                    }`}
                  >
                    {mins / 60}h
                  </button>
                ))}
              </div>
            </div>

            {/* Progress Bar & Numerical Readout */}
            <div className="space-y-2">
              <div className="flex justify-between items-baseline text-xs">
                <span className="text-[var(--text-muted)]">
                  Completed:{' '}
                  <strong className="text-[var(--text-main)] font-mono tabular-nums">
                    {Math.floor(todayMinutes / 60)}h {todayMinutes % 60}m
                  </strong>{' '}
                  / {hasDailyGoal ? `${Math.floor(currentGoal.targetMinutes / 60)}h ${currentGoal.targetMinutes % 60}m` : 'Not Set'}
                </span>
                <span className="font-mono font-bold text-[var(--accent)] tabular-nums">
                  {hasDailyGoal ? `${goalProgressPct}%` : 'Not Set'}
                </span>
              </div>

              <div className="w-full h-2.5 bg-[var(--bg-card)] rounded-full overflow-hidden">
                <div
                  className="h-full bg-[var(--accent)] transition-all duration-300 rounded-full"
                  style={{ width: `${goalProgressPct}%` }}
                />
              </div>
            </div>

            {/* Daily Goal Tasks Checklist */}
            <div className="pt-2 border-t border-[var(--border-subtle)] space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-[var(--text-main)]">Today's Study Checklist</span>
                <span className="text-[11px] text-[var(--text-dim)]">
                  {currentGoal.tasks.filter(t => t.completed).length}/{currentGoal.tasks.length} Done
                </span>
              </div>

              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {currentGoal.tasks.map((task) => (
                  <div
                    key={task.id}
                    onClick={() => toggleGoalTask(task.id)}
                    className={`flex items-center gap-2.5 p-2 rounded-xl text-xs cursor-pointer transition-colors border ${
                      task.completed
                        ? 'bg-[var(--bg-card)]/40 border-transparent text-[var(--text-dim)] line-through'
                        : 'bg-[var(--bg-card)] border-[var(--border-subtle)] text-[var(--text-main)] hover:border-[var(--border-active)]'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-md flex items-center justify-center shrink-0 border ${
                        task.completed
                          ? 'bg-[var(--accent)] border-[var(--accent)] text-[var(--accent-contrast)]'
                          : 'border-[var(--text-dim)]'
                      }`}
                    >
                      {task.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </div>
                    <span className="truncate flex-1">{task.title}</span>
                  </div>
                ))}
              </div>

              {/* Add checklist item */}
              <form onSubmit={handleAddGoalTask} className="flex gap-2 pt-1">
                <input
                  type="text"
                  placeholder="Add target task for today..."
                  value={newGoalTaskText}
                  onChange={(e) => setNewGoalTaskText(e.target.value)}
                  className="flex-1 text-xs px-3 py-1.5 rounded-lg bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] placeholder-[var(--text-dim)] focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={!newGoalTaskText.trim()}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 disabled:opacity-50 transition-colors"
                >
                  Add
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Right Column: 1-Click Study Launcher */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-[var(--text-dim)] uppercase tracking-wider">
                Immediate Action
              </span>
              {activeTimer.status === 'running' && (
                <span className="flex items-center gap-1 text-[11px] text-emerald-400 animate-pulse font-mono">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" /> Active Session
                </span>
              )}
            </div>
            <h2 className="text-base font-bold text-[var(--text-main)]">Start Studying</h2>
            <p className="text-xs text-[var(--text-muted)] mt-1">
              Launch a timed flow block in 1 click. Audio & analytics track automatically.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <button
              onClick={() => {
                quickStart(25, 'pomodoro');
                onNavigate('pomodoro');
              }}
              className="p-3 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] border border-[var(--border-subtle)] hover:border-[var(--accent)] transition-all text-left group"
            >
              <div className="text-xs font-bold text-[var(--text-main)] group-hover:text-[var(--accent)]">
                25m Focus
              </div>
              <div className="text-[10px] text-[var(--text-dim)]">Standard Pomodoro</div>
            </button>

            <button
              onClick={() => {
                quickStart(50, 'pomodoro');
                onNavigate('pomodoro');
              }}
              className="p-3 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] border border-[var(--border-subtle)] hover:border-[var(--accent)] transition-all text-left group"
            >
              <div className="text-xs font-bold text-[var(--text-main)] group-hover:text-[var(--accent)]">
                50m Deep
              </div>
              <div className="text-[10px] text-[var(--text-dim)]">Double Interval</div>
            </button>

            <button
              onClick={() => {
                quickStart(90, 'deepwork');
                onNavigate('timer');
              }}
              className="p-3 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] border border-[var(--border-subtle)] hover:border-[var(--accent)] transition-all text-left group"
            >
              <div className="text-xs font-bold text-[var(--text-main)] group-hover:text-[var(--accent)]">
                90m Flow
              </div>
              <div className="text-[10px] text-[var(--text-dim)]">Ultradian Deep Work</div>
            </button>

            <button
              onClick={() => onNavigate('timer')}
              className="p-3 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] border border-[var(--border-subtle)] hover:border-[var(--accent)] transition-all text-left group"
            >
              <div className="text-xs font-bold text-[var(--text-main)] group-hover:text-[var(--accent)]">
                Custom Setup
              </div>
              <div className="text-[10px] text-[var(--text-dim)]">Select Chapter & Note</div>
            </button>
          </div>

          <button
            onClick={() => onNavigate(activeTimer.mode === 'pomodoro' ? 'pomodoro' : 'timer')}
            className="w-full py-2.5 px-4 rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 font-semibold text-xs flex items-center justify-center gap-2 shadow-xs transition-all"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Open Dedicated Study Timer</span>
          </button>
        </div>
      </div>

      {/* Mini Heatmap & Consistency Preview */}
      {(settings.enabledWidgets.heatmap !== false && settings.dashboardLayout !== 'minimal') && (
        <div className="p-5 sm:p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-[var(--text-dim)] uppercase tracking-wider">
                Habit Consistency
              </span>
              <h2 className="text-base font-bold text-[var(--text-main)]">Recent 35-Day Heatmap</h2>
            </div>
            <button
              onClick={() => onNavigate('heatmap')}
              className="text-xs text-[var(--accent)] hover:underline flex items-center gap-1"
            >
              <span>Full 365-Day View</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <p className="text-xs text-[var(--text-muted)]">
            Click any day square to open its full daily study ledger with sessions and notes.
          </p>

          {/* Miniature Heatmap Squares */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {miniHeatmapDays.map((d) => (
              <button
                key={d.dateStr}
                onClick={() => setSelectedReportDate(d.dateStr)}
                title={`${d.dateStr}: ${d.minutes} mins studied`}
                className={`w-6 h-6 rounded-md transition-transform hover:scale-110 cursor-pointer ${getHeatmapColor(
                  d.minutes
                )}`}
              />
            ))}
          </div>

          <div className="flex items-center justify-between text-[11px] text-[var(--text-dim)] pt-1">
            <span>35 days ago</span>
            <div className="flex items-center gap-1 text-[10px]">
              <span>Less</span>
              <div className="w-2.5 h-2.5 rounded bg-[var(--bg-card)] border border-[var(--border-subtle)]" />
              <div className="w-2.5 h-2.5 rounded bg-emerald-950" />
              <div className="w-2.5 h-2.5 rounded bg-emerald-800" />
              <div className="w-2.5 h-2.5 rounded bg-emerald-600" />
              <div className="w-2.5 h-2.5 rounded bg-emerald-400" />
              <span>More</span>
            </div>
            <span>Today</span>
          </div>
        </div>
      )}

      {/* Row: Subjects Progress & Upcoming Exams & Recent Sessions */}
      {settings.dashboardLayout !== 'minimal' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Subject Syllabus Progress */}
          {settings.enabledWidgets.subjects !== false && (
            <div className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-[var(--text-main)]">Active Subjects</h3>
                <button
                  onClick={() => onNavigate('subjects')}
                  className="text-xs text-[var(--accent)] hover:underline"
                >
                  Manage
                </button>
              </div>

              <div className="space-y-2.5">
                {subjects.slice(0, 4).map((s) => {
                  const sSessions = sessions.filter(sess => sess.subjectId === s.id);
                  const totalMins = Math.round(sSessions.reduce((acc, sess) => acc + sess.duration, 0) / 60);
                  const sChapters = chapters.filter(c => c.subjectId === s.id);
                  const completedChaps = sChapters.filter(c => c.status === 'Completed').length;
                  const pct = sChapters.length > 0 ? Math.round((completedChaps / sChapters.length) * 100) : 0;

                  return (
                    <div
                      key={s.id}
                      onClick={() => onNavigate('subjects', s.id)}
                      className="p-3 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--bg-card-hover)] border border-[var(--border-subtle)] cursor-pointer transition-colors"
                    >
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: s.accentColor }} />
                          <span className="font-semibold text-[var(--text-main)] truncate max-w-[140px]">
                            {s.name}
                          </span>
                        </div>
                        <span className="font-mono text-[var(--text-muted)] tabular-nums">
                          {Math.round(totalMins / 60)}h / {s.targetHours}h
                        </span>
                      </div>
                      <div className="w-full h-1.5 bg-[var(--bg-base)] rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${pct}%`,
                            backgroundColor: s.accentColor,
                          }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Upcoming Exam Countdown */}
          {settings.enabledWidgets.upcomingExam !== false && (
            <div className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-[var(--text-main)]">Upcoming Exam</h3>
                <button
                  onClick={() => onNavigate('exams')}
                  className="text-xs text-[var(--accent)] hover:underline"
                >
                  All ({exams.length})
                </button>
              </div>

              {nextExam ? (
                <div className="p-4 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] space-y-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-semibold text-amber-400 uppercase tracking-wider">
                        {nextExam.priority} Priority
                      </span>
                      <div className="text-sm font-bold text-[var(--text-main)] mt-0.5">
                        {nextExam.name}
                      </div>
                    </div>
                    <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 font-mono font-bold text-center">
                      <div className="text-lg leading-tight tabular-nums">{examDaysRemaining}</div>
                      <div className="text-[9px] uppercase tracking-wider">Days left</div>
                    </div>
                  </div>

                  <div className="text-xs text-[var(--text-muted)]">
                    Date: {nextExam.examDate} · {nextExam.examTime}
                  </div>
                  {nextExam.location && (
                    <div className="text-[11px] text-[var(--text-dim)]">Venue: {nextExam.location}</div>
                  )}
                </div>
              ) : (
                <div className="p-6 text-center text-xs text-[var(--text-muted)] bg-[var(--bg-card)] rounded-xl">
                  No upcoming exams scheduled.
                </div>
              )}

              {/* Spaced Revision Reminder */}
              <div
                onClick={() => onNavigate('revision')}
                className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 text-xs flex items-center justify-between cursor-pointer hover:bg-purple-500/15 transition-colors"
              >
                <div>
                  <div className="font-semibold text-purple-300">Spaced Revision Queue</div>
                  <div className="text-[11px] text-[var(--text-muted)]">
                    {chapters.filter(c => c.revisionRequired).length} chapters due for retention review
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-purple-400" />
              </div>
            </div>
          )}

          {/* Recent Study Sessions */}
          {settings.enabledWidgets.recentSessions !== false && (
            <div className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-[var(--text-main)]">Recent Study Logs</h3>
                <button
                  onClick={() => onNavigate('timer')}
                  className="text-xs text-[var(--accent)] hover:underline"
                >
                  History
                </button>
              </div>

              <div className="space-y-2">
                {sessions.slice(0, 4).map((sess) => {
                  const s = subjects.find(sub => sub.id === sess.subjectId);
                  return (
                    <div
                      key={sess.id}
                      className="p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-xs flex items-center justify-between group"
                    >
                      <div className="min-w-0 pr-2">
                        <div className="font-semibold text-[var(--text-main)] truncate">
                          {s?.name || 'Study'}
                        </div>
                        <div className="text-[11px] text-[var(--text-dim)] truncate">
                          {sess.studyType} · {sess.dateString}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-[var(--text-main)] tabular-nums">
                          {Math.round(sess.duration / 60)}m
                        </span>
                        <button
                          onClick={() => deleteSession(sess.id)}
                          className="opacity-0 group-hover:opacity-100 p-1 text-[var(--text-dim)] hover:text-red-400 transition-opacity"
                          title="Delete session record"
                        >
                          ✕
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Daily Report Modal when clicking a heatmap day */}
      <DailyReportModal
        dateString={selectedReportDate}
        onClose={() => setSelectedReportDate(null)}
      />
    </div>
  );
};
