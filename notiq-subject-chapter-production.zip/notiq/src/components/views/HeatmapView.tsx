import React, { useState, useMemo } from 'react';
import {
  Flame,
  Calendar,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Filter,
  Trophy,
  ArrowRight,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';
import { DailyReportModal } from '../common/DailyReportModal';

export const HeatmapView: React.FC = () => {
  const { sessions, streakData, subjects, settings } = useStudium();

  const [timeRangeDays, setTimeRangeDays] = useState<number>(90);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('all');
  const [selectedReportDate, setSelectedReportDate] = useState<string | null>(null);

  // Group minutes by date
  const heatmapData = useMemo(() => {
    const filteredSessions = sessions.filter(s => {
      if (selectedSubjectId !== 'all' && s.subjectId !== selectedSubjectId) return false;
      return true;
    });

    const dateMap: Record<string, { minutes: number; sessionCount: number; pomoCount: number }> = {};
    filteredSessions.forEach(s => {
      if (!dateMap[s.dateString]) {
        dateMap[s.dateString] = { minutes: 0, sessionCount: 0, pomoCount: 0 };
      }
      dateMap[s.dateString].minutes += s.duration / 60;
      dateMap[s.dateString].sessionCount += 1;
      if (s.timerMode === 'pomodoro') dateMap[s.dateString].pomoCount += 1;
    });

    const days: Array<{
      dateStr: string;
      minutes: number;
      sessionCount: number;
      pomoCount: number;
      dayOfWeek: number;
    }> = [];

    for (let i = timeRangeDays - 1; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const str = d.toISOString().slice(0, 10);
      const entry = dateMap[str] || { minutes: 0, sessionCount: 0, pomoCount: 0 };
      days.push({
        dateStr: str,
        minutes: Math.round(entry.minutes),
        sessionCount: entry.sessionCount,
        pomoCount: entry.pomoCount,
        dayOfWeek: d.getDay(),
      });
    }

    return days;
  }, [sessions, selectedSubjectId, timeRangeDays]);

  const getIntensityClass = (mins: number) => {
    if (mins === 0) return 'bg-[var(--bg-card)] border border-[var(--border-subtle)]';
    if (mins < 30) return 'bg-emerald-950/70 border border-emerald-800/40 text-emerald-400';
    if (mins < 60) return 'bg-emerald-800 border border-emerald-700 text-emerald-200';
    if (mins < 120) return 'bg-emerald-600 border border-emerald-500 text-white';
    return 'bg-emerald-400 border border-emerald-300 text-neutral-950 font-bold';
  };

  const streakMilestones = [
    { target: 3, label: '3-Day Fire', unlocked: streakData.currentStreak >= 3 },
    { target: 7, label: '7-Day Iron Discipline', unlocked: streakData.currentStreak >= 7 },
    { target: 14, label: '14-Day Fortitude', unlocked: streakData.currentStreak >= 14 },
    { target: 30, label: '30-Day Dynasty', unlocked: streakData.currentStreak >= 30 },
    { target: 60, label: '60-Day Master', unlocked: streakData.currentStreak >= 60 },
    { target: 100, label: '100-Day Centurion', unlocked: streakData.currentStreak >= 100 },
    { target: 365, label: '365-Day Immortal', unlocked: streakData.currentStreak >= 365 },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[var(--border-subtle)] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
            Habit Heatmap & Study Streaks
          </h1>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Visualize your consistent dedication across calendar months. Click any day to view its complete ledger.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Subject Filter */}
          <select
            value={selectedSubjectId}
            onChange={(e) => setSelectedSubjectId(e.target.value)}
            className="text-xs p-2 rounded-xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-[var(--text-main)]"
          >
            <option value="all">All Subjects</option>
            {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>

          {/* Time Range Selector */}
          <div className="flex items-center bg-[var(--bg-surface)] p-1 rounded-xl border border-[var(--border-subtle)] text-xs">
            {[35, 90, 180, 365].map((days) => (
              <button
                key={days}
                onClick={() => setTimeRangeDays(days)}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  timeRangeDays === days
                    ? 'bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold shadow-xs'
                    : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
                }`}
              >
                {days}d
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Streak Performance Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-[var(--text-muted)]">Active Streak</span>
            <Flame className="w-4 h-4 text-amber-400 fill-amber-400" />
          </div>
          <div className="mt-2 text-3xl font-bold font-mono text-amber-400 tabular-nums">
            {streakData.currentStreak} <span className="text-sm font-sans font-medium text-[var(--text-muted)]">Days</span>
          </div>
          <span className="text-[10px] text-[var(--text-dim)]">Daily target: {settings.streakRequirementMinutes}m</span>
        </div>

        <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-[var(--text-muted)]">Longest Streak</span>
            <Trophy className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 text-3xl font-bold font-mono text-[var(--text-main)] tabular-nums">
            {streakData.longestStreak} <span className="text-sm font-sans font-medium text-[var(--text-muted)]">Days</span>
          </div>
          <span className="text-[10px] text-[var(--text-dim)]">All-time personal record</span>
        </div>

        <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-[var(--text-muted)]">Streak Protection</span>
            <ShieldCheck className="w-4 h-4 text-sky-400" />
          </div>
          <div className="mt-2 text-3xl font-bold font-mono text-sky-400 tabular-nums">
            {streakData.streakFreezesLeft} <span className="text-sm font-sans font-medium text-[var(--text-muted)]">Freezes</span>
          </div>
          <span className="text-[10px] text-[var(--text-dim)]">Auto-preserves missed days</span>
        </div>

        <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-[var(--text-muted)]">Consistency Rate</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-3xl font-bold font-mono text-emerald-400 tabular-nums">
            {Math.round((streakData.streakHistory.filter(h => h.achieved).length / Math.max(1, streakData.streakHistory.length)) * 100)}%
          </div>
          <span className="text-[10px] text-[var(--text-dim)]">Active study frequency</span>
        </div>
      </div>

      {/* Main Interactive Heatmap Board */}
      <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-[var(--text-main)]">
            Study Activity Ledger ({timeRangeDays} Days)
          </h2>
          <div className="flex items-center gap-1.5 text-xs text-[var(--text-muted)]">
            <span className="text-[11px] text-[var(--text-dim)] mr-1">0m</span>
            <div className="w-3.5 h-3.5 rounded bg-[var(--bg-card)] border border-[var(--border-subtle)]" />
            <div className="w-3.5 h-3.5 rounded bg-emerald-950" />
            <div className="w-3.5 h-3.5 rounded bg-emerald-800" />
            <div className="w-3.5 h-3.5 rounded bg-emerald-600" />
            <div className="w-3.5 h-3.5 rounded bg-emerald-400" />
            <span className="text-[11px] text-[var(--text-dim)] ml-1">120m+</span>
          </div>
        </div>

        {/* Heatmap Grid */}
        <div className="flex flex-wrap gap-1.5 p-4 rounded-xl bg-[var(--bg-card)]/50 border border-[var(--border-subtle)] max-h-[450px] overflow-y-auto">
          {heatmapData.map((d) => (
            <button
              key={d.dateStr}
              onClick={() => setSelectedReportDate(d.dateStr)}
              className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg transition-transform hover:scale-115 cursor-pointer relative group flex items-center justify-center text-[10px] ${getIntensityClass(
                d.minutes
              )}`}
            >
              {/* Tooltip */}
              <div className="absolute bottom-full mb-2 hidden group-hover:block z-50 pointer-events-none">
                <div className="bg-neutral-900 border border-neutral-700 text-white text-[11px] py-1 px-2.5 rounded-lg shadow-xl whitespace-nowrap">
                  <div className="font-semibold">{d.dateStr}</div>
                  <div className="text-[10px] text-neutral-300">
                    {d.minutes} mins · {d.sessionCount} sessions
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Streak Milestones Progression */}
      <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
        <h2 className="text-base font-bold text-[var(--text-main)]">Habit Streak Milestones</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 text-xs">
          {streakMilestones.map((m) => (
            <div
              key={m.target}
              className={`p-3 rounded-xl border text-center transition-all ${
                m.unlocked
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                  : 'bg-[var(--bg-card)] border-[var(--border-subtle)] text-[var(--text-dim)] opacity-60'
              }`}
            >
              <Flame className={`w-5 h-5 mx-auto mb-1 ${m.unlocked ? 'fill-amber-400 text-amber-400' : 'text-neutral-600'}`} />
              <div className="font-bold font-mono">{m.target} Days</div>
              <div className="text-[10px] mt-0.5">{m.unlocked ? 'Unlocked' : 'Locked'}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Daily Study Report Modal */}
      <DailyReportModal
        dateString={selectedReportDate}
        onClose={() => setSelectedReportDate(null)}
      />
    </div>
  );
};
