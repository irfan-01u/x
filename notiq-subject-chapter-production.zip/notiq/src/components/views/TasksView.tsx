import React, { useState, useMemo } from 'react';
import {
  ListTodo,
  Plus,
  Play,
  CheckCircle2,
  Trash2,
  Calendar,
  Clock,
  Filter,
  X,
  Edit3,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';
import { Task, Priority } from '../../types';

interface TasksViewProps {
  onNavigate: (view: string) => void;
}

export const TasksView: React.FC<TasksViewProps> = ({ onNavigate }) => {
  const {
    tasks,
    subjects,
    chapters,
    addTask,
    updateTask,
    deleteTask,
    toggleTaskCompletion,
    startTimerFromTask,
  } = useStudium();

  const [activeFilter, setActiveFilter] = useState<'all' | 'today' | 'pending' | 'completed'>('all');
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    title: '',
    subjectId: subjects[0]?.id || '',
    chapterId: '',
    priority: 'Medium' as 'Low' | 'Medium' | 'High',
    deadline: '',
    estimatedMinutes: 30,
    scheduledDate: new Date().toISOString().slice(0, 10),
  });

  const availableChapters = useMemo(() => {
    return chapters.filter(c => c.subjectId === formData.subjectId);
  }, [chapters, formData.subjectId]);

  const todayStr = new Date().toISOString().slice(0, 10);

  const filteredTasks = useMemo(() => {
    return tasks.filter((t) => {
      if (activeFilter === 'today' && t.scheduledDate !== todayStr) return false;
      if (activeFilter === 'pending' && t.completed) return false;
      if (activeFilter === 'completed' && !t.completed) return false;
      if (selectedSubjectFilter !== 'all' && t.subjectId !== selectedSubjectFilter) return false;
      return true;
    });
  }, [tasks, activeFilter, selectedSubjectFilter, todayStr]);

  const handleOpenCreate = () => {
    setFormData({
      title: '',
      subjectId: subjects[0]?.id || '',
      chapterId: '',
      priority: 'Medium',
      deadline: '',
      estimatedMinutes: 30,
      scheduledDate: todayStr,
    });
    setEditingTask(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (task: Task) => {
    setFormData({
      title: task.title,
      subjectId: task.subjectId || subjects[0]?.id || '',
      chapterId: task.chapterId || '',
      priority: task.priority,
      deadline: task.deadline || '',
      estimatedMinutes: task.estimatedMinutes,
      scheduledDate: task.scheduledDate || todayStr,
    });
    setEditingTask(task);
    setIsModalOpen(true);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return;

    if (editingTask) {
      updateTask(editingTask.id, formData);
    } else {
      addTask({
        ...formData,
        completed: false,
        order: tasks.length,
      });
    }
    setIsModalOpen(false);
  };

  const handleLaunchTimer = (task: Task) => {
    startTimerFromTask(task);
    onNavigate('timer');
  };

  const priorityColors = {
    Low: 'text-neutral-400 bg-neutral-800/40',
    Medium: 'text-sky-400 bg-sky-950/40 border border-sky-800/30',
    High: 'text-amber-400 bg-amber-950/40 border border-amber-800/30',
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[var(--border-subtle)] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
            Academic Tasks & To-Do
          </h1>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Organize study objectives, set time budgets, and launch focused timer sessions directly from tasks.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 shadow-xs transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>New Task</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs">
        <div className="flex items-center gap-1 p-1 bg-[var(--bg-card)] rounded-xl border border-[var(--border-subtle)]">
          {(['all', 'today', 'pending', 'completed'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveFilter(tab)}
              className={`px-3 py-1 rounded-lg capitalize transition-colors ${
                activeFilter === tab
                  ? 'bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold'
                  : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedSubjectFilter}
            onChange={(e) => setSelectedSubjectFilter(e.target.value)}
            className="p-2 rounded-lg bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] text-xs"
          >
            <option value="all">All Subjects</option>
            {subjects.map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Task List */}
      <div className="space-y-2.5">
        {filteredTasks.length === 0 ? (
          <div className="text-center py-16 text-xs text-[var(--text-muted)] bg-[var(--bg-surface)] rounded-2xl border border-[var(--border-subtle)]">
            No study tasks match this filter. Create one to get started!
          </div>
        ) : (
          filteredTasks.map((task) => {
            const subj = subjects.find(s => s.id === task.subjectId);
            const chap = chapters.find(c => c.id === task.chapterId);

            return (
              <div
                key={task.id}
                className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 group ${
                  task.completed
                    ? 'bg-[var(--bg-surface)]/60 border-transparent text-[var(--text-dim)]'
                    : 'bg-[var(--bg-surface)] border-[var(--border-subtle)] hover:border-[var(--border-active)]'
                }`}
              >
                <div className="flex items-start gap-3 min-w-0">
                  <button
                    onClick={() => toggleTaskCompletion(task.id)}
                    className={`mt-0.5 w-5 h-5 rounded-md flex items-center justify-center shrink-0 border transition-colors ${
                      task.completed
                        ? 'bg-[var(--accent)] border-[var(--accent)] text-[var(--accent-contrast)]'
                        : 'border-[var(--border-active)] hover:border-[var(--accent)]'
                    }`}
                  >
                    {task.completed && <CheckCircle2 className="w-4 h-4" />}
                  </button>

                  <div className="min-w-0">
                    <div className={`text-xs font-semibold ${task.completed ? 'line-through text-[var(--text-dim)]' : 'text-[var(--text-main)]'}`}>
                      {task.title}
                    </div>
                    <div className="flex items-center gap-2 mt-1 text-[11px] text-[var(--text-dim)] flex-wrap">
                      {subj && (
                        <span className="flex items-center gap-1 font-medium text-[var(--text-muted)]">
                          <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: subj.accentColor }} />
                          {subj.name}
                        </span>
                      )}
                      {chap && <span>/ {chap.name}</span>}
                      <span>·</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {task.estimatedMinutes}m est
                      </span>
                      {task.deadline && (
                        <>
                          <span>·</span>
                          <span className="flex items-center gap-1 text-amber-400">
                            <Calendar className="w-3 h-3" />
                            Due {task.deadline}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Actions & Launch Timer */}
                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${priorityColors[task.priority]}`}>
                    {task.priority}
                  </span>

                  {!task.completed && (
                    <button
                      onClick={() => handleLaunchTimer(task)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 shadow-xs transition-all"
                      title="Start dedicated timer for this task"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Start Timer</span>
                    </button>
                  )}

                  <button
                    onClick={() => handleOpenEdit(task)}
                    className="p-1.5 text-[var(--text-dim)] hover:text-[var(--text-main)] rounded-lg"
                    title="Edit task"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => deleteTask(task.id)}
                    className="p-1.5 text-[var(--text-dim)] hover:text-red-400 rounded-lg"
                    title="Delete task"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Task Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-2xl shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-[var(--text-main)]">
                {editingTask ? 'Edit Task' : 'Create Study Task'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-[var(--text-dim)] hover:text-[var(--text-main)]">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveForm} className="space-y-3 text-xs">
              <div>
                <label className="block text-[var(--text-muted)] mb-1">Task Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Complete 5 Practice Problems on Dijkstra"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                />
              </div>

              <div>
                <label className="block text-[var(--text-muted)] mb-1">Subject</label>
                <select
                  value={formData.subjectId}
                  onChange={(e) => setFormData({ ...formData, subjectId: e.target.value, chapterId: '' })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                >
                  {subjects.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[var(--text-muted)] mb-1">Chapter (Optional)</label>
                <select
                  value={formData.chapterId}
                  onChange={(e) => setFormData({ ...formData, chapterId: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                >
                  <option value="">-- No specific chapter --</option>
                  {availableChapters.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[var(--text-muted)] mb-1">Priority</label>
                  <select
                    value={formData.priority}
                    onChange={(e) => setFormData({ ...formData, priority: e.target.value as 'Low' | 'Medium' | 'High' })}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[var(--text-muted)] mb-1">Estimated Minutes</label>
                  <input
                    type="number"
                    min="5"
                    max="240"
                    step="5"
                    value={formData.estimatedMinutes}
                    onChange={(e) => setFormData({ ...formData, estimatedMinutes: parseInt(e.target.value) || 30 })}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[var(--text-muted)] mb-1">Scheduled Date</label>
                  <input
                    type="date"
                    value={formData.scheduledDate}
                    onChange={(e) => setFormData({ ...formData, scheduledDate: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                  />
                </div>

                <div>
                  <label className="block text-[var(--text-muted)] mb-1">Deadline (Optional)</label>
                  <input
                    type="date"
                    value={formData.deadline}
                    onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[var(--border-subtle)]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-[var(--text-muted)] hover:bg-[var(--bg-card)]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold hover:opacity-90"
                >
                  Save Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
