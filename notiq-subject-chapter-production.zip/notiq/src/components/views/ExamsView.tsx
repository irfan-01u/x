import React, { useState, useMemo } from 'react';
import {
  GraduationCap,
  Plus,
  Calendar,
  Clock,
  MapPin,
  Trash2,
  Edit3,
  X,
  AlertTriangle,
  BookmarkCheck,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';
import { Exam, Priority } from '../../types';

export const ExamsView: React.FC = () => {
  const { exams, subjects, chapters, addExam, updateExam, deleteExam } = useStudium();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingExam, setEditingExam] = useState<Exam | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    subjectId: subjects[0]?.id || '',
    examDate: '',
    examTime: '09:00',
    location: '',
    notes: '',
    priority: 'High' as 'Low' | 'Medium' | 'High',
  });

  const sortedExams = useMemo(() => {
    return [...exams].sort((a, b) => new Date(a.examDate).getTime() - new Date(b.examDate).getTime());
  }, [exams]);

  const handleOpenCreate = () => {
    setFormData({
      name: '',
      subjectId: subjects[0]?.id || '',
      examDate: '',
      examTime: '09:00',
      location: '',
      notes: '',
      priority: 'High',
    });
    setEditingExam(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (exam: Exam) => {
    setFormData({
      name: exam.name,
      subjectId: exam.subjectId,
      examDate: exam.examDate,
      examTime: exam.examTime,
      location: exam.location || '',
      notes: exam.notes || '',
      priority: exam.priority,
    });
    setEditingExam(exam);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.examDate) return;

    if (editingExam) {
      updateExam(editingExam.id, formData);
    } else {
      addExam(formData);
    }
    setIsModalOpen(false);
  };

  const priorityColors = {
    Low: 'text-neutral-400 bg-neutral-800/40',
    Medium: 'text-sky-400 bg-sky-950/40 border border-sky-800/30',
    High: 'text-rose-400 bg-rose-950/40 border border-rose-800/30',
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[var(--border-subtle)] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
            Exam & Deadline Countdown
          </h1>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Monitor target exam dates, revision readiness, and subject syllabus preparedness.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 shadow-xs transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Add Exam Target</span>
        </button>
      </div>

      {/* Exam Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sortedExams.length === 0 ? (
          <div className="col-span-2 text-center py-16 text-xs text-[var(--text-muted)] bg-[var(--bg-surface)] rounded-2xl border border-[var(--border-subtle)]">
            No exams registered. Add your midterm or final examination targets!
          </div>
        ) : (
          sortedExams.map((exam) => {
            const subj = subjects.find(s => s.id === exam.subjectId);
            const sChapters = chapters.filter(c => c.subjectId === exam.subjectId);
            const completedCount = sChapters.filter(c => c.status === 'Completed').length;
            const prepPct = sChapters.length > 0 ? Math.round((completedCount / sChapters.length) * 100) : 0;

            const examTimeMs = new Date(exam.examDate + 'T' + exam.examTime).getTime();
            const nowMs = new Date().getTime();
            const daysLeft = Math.ceil((examTimeMs - nowMs) / (1000 * 60 * 60 * 24));
            const isOverdue = daysLeft < 0;

            return (
              <div
                key={exam.id}
                className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4 relative overflow-hidden group shadow-xs"
              >
                {/* Top row */}
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-semibold text-[var(--text-muted)] uppercase tracking-wider">
                      {subj?.name || 'General Exam'}
                    </span>
                    <h3 className="font-bold text-base text-[var(--text-main)] mt-0.5">{exam.name}</h3>
                  </div>

                  {/* Countdown Badge */}
                  <div className={`p-2.5 rounded-xl font-mono text-center shrink-0 border ${
                    isOverdue
                      ? 'bg-red-500/10 border-red-500/30 text-red-400'
                      : daysLeft <= 14
                      ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
                      : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                  }`}>
                    <div className="text-xl font-bold leading-none tabular-nums">
                      {isOverdue ? 'Passed' : daysLeft}
                    </div>
                    {!isOverdue && <div className="text-[9px] uppercase tracking-wider mt-0.5">Days Left</div>}
                  </div>
                </div>

                {/* Exam Details */}
                <div className="space-y-1.5 text-xs text-[var(--text-muted)]">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-[var(--text-dim)]" />
                    <span>{new Date(exam.examDate).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })} at {exam.examTime}</span>
                  </div>
                  {exam.location && (
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-[var(--text-dim)]" />
                      <span>{exam.location}</span>
                    </div>
                  )}
                  {exam.notes && (
                    <p className="text-[11px] text-[var(--text-dim)] italic pt-1 border-t border-[var(--border-subtle)]">
                      "{exam.notes}"
                    </p>
                  )}
                </div>

                {/* Preparation Progress Bar */}
                <div className="space-y-1.5 pt-2 border-t border-[var(--border-subtle)]">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-[var(--text-muted)]">Syllabus Preparedness</span>
                    <span className="font-mono font-bold text-[var(--accent)]">{prepPct}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-[var(--bg-card)] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[var(--accent)] rounded-full"
                      style={{ width: `${prepPct}%` }}
                    />
                  </div>
                  <div className="text-[10px] text-[var(--text-dim)]">
                    {completedCount} of {sChapters.length} chapters conquered
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-2">
                  <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${priorityColors[exam.priority]}`}>
                    {exam.priority} Priority
                  </span>

                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => handleOpenEdit(exam)}
                      className="p-1.5 text-[var(--text-dim)] hover:text-[var(--text-main)] rounded-lg"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteExam(exam.id)}
                      className="p-1.5 text-[var(--text-dim)] hover:text-red-400 rounded-lg"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-2xl shadow-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-[var(--text-main)]">
              {editingExam ? 'Edit Exam Target' : 'Register Exam Target'}
            </h3>

            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="block text-[var(--text-muted)] mb-1">Exam Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Midterm: Classical Electrodynamics"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                />
              </div>

              <div>
                <label className="block text-[var(--text-muted)] mb-1">Subject</label>
                <select
                  value={formData.subjectId}
                  onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                >
                  {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[var(--text-muted)] mb-1">Exam Date *</label>
                  <input
                    type="date"
                    required
                    value={formData.examDate}
                    onChange={(e) => setFormData({ ...formData, examDate: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                  />
                </div>

                <div>
                  <label className="block text-[var(--text-muted)] mb-1">Exam Time</label>
                  <input
                    type="time"
                    value={formData.examTime}
                    onChange={(e) => setFormData({ ...formData, examTime: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[var(--text-muted)] mb-1">Location / Examination Hall</label>
                <input
                  type="text"
                  placeholder="e.g. Hall 402, North Campus"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                />
              </div>

              <div>
                <label className="block text-[var(--text-muted)] mb-1">Notes / Permitted Materials</label>
                <textarea
                  rows={2}
                  placeholder="e.g. 1-page formula sheet allowed, scientific calculator"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[var(--border-subtle)]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-[var(--text-muted)] hover:bg-[var(--bg-card)]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold hover:opacity-90"
                >
                  Save Exam
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
