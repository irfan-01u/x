import React, { useState, useMemo } from 'react';
import {
  Calendar,
  Clock,
  Plus,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Trash2,
  ChevronLeft,
  ChevronRight,
  BookOpen,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';
import { StudyBlock } from '../../types';

export const PlannerView: React.FC = () => {
  const { studyBlocks, subjects, sessions, addStudyBlock, updateStudyBlock, deleteStudyBlock } = useStudium();

  const [activeTab, setActiveTab] = useState<'daily' | 'weekly'>('weekly');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    title: '',
    subjectId: subjects[0]?.id || '',
    dayOfWeek: 1, // Monday
    startTime: '09:00',
    endTime: '10:30',
    status: 'Planned' as StudyBlock['status'],
  });

  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  // Planned hours calculation
  const plannedMinutesTotal = useMemo(() => {
    return studyBlocks.reduce((acc, b) => {
      const [sh, sm] = b.startTime.split(':').map(Number);
      const [eh, em] = b.endTime.split(':').map(Number);
      const dur = (eh * 60 + em) - (sh * 60 + sm);
      return acc + Math.max(0, dur);
    }, 0);
  }, [studyBlocks]);

  // Actual hours from sessions in the past 7 days
  const actualMinutesTotal = useMemo(() => {
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    const weekAgoStr = weekAgo.toISOString().slice(0, 10);
    return Math.round(
      sessions
        .filter(s => s.dateString >= weekAgoStr)
        .reduce((acc, s) => acc + s.duration, 0) / 60
    );
  }, [sessions]);

  const handleSaveBlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return;
    addStudyBlock(formData);
    setIsModalOpen(false);
  };

  const getStatusBadge = (status: StudyBlock['status']) => {
    if (status === 'Completed') return 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20';
    if (status === 'Skipped') return 'bg-red-500/10 text-red-400 border border-red-500/20';
    if (status === 'Rescheduled') return 'bg-amber-500/10 text-amber-400 border border-amber-500/20';
    return 'bg-sky-500/10 text-sky-400 border border-sky-500/20';
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[var(--border-subtle)] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
            Academic Study Planner
          </h1>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Structured timetable schedule blocks with Planned vs. Actual velocity analysis.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex bg-[var(--bg-surface)] p-1 rounded-xl border border-[var(--border-subtle)] text-xs">
            <button
              onClick={() => setActiveTab('weekly')}
              className={`px-3 py-1 rounded-lg transition-colors font-medium ${
                activeTab === 'weekly'
                  ? 'bg-[var(--accent)] text-[var(--accent-contrast)] shadow-xs'
                  : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
              }`}
            >
              Weekly Timetable
            </button>
            <button
              onClick={() => setActiveTab('daily')}
              className={`px-3 py-1 rounded-lg transition-colors font-medium ${
                activeTab === 'daily'
                  ? 'bg-[var(--accent)] text-[var(--accent-contrast)] shadow-xs'
                  : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
              }`}
            >
              Today's Schedule
            </button>
          </div>

          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] hover:opacity-90 shadow-xs transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Study Block</span>
          </button>
        </div>
      </div>

      {/* Planned vs Actual Analytics Bar */}
      <div className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
        <div>
          <span className="text-[var(--text-muted)]">Planned Commitment</span>
          <div className="mt-1 font-mono font-bold text-xl text-[var(--text-main)]">
            {Math.floor(plannedMinutesTotal / 60)}h {plannedMinutesTotal % 60}m
          </div>
          <span className="text-[10px] text-[var(--text-dim)]">{studyBlocks.length} scheduled blocks</span>
        </div>

        <div>
          <span className="text-[var(--text-muted)]">Actual Realized Study</span>
          <div className="mt-1 font-mono font-bold text-xl text-emerald-400">
            {Math.floor(actualMinutesTotal / 60)}h {actualMinutesTotal % 60}m
          </div>
          <span className="text-[10px] text-[var(--text-dim)]">past 7 days completed</span>
        </div>

        <div>
          <span className="text-[var(--text-muted)]">Adherence Velocity</span>
          <div className="mt-1 font-mono font-bold text-xl text-[var(--accent)]">
            {plannedMinutesTotal > 0 ? Math.round((actualMinutesTotal / plannedMinutesTotal) * 100) : 100}%
          </div>
          <span className="text-[10px] text-[var(--text-dim)]">Target adherence rate</span>
        </div>
      </div>

      {/* Weekly Timetable Grid */}
      {activeTab === 'weekly' && (
        <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
          {daysOfWeek.map((dayName, dayIndex) => {
            const dayBlocks = studyBlocks.filter(b => b.dayOfWeek === dayIndex);
            const isToday = new Date().getDay() === dayIndex;

            return (
              <div
                key={dayName}
                className={`p-3 rounded-2xl border transition-colors min-h-[350px] flex flex-col ${
                  isToday
                    ? 'bg-[var(--bg-card)] border-[var(--accent)] shadow-xs'
                    : 'bg-[var(--bg-surface)] border-[var(--border-subtle)]'
                }`}
              >
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-[var(--border-subtle)]">
                  <span className={`text-xs font-bold ${isToday ? 'text-[var(--accent)]' : 'text-[var(--text-main)]'}`}>
                    {dayName.slice(0, 3)}
                  </span>
                  {isToday && (
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-[var(--accent)] text-[var(--accent-contrast)] font-bold">
                      TODAY
                    </span>
                  )}
                </div>

                <div className="space-y-2 flex-1 overflow-y-auto">
                  {dayBlocks.length === 0 ? (
                    <div className="text-center py-8 text-[11px] text-[var(--text-dim)]">
                      No blocks
                    </div>
                  ) : (
                    dayBlocks.map((block) => {
                      const subj = subjects.find(s => s.id === block.subjectId);
                      return (
                        <div
                          key={block.id}
                          className="p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-xs space-y-1.5 group"
                        >
                          <div className="flex items-start justify-between">
                            <span className="font-semibold text-[var(--text-main)] truncate max-w-[100px]">
                              {block.title}
                            </span>
                            <button
                              onClick={() => deleteStudyBlock(block.id)}
                              className="text-[var(--text-dim)] hover:text-red-400 p-0.5 opacity-0 group-hover:opacity-100"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>

                          <div className="text-[10px] text-[var(--text-dim)] font-mono">
                            {block.startTime} – {block.endTime}
                          </div>

                          <div className="flex items-center justify-between pt-1">
                            <span
                              className="text-[10px] truncate max-w-[80px]"
                              style={{ color: subj?.accentColor || 'var(--accent)' }}
                            >
                              {subj?.name}
                            </span>
                            <button
                              onClick={() => {
                                const nextStatus =
                                  block.status === 'Planned'
                                    ? 'Completed'
                                    : block.status === 'Completed'
                                    ? 'Skipped'
                                    : 'Planned';
                                updateStudyBlock(block.id, { status: nextStatus });
                              }}
                              className={`text-[9px] px-1.5 py-0.2 rounded ${getStatusBadge(block.status)}`}
                            >
                              {block.status}
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Daily View */}
      {activeTab === 'daily' && (
        <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4">
          <h2 className="text-base font-bold text-[var(--text-main)]">
            Today's Scheduled Study Intervals ({daysOfWeek[new Date().getDay()]})
          </h2>

          <div className="space-y-2">
            {studyBlocks
              .filter(b => b.dayOfWeek === new Date().getDay())
              .map((block) => {
                const subj = subjects.find(s => s.id === block.subjectId);
                return (
                  <div
                    key={block.id}
                    className="p-4 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-semibold text-sm text-[var(--text-main)]">{block.title}</div>
                      <div className="text-[11px] text-[var(--text-muted)] flex items-center gap-2 mt-0.5">
                        <span className="font-mono text-emerald-400">{block.startTime} – {block.endTime}</span>
                        <span>·</span>
                        <span>{subj?.name}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`text-xs px-2.5 py-1 rounded-lg ${getStatusBadge(block.status)}`}>
                        {block.status}
                      </span>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* Add Block Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-2xl shadow-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-[var(--text-main)]">Schedule Study Block</h3>

            <form onSubmit={handleSaveBlock} className="space-y-3 text-xs">
              <div>
                <label className="block text-[var(--text-muted)] mb-1">Block Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Physics Wave Optics Problem Set"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                />
              </div>

              <div>
                <label className="block text-[var(--text-muted)] mb-1">Subject</label>
                <select
                  value={formData.subjectId}
                  onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                >
                  {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-[var(--text-muted)] mb-1">Day of Week</label>
                <select
                  value={formData.dayOfWeek}
                  onChange={(e) => setFormData({ ...formData, dayOfWeek: parseInt(e.target.value) })}
                  className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                >
                  {daysOfWeek.map((d, idx) => (
                    <option key={d} value={idx}>{d}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[var(--text-muted)] mb-1">Start Time</label>
                  <input
                    type="time"
                    value={formData.startTime}
                    onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                  />
                </div>

                <div>
                  <label className="block text-[var(--text-muted)] mb-1">End Time</label>
                  <input
                    type="time"
                    value={formData.endTime}
                    onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)]"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[var(--border-subtle)]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-[var(--text-muted)] hover:bg-[var(--bg-card)]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold hover:opacity-90"
                >
                  Schedule Block
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
