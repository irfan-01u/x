import React, { useState, useMemo } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Flag,
  CheckCircle2,
  Trash2,
  Clock,
  BookOpen,
  Hourglass,
  ShieldCheck,
  Wifi,
  WifiOff,
  Server,
  Layers,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';
import { StudyType } from '../../types';

export const StopwatchView: React.FC = () => {
  const {
    activeTimer,
    startTimer,
    pauseTimer,
    resumeTimer,
    resetTimer,
    cancelTimerSession,
    finishTimerSession,
    addStopwatchLap,
    subjects,
    chapters,
    sessions,
    isOfflineMode,
  } = useStudium();

  const [setupSubjectId, setSetupSubjectId] = useState(activeTimer.subjectId || subjects[0]?.id || '');
  const [setupChapterId, setSetupChapterId] = useState(activeTimer.chapterId || '');
  const [setupStudyType, setSetupStudyType] = useState<StudyType>(activeTimer.studyType || 'Practice');

  const isStopwatchRunning = activeTimer.mode === 'stopwatch' && activeTimer.status === 'running';
  const isStopwatchActive = activeTimer.mode === 'stopwatch' && activeTimer.status !== 'idle';

  const elapsed = activeTimer.mode === 'stopwatch' ? activeTimer.elapsedSeconds : 0;
  const hours = Math.floor(elapsed / 3600);
  const minutes = Math.floor((elapsed % 3600) / 60);
  const seconds = elapsed % 60;
  const formattedTime = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const laps = activeTimer.mode === 'stopwatch' ? activeTimer.stopwatch.laps : [];

  // Laps analysis
  const lapAnalysis = useMemo(() => {
    if (laps.length === 0) return null;
    let fastest = laps[0].lapTime;
    let slowest = laps[0].lapTime;
    let sum = 0;

    laps.forEach(l => {
      if (l.lapTime < fastest) fastest = l.lapTime;
      if (l.lapTime > slowest) slowest = l.lapTime;
      sum += l.lapTime;
    });

    const average = Math.round(sum / laps.length);
    return { fastest, slowest, average };
  }, [laps]);

  // Stopwatch historical statistics
  const swStats = useMemo(() => {
    const swSessions = sessions.filter(s => s.timerMode === 'stopwatch');
    const totalTime = swSessions.reduce((acc, s) => acc + s.duration, 0);
    const avgTime = swSessions.length > 0 ? Math.round(totalTime / swSessions.length) : 0;
    const longest = swSessions.reduce((max, s) => Math.max(max, s.duration), 0);
    return {
      count: swSessions.length,
      totalMinutes: Math.round(totalTime / 60),
      avgMinutes: Math.round(avgTime / 60),
      longestMinutes: Math.round(longest / 60),
      sessions: swSessions,
    };
  }, [sessions]);

  const handleStartStopwatch = () => {
    startTimer({
      mode: 'stopwatch',
      targetDuration: 0,
      elapsedSeconds: 0,
      subjectId: setupSubjectId,
      chapterId: setupChapterId || undefined,
      studyType: setupStudyType,
      stopwatch: { laps: [] },
    });
  };

  const formatLapTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const activeSubject = subjects.find(s => s.id === (activeTimer.subjectId || setupSubjectId));
  const activeChapter = chapters.find(c => c.id === (activeTimer.chapterId || setupChapterId));

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[var(--border-subtle)] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
              Stopwatch Laboratory
            </h1>
            <span className="text-[10px] px-2 py-0.5 rounded font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
              <Server className="w-3 h-3" />
              <span>SERVER PERSISTED</span>
            </span>
          </div>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Server-authoritative wall-clock study chronometer with offline resilience and anti-drift persistence.
          </p>
        </div>

        {/* Persistence & Network Badges */}
        <div className="flex items-center gap-2 text-xs">
          {isOfflineMode ? (
            <span className="px-2.5 py-1 rounded-xl bg-amber-500/15 text-amber-300 border border-amber-500/30 flex items-center gap-1.5 font-medium text-[11px]">
              <WifiOff className="w-3.5 h-3.5" />
              <span>Offline Safeguard Active</span>
            </span>
          ) : (
            <span className="px-2.5 py-1 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5 font-medium text-[11px]">
              <Wifi className="w-3.5 h-3.5" />
              <span>Cloud Sync Online</span>
            </span>
          )}
        </div>
      </div>

      {/* Offline Alert Banner if currently offline */}
      {isOfflineMode && (
        <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-center gap-2.5 text-xs text-amber-200">
          <Clock className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            <strong>Device Offline:</strong> Your stopwatch session is protected locally with its original
            server start time. Elapsed duration is calculated continuously and will synchronize automatically
            when connection returns.
          </span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Dial & Laps */}
        <div className="lg:col-span-7 flex flex-col items-center p-6 sm:p-10 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs">
          {/* Active Session Meta Pill */}
          {isStopwatchActive && (
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[11px] mb-2">
              <span className={`w-2 h-2 rounded-full ${isStopwatchRunning ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'}`} />
              <span className="font-semibold text-[var(--text-main)]">
                {activeSubject?.name || 'General Study'}
              </span>
              {activeChapter && (
                <span className="text-[var(--text-muted)]"> &bull; {activeChapter.name}</span>
              )}
            </div>
          )}

          {/* Chronometer */}
          <div className="text-6xl sm:text-8xl font-mono font-bold tracking-tight text-[var(--text-main)] tabular-nums select-none my-6">
            {formattedTime}
          </div>

          {/* Server Timestamp Note */}
          {isStopwatchActive && activeTimer.startTime && (
            <div className="text-[11px] font-mono text-[var(--text-dim)] mb-6 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Wall-clock started at {new Date(activeTimer.startTime).toLocaleTimeString()}</span>
            </div>
          )}

          {/* Controls */}
          <div className="flex flex-wrap items-center justify-center gap-3 mb-8">
            {!isStopwatchActive ? (
              <button
                onClick={handleStartStopwatch}
                className="px-8 py-3.5 rounded-2xl bg-[var(--accent)] text-[var(--accent-contrast)] font-bold text-sm hover:opacity-90 active:scale-95 transition-all shadow-md shadow-[var(--accent)]/20 flex items-center gap-2"
              >
                <Play className="w-5 h-5 fill-current" />
                <span>Start Stopwatch</span>
              </button>
            ) : isStopwatchRunning ? (
              <>
                <button
                  onClick={pauseTimer}
                  className="px-6 py-3 rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold text-xs hover:opacity-90 transition-all flex items-center gap-1.5"
                >
                  <Pause className="w-4 h-4" />
                  <span>Pause</span>
                </button>

                <button
                  onClick={addStopwatchLap}
                  className="px-5 py-3 rounded-xl bg-[var(--bg-card)] text-[var(--text-main)] border border-[var(--border-subtle)] hover:border-[var(--accent)] text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Flag className="w-4 h-4 text-amber-400" />
                  <span>Split Lap</span>
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={resumeTimer}
                  className="px-6 py-3 rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] font-semibold text-xs hover:opacity-90 transition-all flex items-center gap-1.5"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Resume</span>
                </button>

                <button
                  onClick={resetTimer}
                  title="Reset and cancel session"
                  className="p-3 rounded-xl bg-[var(--bg-card)] text-[var(--text-muted)] hover:text-[var(--text-main)] border border-[var(--border-subtle)] transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </>
            )}

            {isStopwatchActive && (
              <>
                <button
                  onClick={() => finishTimerSession(false)}
                  className="px-5 py-3 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Finish & Record</span>
                </button>

                <button
                  onClick={cancelTimerSession}
                  className="px-4 py-3 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Cancel</span>
                </button>
              </>
            )}
          </div>

          {/* Lap Analysis Summary */}
          {lapAnalysis && (
            <div className="w-full grid grid-cols-3 gap-2 p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-xs mb-4">
              <div>
                <span className="text-[10px] text-[var(--text-dim)] uppercase">Fastest</span>
                <div className="font-mono font-bold text-emerald-400">{formatLapTime(lapAnalysis.fastest)}</div>
              </div>
              <div>
                <span className="text-[10px] text-[var(--text-dim)] uppercase">Average</span>
                <div className="font-mono font-bold text-sky-400">{formatLapTime(lapAnalysis.average)}</div>
              </div>
              <div>
                <span className="text-[10px] text-[var(--text-dim)] uppercase">Slowest</span>
                <div className="font-mono font-bold text-amber-400">{formatLapTime(lapAnalysis.slowest)}</div>
              </div>
            </div>
          )}

          {/* Laps Table */}
          {laps.length > 0 && (
            <div className="w-full max-h-60 overflow-y-auto space-y-1.5 border-t border-[var(--border-subtle)] pt-4">
              <div className="text-[11px] font-semibold text-[var(--text-dim)] uppercase tracking-wider mb-2">
                Recorded Laps ({laps.length})
              </div>
              {[...laps].reverse().map((lap) => (
                <div
                  key={lap.lapNumber}
                  className="flex items-center justify-between p-2 rounded-lg bg-[var(--bg-card)] text-xs font-mono"
                >
                  <span className="text-[var(--text-dim)]">Lap #{lap.lapNumber}</span>
                  <span className="text-[var(--accent)] font-semibold">+{formatLapTime(lap.lapTime)}</span>
                  <span className="text-[var(--text-main)]">{formatLapTime(lap.totalTime)}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Setup & Historical Stats */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-3">
            <h3 className="text-sm font-bold text-[var(--text-main)]">Stopwatch Attribution</h3>
            <div>
              <label className="block text-xs text-[var(--text-muted)] mb-1">Subject</label>
              <select
                value={setupSubjectId}
                onChange={(e) => setSetupSubjectId(e.target.value)}
                disabled={isStopwatchActive}
                className="w-full text-xs p-2 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] disabled:opacity-60"
              >
                {subjects.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-[var(--text-muted)] mb-1">Chapter (Optional)</label>
              <select
                value={setupChapterId}
                onChange={(e) => setSetupChapterId(e.target.value)}
                disabled={isStopwatchActive}
                className="w-full text-xs p-2 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] disabled:opacity-60"
              >
                <option value="">No specific chapter</option>
                {chapters
                  .filter(c => !setupSubjectId || c.subjectId === setupSubjectId)
                  .map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-[var(--text-muted)] mb-1">Study Type</label>
              <select
                value={setupStudyType}
                onChange={(e) => setSetupStudyType(e.target.value as StudyType)}
                disabled={isStopwatchActive}
                className="w-full text-xs p-2 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-main)] disabled:opacity-60"
              >
                {['Practice', 'Problem Solving', 'Mock Test', 'Reading', 'Learning'].map(t => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Historical Stats */}
          <div className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-3">
            <h3 className="text-sm font-bold text-[var(--text-main)]">Stopwatch Metrics</h3>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-[var(--bg-card)]">
                <span className="text-[var(--text-dim)]">Total Time</span>
                <div className="mt-1 font-mono font-bold text-base text-[var(--text-main)]">
                  {swStats.totalMinutes}m
                </div>
              </div>
              <div className="p-3 rounded-xl bg-[var(--bg-card)]">
                <span className="text-[var(--text-dim)]">Avg Session</span>
                <div className="mt-1 font-mono font-bold text-base text-[var(--text-main)]">
                  {swStats.avgMinutes}m
                </div>
              </div>
              <div className="p-3 rounded-xl bg-[var(--bg-card)]">
                <span className="text-[var(--text-dim)]">Longest Session</span>
                <div className="mt-1 font-mono font-bold text-base text-[var(--text-main)]">
                  {swStats.longestMinutes}m
                </div>
              </div>
              <div className="p-3 rounded-xl bg-[var(--bg-card)]">
                <span className="text-[var(--text-dim)]">Sessions Count</span>
                <div className="mt-1 font-mono font-bold text-base text-[var(--text-main)]">
                  {swStats.count}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

