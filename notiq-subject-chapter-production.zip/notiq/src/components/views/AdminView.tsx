import React from 'react';
import {
  ShieldAlert,
  Lock,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Server,
  KeyRound,
  ExternalLink,
} from 'lucide-react';
import { useAdminAuth } from '../../context/AdminAuthContext';

interface AdminViewProps {
  onNavigateRoute?: (route: string) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({ onNavigateRoute }) => {
  const { isAuthenticated, adminUser } = useAdminAuth();

  const handleGoToAdmin = () => {
    if (onNavigateRoute) {
      onNavigateRoute('/admin');
    } else {
      window.location.pathname = '/admin';
    }
  };

  const handleGoToLogin = () => {
    if (onNavigateRoute) {
      onNavigateRoute('/admin/login');
    } else {
      window.location.pathname = '/admin/login';
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-4xl mx-auto">
      {/* Top Header */}
      <div className="border-b border-[var(--border-subtle)] pb-4">
        <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold uppercase tracking-wider font-mono">
          <ShieldAlert className="w-4 h-4" />
          <span>Restricted Zone &bull; Platform Administration</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)] mt-1">
          Administrative Operations Control Plane
        </h1>
        <p className="text-xs text-[var(--text-muted)] mt-0.5">
          Access to student management, challenge generation, league rules, and audit logs is restricted to authorized administrative personnel.
        </p>
      </div>

      {/* Main Gateway Card */}
      <div className="p-6 sm:p-8 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-6 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="space-y-2 max-w-lg">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-mono font-bold">
              <Lock className="w-3.5 h-3.5" />
              <span>SERVER-SIDE RBAC ENFORCED</span>
            </div>
            <h2 className="text-lg font-bold text-[var(--text-main)]">
              {isAuthenticated ? `Authenticated as @${adminUser?.username}` : 'Platform Administrator Authentication'}
            </h2>
            <p className="text-xs text-[var(--text-muted)] leading-relaxed">
              {isAuthenticated
                ? `You hold active administrative privileges as ${adminUser?.role?.replace('_', ' ')}. Launch the dedicated full-screen Admin Console to manage users, leagues, challenges, and audit trails.`
                : 'Normal student accounts cannot access administrative routes. Administrative sessions require scrypt key validation, brute-force rate limit protection, and role-based clearance.'}
            </p>
          </div>

          <div className="shrink-0 flex flex-col gap-2.5 sm:w-56">
            {isAuthenticated ? (
              <button
                onClick={handleGoToAdmin}
                className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/20 flex items-center justify-center gap-2"
              >
                <span>Launch Admin Console</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleGoToLogin}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/20 flex items-center justify-center gap-2"
              >
                <KeyRound className="w-4 h-4" />
                <span>Admin Login</span>
              </button>
            )}

            <button
              onClick={() => {
                if (isAuthenticated) {
                  handleGoToAdmin();
                } else {
                  handleGoToLogin();
                }
              }}
              className="w-full py-2 px-3 rounded-xl border border-[var(--border-subtle)] text-[var(--text-muted)] hover:text-[var(--text-main)] text-[11px] font-mono transition-colors text-center"
            >
              Route: /admin
            </button>
          </div>
        </div>

        {/* Security Feature Grid */}
        <div className="pt-6 border-t border-[var(--border-subtle)] grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 rounded-xl bg-[var(--bg-base)] border border-[var(--border-subtle)] space-y-1">
            <div className="flex items-center gap-2 text-emerald-400 font-semibold">
              <CheckCircle2 className="w-4 h-4" />
              <span>Multi-Role RBAC</span>
            </div>
            <p className="text-[11px] text-[var(--text-muted)]">
              Super Admin, Admin, and Moderator separation with server-side authorization.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-[var(--bg-base)] border border-[var(--border-subtle)] space-y-1">
            <div className="flex items-center gap-2 text-sky-400 font-semibold">
              <Server className="w-4 h-4" />
              <span>Brute-Force Guard</span>
            </div>
            <p className="text-[11px] text-[var(--text-muted)]">
              5 consecutive failed attempts trigger a mandatory 15-minute IP/user lockout.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-[var(--bg-base)] border border-[var(--border-subtle)] space-y-1">
            <div className="flex items-center gap-2 text-purple-400 font-semibold">
              <ShieldCheck className="w-4 h-4" />
              <span>Immutable Audit Logs</span>
            </div>
            <p className="text-[11px] text-[var(--text-muted)]">
              Every suspension, password update, and parameter change is signed and logged.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
