import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Award,
  Clock3,
  Crown,
  Flame,
  History,
  Info,
  Medal,
  RefreshCw,
  Search,
  ShieldCheck,
  Trophy,
  Users,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

type Period = 'daily' | 'weekly' | 'monthly' | 'all-time';
type Scope = 'global' | 'friends' | 'groups';

interface LeaderboardRow {
  rank: number;
  userId: string;
  name: string;
  username: string;
  avatar: string;
  studyMinutes: number;
  studyScore: number;
  xp: number;
  streak: number;
  tier: string;
  isCurrentUser?: boolean;
  change?: number;
}

interface LeaderboardResponse {
  periodType: Period;
  periodKey: string;
  startDate: string;
  endDate: string;
  todayKey: string;
  timezone: string;
  secondsUntilReset: number;
  totalStudyMinutes: number;
  participantsCount: number;
  rankings: LeaderboardRow[];
  currentUser: (LeaderboardRow & { rankMovement: number; nextRankGapMinutes: number }) | null;
  nextRankGapMinutes: number;
  rules: { maxDailyHoursCap: number; dailyResetTimezone: string; xpToPointsRatio: number };
  friends: LeaderboardRow[];
  groups: LeaderboardRow[];
}

const formatMinutes = (minutes: number) => `${Math.floor(minutes / 60)}h ${minutes % 60}m`;
const formatCountdown = (seconds: number) => {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
};

export const LeaderboardView: React.FC = () => {
  const { profile, dailyLeaderboard, fetchDailyLeaderboard } = useStudium();
  const [period, setPeriod] = useState<Period>('daily');
  const [scope, setScope] = useState<Scope>('global');
  const [data, setData] = useState<LeaderboardResponse | null>(null);
  const [archives, setArchives] = useState<any[]>([]);
  const [selectedArchive, setSelectedArchive] = useState('');
  const [search, setSearch] = useState('');
  const [rulesOpen, setRulesOpen] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [offline, setOffline] = useState(!navigator.onLine);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async (silent = false) => {
    try {
      if (!silent) setLoading(true);
      const res = await fetch(`/api/platform/leaderboard?period=${period}&userId=${encodeURIComponent(profile.id)}`);
      if (!res.ok) throw new Error('Leaderboard unavailable');
      const payload = await res.json();
      setData(payload);
      setSeconds(payload.secondsUntilReset || 0);
      setOffline(false);
    } catch {
      setOffline(!navigator.onLine);
    } finally {
      if (!silent) setLoading(false);
    }
  }, [period, profile.id]);

  useEffect(() => { load(); }, [load]);

  // Lightweight 30-second data refresh; never reloads the page.
  useEffect(() => {
    const timer = window.setInterval(() => load(true), 30000);
    return () => window.clearInterval(timer);
  }, [load]);

  // Countdown is derived from the real current instant and the NEXT midnight
  // in Asia/Dhaka. It never uses the browser's local timezone or a fixed value.
  useEffect(() => {
    const getDhakaCountdown = () => {
      const now = new Date();
      const parts = new Intl.DateTimeFormat('en-US', {
        timeZone: 'Asia/Dhaka',
        calendar: 'gregory',
        numberingSystem: 'latn',
        hour12: false,
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', second: '2-digit',
      }).formatToParts(now).reduce<Record<string, number>>((acc, part) => {
        if (part.type !== 'literal') acc[part.type] = Number(part.value);
        return acc;
      }, {});
      if (parts.hour === 24) parts.hour = 0;
      const wallClockAsUtc = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second);
      const currentOffsetMs = wallClockAsUtc - Math.floor(now.getTime() / 1000) * 1000;
      const next = new Date(Date.UTC(parts.year, parts.month - 1, parts.day + 1, 0, 0, 0));
      const nextMidnightUtc = next.getTime() - currentOffsetMs;
      return Math.max(0, Math.ceil((nextMidnightUtc - now.getTime()) / 1000));
    };
    const update = () => setSeconds(getDhakaCountdown());
    update();
    const timer = window.setInterval(update, 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const online = () => { setOffline(false); load(true); fetchDailyLeaderboard(); };
    const offlineHandler = () => setOffline(true);
    window.addEventListener('online', online);
    window.addEventListener('offline', offlineHandler);
    return () => {
      window.removeEventListener('online', online);
      window.removeEventListener('offline', offlineHandler);
    };
  }, [load, fetchDailyLeaderboard]);

  useEffect(() => {
    if (period === 'daily') {
      fetch('/api/platform/leaderboard/daily/archives')
        .then(r => r.ok ? r.json() : [])
        .then(list => {
          setArchives(list);
          if (list[0] && !selectedArchive) setSelectedArchive(list[0].dateKey);
        })
        .catch(() => undefined);
    }
  }, [period, selectedArchive]);

  const visibleRows = useMemo(() => {
    const source = scope === 'friends' ? data?.friends || [] : scope === 'groups' ? data?.groups || [] : data?.rankings || [];
    const q = search.trim().toLowerCase();
    return q ? source.filter(row => row.name.toLowerCase().includes(q) || row.username.toLowerCase().includes(q)) : source;
  }, [data, scope, search]);

  const current = data?.currentUser;
  const nearby = useMemo(() => {
    if (!current || !data?.rankings.length) return [];
    return data.rankings.filter(row => Math.abs(row.rank - current.rank) <= 2);
  }, [data, current]);
  const podium = (data?.rankings || []).slice(0, 3);

  const periodLabel = period === 'daily' ? "Today's Leaderboard" : period === 'weekly' ? 'Weekly League' : period === 'monthly' ? 'Monthly' : 'All-Time';

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[var(--border-subtle)] pb-4">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">NOTIQ League</h1>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold">
              {offline ? 'Offline' : '● Live'}
            </span>
          </div>
          <p className="text-xs text-[var(--text-muted)] mt-1">Study. Track. Level Up — using validated study sessions only.</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => load()} className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs text-[var(--text-muted)] hover:text-[var(--text-main)]">
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Sync
          </button>
          <button onClick={() => setRulesOpen(true)} className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs text-[var(--text-muted)] hover:text-[var(--text-main)]">
            <Info className="w-3.5 h-3.5" /> Rules
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 p-2 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)]">
        {(['daily', 'weekly', 'monthly', 'all-time'] as Period[]).map(item => (
          <button key={item} onClick={() => setPeriod(item)} className={`px-3 py-2.5 rounded-xl text-xs font-semibold transition ${period === item ? 'bg-[var(--accent)] text-[var(--accent-contrast)]' : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'}`}>
            {item === 'all-time' ? 'All-Time' : item[0].toUpperCase() + item.slice(1)}
          </button>
        ))}
      </div>

      {period === 'daily' && (
        <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-emerald-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center"><Clock3 className="w-5 h-5" /></div>
            <div><div className="text-sm font-bold text-[var(--text-main)]">{data?.todayKey || dailyLeaderboard?.todayKey || 'Today'}</div><div className="text-[11px] text-[var(--text-muted)]">Resets at 12:00 AM · {data?.timezone || 'Asia/Dhaka'}</div></div>
          </div>
          <div className="font-mono font-bold text-amber-400 text-lg tabular-nums">{formatCountdown(seconds)}</div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">
        <div className="space-y-6">
          {podium.length > 0 ? (
            <div className="grid grid-cols-3 gap-3 items-end">
              {podium.map((row, idx) => (
                <div key={row.userId} className={`p-4 rounded-2xl border text-center ${idx === 0 ? 'bg-amber-500/10 border-amber-500/30' : 'bg-[var(--bg-surface)] border-[var(--border-subtle)]'}`}>
                  <div className="flex justify-center mb-2">{idx === 0 ? <Crown className="w-6 h-6 text-amber-400" /> : <Medal className="w-5 h-5 text-[var(--text-muted)]" />}</div>
                  {row.avatar ? <img src={row.avatar} alt="" className="w-12 h-12 rounded-full mx-auto object-cover border border-[var(--border-subtle)]" /> : <div className="w-12 h-12 rounded-full mx-auto bg-[var(--bg-card)] flex items-center justify-center text-sm font-bold">{row.username.slice(0,1).toUpperCase()}</div>}
                  <div className="mt-2 text-xs font-bold text-[var(--text-main)] truncate">#{row.rank} · {row.name}</div>
                  <div className="text-[10px] text-[var(--text-muted)] mt-1">{formatMinutes(row.studyMinutes)}</div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-10 text-center rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)]">
              <Trophy className="w-8 h-8 mx-auto text-[var(--text-dim)] mb-3" />
              <div className="text-sm font-semibold text-[var(--text-main)]">No leaderboard activity yet.</div>
              <div className="text-xs text-[var(--text-muted)] mt-1">Complete a validated study session to enter NOTIQ League.</div>
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-3 justify-between p-3 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)]">
            <div className="flex gap-2 p-1 bg-[var(--bg-card)] rounded-xl">
              {(['global', 'friends', 'groups'] as Scope[]).map(item => (
                <button key={item} onClick={() => setScope(item)} className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${scope === item ? 'bg-[var(--accent)] text-[var(--accent-contrast)]' : 'text-[var(--text-muted)]'}`}>
                  {item === 'global' ? 'Global' : item === 'friends' ? 'Friends' : 'Groups'}
                </button>
              ))}
            </div>
            <div className="relative min-w-[220px]"><Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-[var(--text-dim)]" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search students" className="w-full pl-9 pr-3 py-2 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-xs outline-none" /></div>
          </div>

          {scope !== 'global' && visibleRows.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] text-xs text-[var(--text-muted)]">
              {scope === 'friends' ? 'No friends are participating yet.' : 'No groups available yet.'}
            </div>
          ) : (
            <div className="rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] overflow-hidden">
              <div className="px-4 py-3 border-b border-[var(--border-subtle)] flex items-center justify-between"><span className="text-xs font-bold text-[var(--text-main)]">{periodLabel}</span><span className="text-[10px] text-[var(--text-muted)]">{data?.participantsCount || 0} participants</span></div>
              <div className="p-2 space-y-1">
                {visibleRows.map(row => {
                  const movement = row.change || 0;
                  return <div key={row.userId} className={`flex items-center justify-between gap-3 p-3 rounded-xl ${row.isCurrentUser ? 'bg-[var(--accent)]/10 border border-[var(--accent)]/30' : 'hover:bg-[var(--bg-card)]'}`}>
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 text-center text-xs font-mono font-bold text-[var(--text-muted)]">#{row.rank}</div>
                      {row.avatar ? <img src={row.avatar} alt="" className="w-8 h-8 rounded-full object-cover" /> : <div className="w-8 h-8 rounded-full bg-[var(--bg-card)] flex items-center justify-center text-[10px] font-bold">{row.username.slice(0,1).toUpperCase()}</div>}
                      <div className="min-w-0"><div className="text-xs font-semibold text-[var(--text-main)] truncate">{row.name}{row.isCurrentUser ? ' · You' : ''}</div><div className="text-[10px] text-[var(--text-muted)]">@{row.username} · {row.tier}</div></div>
                    </div>
                    <div className="flex items-center gap-4 shrink-0 text-right"><div className="hidden sm:block"><div className="text-[10px] text-[var(--text-muted)]">Streak</div><div className="text-xs font-mono"><Flame className="inline w-3 h-3 text-amber-400" /> {row.streak}d</div></div><div><div className="text-xs font-mono font-bold text-[var(--text-main)]">{formatMinutes(row.studyMinutes)}</div><div className="text-[10px] text-[var(--text-muted)]">Score {row.studyScore}</div></div>{movement !== 0 && <span className={movement > 0 ? 'text-emerald-400 text-[10px]' : 'text-rose-400 text-[10px]'}>{movement > 0 ? <ArrowUp className="inline w-3 h-3" /> : <ArrowDown className="inline w-3 h-3" />}{Math.abs(movement)}</span>}</div>
                  </div>;
                })}
              </div>
            </div>
          )}
        </div>

        <aside className="space-y-4">
          <div className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--accent)]/30">
            <div className="flex items-center justify-between"><span className="text-[10px] uppercase tracking-wider font-bold text-[var(--accent)]">Your Position</span><Users className="w-4 h-4 text-[var(--accent)]" /></div>
            {current ? <><div className="text-3xl font-bold font-mono mt-2 text-[var(--text-main)]">#{current.rank}</div><div className="text-sm font-semibold text-[var(--text-main)] mt-1">{formatMinutes(current.studyMinutes)}</div><div className="text-xs text-[var(--text-muted)] mt-2">Score {current.studyScore} · {current.streak} day streak</div><div className="mt-3 text-xs">{current.rank === 1 ? <span className="text-amber-400">You are currently #1.</span> : <span className="text-[var(--text-muted)]">{current.nextRankGapMinutes}m to reach #{current.rank - 1}</span>}</div></> : <div className="text-xs text-[var(--text-muted)] mt-3">You're currently the only participant once your first valid session is recorded.</div>}
          </div>

          {current && nearby.length > 0 && <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)]"><div className="text-xs font-bold text-[var(--text-main)] mb-3">Nearby Competitors</div><div className="space-y-1">{nearby.map(row => <div key={row.userId} className={`flex items-center justify-between px-2 py-2 rounded-lg text-[11px] ${row.userId === profile.id ? 'bg-[var(--accent)]/10' : ''}`}><span className="font-mono">#{row.rank}</span><span className="truncate mx-2 flex-1">{row.userId === profile.id ? 'You' : row.name}</span><span className="font-mono">{row.studyMinutes}m</span></div>)}</div></div>}

          <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)]"><div className="flex items-center gap-2 text-xs font-bold"><ShieldCheck className="w-4 h-4 text-emerald-400" /> Verified Competition</div><p className="text-[10px] text-[var(--text-muted)] mt-2 leading-relaxed">Only completed, non-overlapping study sessions accepted by the server can affect rankings. The daily competitive cap is {data?.rules.maxDailyHoursCap || 12} hours.</p></div>

          {period === 'daily' && archives.length > 0 && <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)]"><div className="flex items-center gap-2 text-xs font-bold mb-2"><History className="w-4 h-4" /> Daily History</div><select value={selectedArchive} onChange={e => setSelectedArchive(e.target.value)} className="w-full p-2 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-xs">{archives.map(a => <option key={a.dateKey} value={a.dateKey}>{a.dateKey}</option>)}</select><div className="text-[10px] text-[var(--text-muted)] mt-2">{archives.find(a => a.dateKey === selectedArchive)?.participantsCount || 0} participants · {formatMinutes(archives.find(a => a.dateKey === selectedArchive)?.totalStudyMinutes || 0)}</div></div>}
        </aside>
      </div>

      {rulesOpen && <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60" onClick={() => setRulesOpen(false)}><div onClick={e => e.stopPropagation()} className="w-full max-w-md rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] p-6 space-y-4"><div className="flex items-center gap-2"><Award className="w-5 h-5 text-amber-400" /><h2 className="font-bold">NOTIQ League Rules</h2></div><ul className="text-xs text-[var(--text-muted)] space-y-2 list-disc pl-5"><li>Rankings use validated server-side study sessions.</li><li>Daily period: 00:00–23:59:59 in Asia/Dhaka by default.</li><li>Sessions crossing midnight are split between calendar days.</li><li>Overlapping, duplicate, cancelled and invalid sessions do not count.</li><li>Daily competitive study time is capped by the Admin rule.</li><li>Previous daily results are archived and never used as live competitors.</li></ul><button onClick={() => setRulesOpen(false)} className="w-full py-2.5 rounded-xl bg-[var(--accent)] text-[var(--accent-contrast)] text-xs font-bold">Close</button></div></div>}
    </div>
  );
};
