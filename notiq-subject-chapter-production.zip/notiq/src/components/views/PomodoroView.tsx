import React, { useState, useMemo } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  CheckCircle2,
  Clock,
  Coffee,
  Flame,
  Award,
  Sliders,
  Maximize2,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import { useStudium } from '../../context/StudiumContext';

export const PomodoroView: React.FC = () => {
  const {
    activeTimer,
    startTimer,
    pauseTimer,
    resumeTimer,
    resetTimer,
    finishTimerSession,
    skipPomodoroPhase,
    setFocusMode,
    subjects,
    chapters,
    sessions,
    settings,
    updateSettings,
  } = useStudium();

  const [activeTab, setActiveTab] = useState<'timer' | 'stats' | 'settings'>('timer');

  // Pomodoro Statistics
  const pomoStats = useMemo(() => {
    const todayStr = new Date().toISOString().slice(0, 10);
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    const oneWeekAgoStr = oneWeekAgo.toISOString().slice(0, 10);
    const oneMonthAgo = new Date();
    oneMonthAgo.setDate(oneMonthAgo.getDate() - 30);
    const oneMonthAgoStr = oneMonthAgo.toISOString().slice(0, 10);

    const pomoSessions = sessions.filter(s => s.timerMode === 'pomodoro');
    const todayCount = pomoSessions.filter(s => s.dateString === todayStr).length;
    const weekCount = pomoSessions.filter(s => s.dateString >= oneWeekAgoStr).length;
    const monthCount = pomoSessions.filter(s => s.dateString >= oneMonthAgoStr).length;
    const allTimeCount = pomoSessions.length;

    const completed = pomoSessions.filter(s => s.completedNormally).length;
    const interrupted = pomoSessions.filter(s => s.interrupted).length;
    const completionRate = pomoSessions.length > 0
      ? Math.round((completed / pomoSessions.length) * 100)
      : 100;

    return {
      todayCount,
      weekCount,
      monthCount,
      allTimeCount,
      completed,
      interrupted,
      completionRate,
      pomoSessions,
    };
  }, [sessions]);

  // Active Subject and Chapter
  const subject = subjects.find(s => s.id === activeTimer.subjectId) || subjects[0];
  const chapter = chapters.find(c => c.id === activeTimer.chapterId);

  // Time calculations
  const remainingSeconds = Math.max(0, activeTimer.targetDuration - activeTimer.elapsedSeconds);
  const minutes = Math.floor(remainingSeconds / 60);
  const seconds = remainingSeconds % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const progressPercent = activeTimer.targetDuration > 0
    ? Math.min(100, Math.round((activeTimer.elapsedSeconds / activeTimer.targetDuration) * 100))
    : 0;

  const isBreak = activeTimer.pomodoro.phase !== 'focus';

  // Apply Pomodoro Preset
  const handleApplyPreset = (focusMins: number, breakMins: number) => {
    updateSettings({
      defaultPomodoroFocus: focusMins,
      defaultPomodoroShortBreak: breakMins,
    });
    startTimer({
      mode: 'pomodoro',
      targetDuration: focusMins * 60,
      elapsedSeconds: 0,
      pomodoro: {
        phase: 'focus',
        cycle: 1,
        totalCycles: 4,
        completedFocusCount: 0,
        interruptedCount: 0,
      },
    });
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[var(--border-subtle)] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-main)]">
            Pomodoro Interval Engine
          </h1>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Structured cycles of intense single-task focus alternating with cognitive recovery intervals.
          </p>
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-xl text-xs">
          <button
            onClick={() => setActiveTab('timer')}
            className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
              activeTab === 'timer'
                ? 'bg-[var(--accent)] text-[var(--accent-contrast)] shadow-xs'
                : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
            }`}
          >
            Engine
          </button>
          <button
            onClick={() => setActiveTab('stats')}
            className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
              activeTab === 'stats'
                ? 'bg-[var(--accent)] text-[var(--accent-contrast)] shadow-xs'
                : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
            }`}
          >
            Stats & History
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
              activeTab === 'settings'
                ? 'bg-[var(--accent)] text-[var(--accent-contrast)] shadow-xs'
                : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'
            }`}
          >
            Settings
          </button>
        </div>
      </div>

      {activeTab === 'timer' && (
        <div className="space-y-6">
          {/* Main Dial Card */}
          <div className="flex flex-col items-center justify-center p-8 sm:p-12 rounded-3xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] shadow-xs relative overflow-hidden">
            {/* Top Phase Header */}
            <div className="w-full flex items-center justify-between text-xs text-[var(--text-muted)] mb-8">
              <div className="flex items-center gap-2">
                <span
                  className={`w-2.5 h-2.5 rounded-full ${
                    isBreak ? 'bg-amber-400' : 'bg-emerald-400 animate-pulse'
                  }`}
                />
                <span className="font-semibold text-[var(--text-main)]">
                  {isBreak
                    ? activeTimer.pomodoro.phase === 'longBreak'
                      ? 'Long Break Interval'
                      : 'Short Rest Interval'
                    : 'Deep Focus Interval'}
                </span>
                <span className="text-[var(--text-dim)]">
                  (Cycle {activeTimer.pomodoro.cycle} of {activeTimer.pomodoro.totalCycles})
                </span>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setFocusMode(true)}
                  className="flex items-center gap-1 text-[var(--accent)] hover:underline"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span>Zen Mode</span>
                </button>
              </div>
            </div>

            {/* Cycle Visual Indicator Dots */}
            <div className="flex items-center gap-3 mb-6">
              {[1, 2, 3, 4].map((c) => {
                const isPast = c < activeTimer.pomodoro.cycle;
                const isCurrent = c === activeTimer.pomodoro.cycle;
                return (
                  <div key={c} className="flex items-center gap-1.5">
                    <div
                      className={`w-3.5 h-3.5 rounded-full transition-all ${
                        isPast
                          ? 'bg-[var(--accent)] text-[var(--accent-contrast)]'
                          : isCurrent
                          ? 'bg-[var(--accent)] ring-4 ring-[var(--accent-glow)]'
                          : 'bg-[var(--bg-card)] border border-[var(--border-subtle)]'
                      }`}
                    />
                    {c < 4 && <div className="w-4 h-0.5 bg-[var(--border-subtle)]" />}
                  </div>
                );
              })}
            </div>

            {/* Time Readout */}
            <div className="text-7xl sm:text-9xl font-mono font-bold tracking-tight text-[var(--text-main)] tabular-nums select-none mb-6">
              {formattedTime}
            </div>

            {/* Target Subject Context */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-xs text-[var(--text-muted)] mb-8">
              <span className="font-semibold text-[var(--text-main)]">{subject.name}</span>
              {chapter && (
                <>
                  <span className="text-[var(--text-dim)]">·</span>
                  <span className="text-[var(--text-dim)]">{chapter.name}</span>
                </>
              )}
              {activeTimer.taskTitle && (
                <>
                  <span className="text-[var(--text-dim)]">·</span>
                  <span className="text-[var(--accent)] truncate max-w-[200px]">{activeTimer.taskTitle}</span>
                </>
              )}
            </div>

            {/* Linear Progress Bar */}
            <div className="w-full max-w-md h-2 bg-[var(--bg-card)] rounded-full overflow-hidden mb-8">
              <div
                className={`h-full transition-all duration-300 ${
                  isBreak ? 'bg-amber-400' : 'bg-[var(--accent)]'
                }`}
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            {/* Controls */}
            <div className="flex items-center gap-4">
              <button
                onClick={resetTimer}
                className="p-3 rounded-2xl bg-[var(--bg-card)] text-[var(--text-muted)] hover:text-[var(--text-main)] border border-[var(--border-subtle)] transition-colors"
                title="Reset current interval"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              {activeTimer.status === 'running' ? (
                <button
                  onClick={pauseTimer}
                  className="px-8 py-3.5 rounded-2xl bg-[var(--accent)] text-[var(--accent-contrast)] font-bold text-sm hover:opacity-90 active:scale-95 transition-all shadow-md shadow-[var(--accent)]/20 flex items-center gap-2"
                >
                  <Pause className="w-5 h-5" />
                  <span>Pause</span>
                </button>
              ) : (
                <button
                  onClick={resumeTimer}
                  className="px-8 py-3.5 rounded-2xl bg-[var(--accent)] text-[var(--accent-contrast)] font-bold text-sm hover:opacity-90 active:scale-95 transition-all shadow-md shadow-[var(--accent)]/20 flex items-center gap-2"
                >
                  <Play className="w-5 h-5 fill-current" />
                  <span>{activeTimer.status === 'paused' ? 'Resume' : 'Start Focus'}</span>
                </button>
              )}

              <button
                onClick={skipPomodoroPhase}
                className="p-3 rounded-2xl bg-[var(--bg-card)] text-[var(--text-muted)] hover:text-[var(--text-main)] border border-[var(--border-subtle)] transition-colors"
                title="Skip to next phase"
              >
                <SkipForward className="w-4 h-4" />
              </button>
            </div>

            {/* Complete Early Action */}
            {activeTimer.status !== 'idle' && (
              <button
                onClick={() => finishTimerSession(false)}
                className="mt-6 flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20 transition-colors"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Finish & Record Pomodoro</span>
              </button>
            )}
          </div>

          {/* Presets Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { name: 'Standard 25/5', focus: 25, rest: 5, desc: 'Classic Francesco Cirillo technique' },
              { name: 'Extended 50/10', focus: 50, rest: 10, desc: 'Deep problem-solving double block' },
              { name: 'Ultradian 90/20', focus: 90, rest: 20, desc: 'Natural human biological focus cycle' },
            ].map((p) => (
              <button
                key={p.name}
                onClick={() => handleApplyPreset(p.focus, p.rest)}
                className="p-4 rounded-2xl bg-[var(--bg-surface)] hover:bg-[var(--bg-card)] border border-[var(--border-subtle)] hover:border-[var(--accent)] transition-all text-left group"
              >
                <div className="flex items-center justify-between text-xs font-bold text-[var(--text-main)] group-hover:text-[var(--accent)]">
                  <span>{p.name}</span>
                  <ChevronRight className="w-4 h-4 text-[var(--text-dim)]" />
                </div>
                <div className="text-[11px] text-[var(--text-dim)] mt-1">{p.desc}</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Stats Tab */}
      {activeTab === 'stats' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)]">
              <span className="text-xs text-[var(--text-muted)]">Today's Completed</span>
              <div className="mt-1 text-2xl font-bold font-mono text-[var(--text-main)] tabular-nums">
                {pomoStats.todayCount} <span className="text-xs font-normal text-[var(--text-dim)]">cycles</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)]">
              <span className="text-xs text-[var(--text-muted)]">This Week</span>
              <div className="mt-1 text-2xl font-bold font-mono text-emerald-400 tabular-nums">
                {pomoStats.weekCount} <span className="text-xs font-normal text-[var(--text-dim)]">cycles</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)]">
              <span className="text-xs text-[var(--text-muted)]">Completion Rate</span>
              <div className="mt-1 text-2xl font-bold font-mono text-purple-400 tabular-nums">
                {pomoStats.completionRate}%
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)]">
              <span className="text-xs text-[var(--text-muted)]">All-Time Total</span>
              <div className="mt-1 text-2xl font-bold font-mono text-amber-400 tabular-nums">
                {pomoStats.allTimeCount}
              </div>
            </div>
          </div>

          {/* Pomodoro History Table */}
          <div className="p-5 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-3">
            <h3 className="text-sm font-bold text-[var(--text-main)]">Recent Pomodoro Sessions</h3>
            <div className="space-y-2">
              {pomoStats.pomoSessions.slice(0, 8).map((s) => {
                const subj = subjects.find(sub => sub.id === s.subjectId);
                return (
                  <div
                    key={s.id}
                    className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] text-xs flex items-center justify-between"
                  >
                    <div>
                      <div className="font-semibold text-[var(--text-main)]">
                        {subj?.name || 'Subject'}
                      </div>
                      <div className="text-[11px] text-[var(--text-dim)]">
                        {s.dateString} · {s.completedNormally ? 'Completed Cycle' : 'Interrupted'}
                      </div>
                    </div>
                    <span className="font-mono font-bold text-[var(--text-main)] tabular-nums">
                      {Math.round(s.duration / 60)}m
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Settings Tab */}
      {activeTab === 'settings' && (
        <div className="p-6 rounded-2xl bg-[var(--bg-surface)] border border-[var(--border-subtle)] space-y-4 max-w-xl">
          <h3 className="text-base font-bold text-[var(--text-main)]">Pomodoro Configuration</h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-[var(--text-muted)] mb-1">
                Focus Duration ({settings.defaultPomodoroFocus} minutes)
              </label>
              <input
                type="range"
                min="10"
                max="60"
                step="5"
                value={settings.defaultPomodoroFocus}
                onChange={(e) => updateSettings({ defaultPomodoroFocus: parseInt(e.target.value) })}
                className="w-full accent-[var(--accent)]"
              />
            </div>

            <div>
              <label className="block text-[var(--text-muted)] mb-1">
                Short Break Duration ({settings.defaultPomodoroShortBreak} minutes)
              </label>
              <input
                type="range"
                min="2"
                max="15"
                step="1"
                value={settings.defaultPomodoroShortBreak}
                onChange={(e) => updateSettings({ defaultPomodoroShortBreak: parseInt(e.target.value) })}
                className="w-full accent-[var(--accent)]"
              />
            </div>

            <div>
              <label className="block text-[var(--text-muted)] mb-1">
                Long Break Duration ({settings.defaultPomodoroLongBreak} minutes)
              </label>
              <input
                type="range"
                min="10"
                max="30"
                step="5"
                value={settings.defaultPomodoroLongBreak}
                onChange={(e) => updateSettings({ defaultPomodoroLongBreak: parseInt(e.target.value) })}
                className="w-full accent-[var(--accent)]"
              />
            </div>

            <div className="pt-3 border-t border-[var(--border-subtle)] space-y-2">
              <label className="flex items-center justify-between cursor-pointer">
                <span>Auto-start Break When Focus Ends</span>
                <input
                  type="checkbox"
                  checked={settings.autoStartBreak}
                  onChange={(e) => updateSettings({ autoStartBreak: e.target.checked })}
                  className="accent-[var(--accent)]"
                />
              </label>

              <label className="flex items-center justify-between cursor-pointer">
                <span>Auto-start Focus When Break Ends</span>
                <input
                  type="checkbox"
                  checked={settings.autoStartFocus}
                  onChange={(e) => updateSettings({ autoStartFocus: e.target.checked })}
                  className="accent-[var(--accent)]"
                />
              </label>

              <label className="flex items-center justify-between cursor-pointer">
                <span>Auto-play Ambient Sound on Start</span>
                <input
                  type="checkbox"
                  checked={settings.autoPlayMusic}
                  onChange={(e) => updateSettings({ autoPlayMusic: e.target.checked })}
                  className="accent-[var(--accent)]"
                />
              </label>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
