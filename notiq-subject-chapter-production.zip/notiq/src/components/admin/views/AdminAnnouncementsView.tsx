import React, { useState, useEffect } from 'react';
import {
  Megaphone,
  PlusCircle,
  History,
  CheckCircle2,
  Trash2,
  AlertCircle,
  Bell,
  Eye,
  EyeOff,
} from 'lucide-react';
import { useAdminAuth } from '../../../context/AdminAuthContext';

interface Announcement {
  id: string;
  title: string;
  content: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  targetAudience: 'ALL' | 'LEAGUE_COMPETITORS' | 'NEW_USERS';
  authorAdmin: string;
  createdAt: string;
  active: boolean;
}

interface AdminAnnouncementsViewProps {
  initialSubItem?: string;
}

export const AdminAnnouncementsView: React.FC<AdminAnnouncementsViewProps> = ({
  initialSubItem = 'create_announcement',
}) => {
  const { token } = useAdminAuth();

  const [activeTab, setActiveTab] = useState(initialSubItem);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<string | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [priority, setPriority] = useState<'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT'>('HIGH');
  const [targetAudience, setTargetAudience] = useState<'ALL' | 'LEAGUE_COMPETITORS' | 'NEW_USERS'>('ALL');

  useEffect(() => {
    if (initialSubItem) {
      setActiveTab(initialSubItem);
    }
  }, [initialSubItem]);

  const fetchAnnouncements = async () => {
    try {
      const res = await fetch('/api/admin/announcements', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setAnnouncements(data);
      }
    } catch (err) {
      console.error('Failed to load announcements:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnnouncements();
  }, [token]);

  const handleCreateAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !content) return;

    try {
      const res = await fetch('/api/admin/announcements', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title,
          content,
          priority,
          targetAudience,
        }),
      });

      if (res.ok) {
        setMessage('Cohort announcement broadcasted successfully to all student notification feeds.');
        setTimeout(() => setMessage(null), 4000);
        setTitle('');
        setContent('');
        setActiveTab('announcement_history');
        fetchAnnouncements();
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to create announcement');
      }
    } catch (err: any) {
      alert(err.message || 'Network error');
    }
  };

  const handleToggleActive = async (ann: Announcement) => {
    try {
      const res = await fetch(`/api/admin/announcements/${ann.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ active: !ann.active }),
      });

      if (res.ok) {
        fetchAnnouncements();
      }
    } catch (err) {
      console.error('Toggle announcement error:', err);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you wish to delete this announcement?')) return;

    try {
      const res = await fetch(`/api/admin/announcements/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.ok) {
        setMessage('Announcement deleted.');
        setTimeout(() => setMessage(null), 3000);
        fetchAnnouncements();
      }
    } catch (err) {
      console.error('Delete announcement error:', err);
    }
  };

  const getPriorityBadge = (p: string) => {
    switch (p) {
      case 'URGENT':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      case 'HIGH':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'MEDIUM':
        return 'bg-sky-500/20 text-sky-300 border-sky-500/30';
      default:
        return 'bg-slate-700 text-slate-300 border-slate-600';
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto text-slate-100">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-sky-400 font-bold uppercase tracking-wider">
            <Megaphone className="w-4 h-4" />
            <span>Platform Communications & Broadcasts</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1">
            Cohort Announcements & Notices
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Broadcast platform updates, scheduled exam reminders, and league settlement alerts.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('create_announcement')}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-sm shadow-amber-500/20"
        >
          <PlusCircle className="w-4 h-4" />
          <span>New Announcement</span>
        </button>
      </div>

      {message && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        {[
          { key: 'create_announcement', label: 'Create Announcement' },
          { key: 'announcement_history', label: 'Announcement History', count: announcements.length },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
              activeTab === tab.key
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <span>{tab.label}</span>
            {tab.count !== undefined && (
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                  activeTab === tab.key ? 'bg-slate-950/30 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Tab 1: Create Announcement */}
      {activeTab === 'create_announcement' && (
        <div className="max-w-xl p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <PlusCircle className="w-5 h-5 text-amber-400" />
            <span>Compose Cohort Broadcast</span>
          </h2>

          <form onSubmit={handleCreateAnnouncement} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Announcement Headline
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Diamond League Weekly Settlement & Honor Roll Announcement"
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Message Body
              </label>
              <textarea
                required
                rows={4}
                value={content}
                onChange={e => setContent(e.target.value)}
                placeholder="Detailed explanation, instructions, or congratulatory remarks..."
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Urgency / Priority
                </label>
                <select
                  value={priority}
                  onChange={e => setPriority(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                >
                  <option value="LOW">LOW — Routine informative memo</option>
                  <option value="MEDIUM">MEDIUM — Standard cohort notice</option>
                  <option value="HIGH">HIGH — High-visibility banner</option>
                  <option value="URGENT">URGENT — Critical platform advisory</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Target Audience
                </label>
                <select
                  value={targetAudience}
                  onChange={e => setTargetAudience(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                >
                  <option value="ALL">All Registered Scholars</option>
                  <option value="LEAGUE_COMPETITORS">Competitive League Scholars</option>
                  <option value="NEW_USERS">Newly Enrolled Students</option>
                </select>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-sm shadow-amber-500/20"
              >
                Broadcast to Platform
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Tab 2: History */}
      {activeTab === 'announcement_history' && (
        <div className="space-y-4">
          {announcements.map(ann => (
            <div
              key={ann.id}
              className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3"
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-white text-sm">{ann.title}</h3>
                    <span className={`px-2 py-0.2 rounded text-[10px] font-mono font-bold border ${getPriorityBadge(ann.priority)}`}>
                      {ann.priority}
                    </span>
                    <span
                      className={`px-2 py-0.2 rounded text-[10px] font-mono font-semibold ${
                        ann.active ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {ann.active ? 'LIVE BROADCAST' : 'ARCHIVED / INACTIVE'}
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-400 mt-1 font-mono">
                    Published by {ann.authorAdmin} &bull; {new Date(ann.createdAt).toLocaleString()} &bull; Target: {ann.targetAudience}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleToggleActive(ann)}
                    title={ann.active ? 'Archive announcement' : 'Reactivate announcement'}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                  >
                    {ann.active ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>

                  <button
                    onClick={() => handleDelete(ann.id)}
                    title="Delete announcement"
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-300 leading-relaxed font-sans">
                {ann.content}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
