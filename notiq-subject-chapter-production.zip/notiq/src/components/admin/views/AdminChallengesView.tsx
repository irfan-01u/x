import React, { useState, useEffect } from 'react';
import {
  Flame,
  PlusCircle,
  History,
  CheckCircle2,
  Trash2,
  Calendar,
  Users,
  Award,
  Clock,
  Atom,
  Timer,
  RefreshCw,
} from 'lucide-react';
import { useAdminAuth } from '../../../context/AdminAuthContext';

interface Challenge {
  id: string;
  title: string;
  description: string;
  targetType: 'HOURS' | 'DAYS_STREAK' | 'POMODOROS' | 'SUBJECT_FOCUS';
  targetValue: number;
  xpReward: number;
  participantsCount: number;
  completionsCount: number;
  startDate: string;
  endDate: string;
  status: 'ACTIVE' | 'UPCOMING' | 'COMPLETED' | 'CANCELLED';
  badgeIcon: string;
}

interface AdminChallengesViewProps {
  initialSubItem?: string;
}

export const AdminChallengesView: React.FC<AdminChallengesViewProps> = ({
  initialSubItem = 'active_challenges',
}) => {
  const { token, adminUser } = useAdminAuth();

  const [activeTab, setActiveTab] = useState(initialSubItem);
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<string | null>(null);

  // Create Challenge Form
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [targetType, setTargetType] = useState<'HOURS' | 'DAYS_STREAK' | 'POMODOROS' | 'SUBJECT_FOCUS'>('HOURS');
  const [targetValue, setTargetValue] = useState(15);
  const [xpReward, setXpReward] = useState(500);
  const [daysDuration, setDaysDuration] = useState(7);
  const [badgeIcon, setBadgeIcon] = useState('Flame');

  useEffect(() => {
    if (initialSubItem) {
      setActiveTab(initialSubItem);
    }
  }, [initialSubItem]);

  const fetchChallenges = async () => {
    try {
      const res = await fetch('/api/admin/challenges', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setChallenges(data);
      }
    } catch (err) {
      console.error('Failed to fetch challenges:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchChallenges();
  }, [token]);

  const handleCreateChallenge = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description) return;

    try {
      const startDate = new Date().toISOString();
      const endDate = new Date(Date.now() + daysDuration * 86400000).toISOString();

      const res = await fetch('/api/admin/challenges', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title,
          description,
          targetType,
          targetValue: Number(targetValue),
          xpReward: Number(xpReward),
          badgeIcon,
          startDate,
          endDate,
        }),
      });

      if (res.ok) {
        setMessage('Academic challenge published successfully to student feed.');
        setTimeout(() => setMessage(null), 4000);
        setTitle('');
        setDescription('');
        setActiveTab('active_challenges');
        fetchChallenges();
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to create challenge');
      }
    } catch (err: any) {
      alert(err.message || 'Network error');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you wish to delete this challenge?')) return;

    try {
      const res = await fetch(`/api/admin/challenges/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setMessage('Challenge removed.');
        setTimeout(() => setMessage(null), 3000);
        fetchChallenges();
      }
    } catch (err) {
      console.error('Delete challenge error:', err);
    }
  };

  const activeChallenges = challenges.filter(c => c.status === 'ACTIVE');
  const pastChallenges = challenges.filter(c => c.status === 'COMPLETED' || c.status === 'CANCELLED');

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto text-slate-100">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-rose-400 font-bold uppercase tracking-wider">
            <Flame className="w-4 h-4" />
            <span>Academic Challenge Management</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1">
            Study Challenges & Cohort Sprints
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Orchestrate campus-wide study marathons, streak sprints, and Pomodoro challenges.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('create_challenge')}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-sm shadow-amber-500/20"
        >
          <PlusCircle className="w-4 h-4" />
          <span>New Challenge</span>
        </button>
      </div>

      {message && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        {[
          { key: 'active_challenges', label: 'Active Challenges', count: activeChallenges.length },
          { key: 'create_challenge', label: 'Create Challenge' },
          { key: 'challenge_history', label: 'Challenge History', count: pastChallenges.length },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
              activeTab === tab.key
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <span>{tab.label}</span>
            {tab.count !== undefined && (
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                  activeTab === tab.key ? 'bg-slate-950/30 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Tab 1: Active Challenges */}
      {activeTab === 'active_challenges' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {activeChallenges.map(c => (
            <div
              key={c.id}
              className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4 relative overflow-hidden"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
                    <Flame className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-sm leading-tight">{c.title}</h3>
                    <span className="text-[10px] font-mono text-emerald-400 font-semibold">
                      ACTIVE RUNNING
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => handleDelete(c.id)}
                  title="Delete Challenge"
                  className="p-1 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">
                {c.description}
              </p>

              <div className="pt-2 border-t border-slate-800/80 grid grid-cols-2 gap-2 text-xs font-mono">
                <div>
                  <span className="text-slate-500 text-[10px]">Reward</span>
                  <div className="font-bold text-amber-300">+{c.xpReward} XP</div>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px]">Participants</span>
                  <div className="font-bold text-white">{c.participantsCount} Scholars</div>
                </div>
              </div>

              <div className="text-[10px] font-mono text-slate-500">
                Ends: {new Date(c.endDate).toLocaleDateString()}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Create Challenge */}
      {activeTab === 'create_challenge' && (
        <div className="max-w-xl p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <PlusCircle className="w-5 h-5 text-amber-400" />
            <span>Design New Academic Challenge</span>
          </h2>

          <form onSubmit={handleCreateChallenge} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Challenge Title
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. 14-Day Organic Chemistry Deep Work Sprint"
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Challenge Description & Rules
              </label>
              <textarea
                required
                rows={3}
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Clarify specific qualification criteria for students..."
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Metric Target Type
                </label>
                <select
                  value={targetType}
                  onChange={e => setTargetType(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                >
                  <option value="HOURS">Total Study Hours</option>
                  <option value="DAYS_STREAK">Consecutive Days Streak</option>
                  <option value="POMODOROS">Pomodoro Intervals</option>
                  <option value="SUBJECT_FOCUS">Chapters Reviewed</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Target Threshold Value
                </label>
                <input
                  type="number"
                  min={1}
                  required
                  value={targetValue}
                  onChange={e => setTargetValue(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  XP Reward
                </label>
                <input
                  type="number"
                  min={50}
                  required
                  value={xpReward}
                  onChange={e => setXpReward(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Sprint Duration (Days)
                </label>
                <input
                  type="number"
                  min={1}
                  max={60}
                  required
                  value={daysDuration}
                  onChange={e => setDaysDuration(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-sm shadow-amber-500/20"
              >
                Launch Campus Challenge
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Tab 3: History */}
      {activeTab === 'challenge_history' && (
        <div className="space-y-3">
          {pastChallenges.map(c => (
            <div
              key={c.id}
              className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between text-xs"
            >
              <div>
                <div className="font-semibold text-slate-200">{c.title}</div>
                <div className="text-[11px] text-slate-500">
                  Ended {new Date(c.endDate).toLocaleDateString()} &bull; {c.participantsCount} participants &bull; {c.completionsCount} completed
                </div>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-400">
                {c.status}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
