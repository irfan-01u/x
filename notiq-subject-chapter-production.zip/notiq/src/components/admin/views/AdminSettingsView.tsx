import React, { useState, useEffect } from 'react';
import {
  Settings,
  Sliders,
  Lock,
  Server,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  ShieldCheck,
} from 'lucide-react';
import { useAdminAuth } from '../../../context/AdminAuthContext';

interface PlatformSettings {
  maintenanceMode: boolean;
  registrationOpen: boolean;
  requireEmailVerification: boolean;
  antiCheatMode: 'STANDARD' | 'STRICT' | 'AGGRESSIVE';
  maxStudySessionHours: number;
  sessionTimeoutMinutes: number;
  maxFailedLoginAttempts: number;
  lockoutDurationMinutes: number;
  systemName: string;
  supportEmail: string;
}

interface AdminSettingsViewProps {
  initialSubItem?: string;
}

export const AdminSettingsView: React.FC<AdminSettingsViewProps> = ({
  initialSubItem = 'platform_settings',
}) => {
  const { token, adminUser } = useAdminAuth();

  const [activeTab, setActiveTab] = useState(initialSubItem);
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  // Form Fields
  const [systemName, setSystemName] = useState('');
  const [supportEmail, setSupportEmail] = useState('');
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [registrationOpen, setRegistrationOpen] = useState(true);
  const [requireEmail, setRequireEmail] = useState(true);
  const [antiCheatMode, setAntiCheatMode] = useState<'STANDARD' | 'STRICT' | 'AGGRESSIVE'>('STRICT');
  const [maxStudySessionHours, setMaxStudySessionHours] = useState(6);
  const [sessionTimeoutMinutes, setSessionTimeoutMinutes] = useState(480);
  const [maxFailedLoginAttempts, setMaxFailedLoginAttempts] = useState(5);
  const [lockoutDurationMinutes, setLockoutDurationMinutes] = useState(15);

  useEffect(() => {
    if (initialSubItem) {
      setActiveTab(initialSubItem);
    }
  }, [initialSubItem]);

  const fetchSettings = async () => {
    try {
      const res = await fetch('/api/admin/settings', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setSettings(data);
        setSystemName(data.systemName);
        setSupportEmail(data.supportEmail);
        setMaintenanceMode(data.maintenanceMode);
        setRegistrationOpen(data.registrationOpen);
        setRequireEmail(data.requireEmailVerification);
        setAntiCheatMode(data.antiCheatMode);
        setMaxStudySessionHours(data.maxStudySessionHours);
        setSessionTimeoutMinutes(data.sessionTimeoutMinutes);
        setMaxFailedLoginAttempts(data.maxFailedLoginAttempts);
        setLockoutDurationMinutes(data.lockoutDurationMinutes);
      }
    } catch (err) {
      console.error('Failed to load settings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, [token]);

  const isSuperAdmin = adminUser?.role === 'SUPER_ADMIN';

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isSuperAdmin) {
      alert('Only Super Administrators can modify platform settings.');
      return;
    }

    setSaving(true);
    setMessage(null);

    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          systemName,
          supportEmail,
          maintenanceMode,
          registrationOpen,
          requireEmailVerification: requireEmail,
          antiCheatMode,
          maxStudySessionHours: Number(maxStudySessionHours),
          sessionTimeoutMinutes: Number(sessionTimeoutMinutes),
          maxFailedLoginAttempts: Number(maxFailedLoginAttempts),
          lockoutDurationMinutes: Number(lockoutDurationMinutes),
        }),
      });

      if (res.ok) {
        setMessage('Platform configuration parameters committed successfully.');
        setTimeout(() => setMessage(null), 4000);
        fetchSettings();
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to update settings');
      }
    } catch (err: any) {
      alert(err.message || 'Network error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto text-slate-100">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-slate-400 font-bold uppercase tracking-wider">
            <Settings className="w-4 h-4 text-amber-400" />
            <span>Platform Infrastructure & Security</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1">
            System Configuration & Security
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage anti-cheat heuristics, session timeouts, and runtime operational parameters.
          </p>
        </div>
      </div>

      {message && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        {[
          { key: 'platform_settings', label: 'Platform Settings' },
          { key: 'security_settings', label: 'Security & Brute-Force' },
          { key: 'system_configuration', label: 'System Configuration' },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === tab.key
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Form Content */}
      <form onSubmit={handleSaveSettings} className="space-y-6">
        {/* Tab 1: Platform Settings */}
        {activeTab === 'platform_settings' && (
          <div className="max-w-2xl p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4 text-xs">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Sliders className="w-5 h-5 text-amber-400" />
              <span>Platform Identity & Access</span>
            </h2>

            <div className="space-y-3.5 pt-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  System Name
                </label>
                <input
                  type="text"
                  disabled={!isSuperAdmin}
                  value={systemName}
                  onChange={e => setSystemName(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Academic Support Email
                </label>
                <input
                  type="email"
                  disabled={!isSuperAdmin}
                  value={supportEmail}
                  onChange={e => setSupportEmail(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                />
              </div>

              <div className="pt-2 border-t border-slate-800 space-y-3">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    disabled={!isSuperAdmin}
                    checked={maintenanceMode}
                    onChange={e => setMaintenanceMode(e.target.checked)}
                    className="w-4 h-4 rounded text-amber-500 focus:ring-amber-500 bg-slate-950 border-slate-700"
                  />
                  <div>
                    <span className="font-semibold text-white block">Maintenance Mode</span>
                    <span className="text-[11px] text-slate-400">
                      Restricts student dashboard access while administrative upgrades are in progress.
                    </span>
                  </div>
                </label>

                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    disabled={!isSuperAdmin}
                    checked={registrationOpen}
                    onChange={e => setRegistrationOpen(e.target.checked)}
                    className="w-4 h-4 rounded text-amber-500 focus:ring-amber-500 bg-slate-950 border-slate-700"
                  />
                  <div>
                    <span className="font-semibold text-white block">Student Registration Open</span>
                    <span className="text-[11px] text-slate-400">
                      Allows new university scholars to self-enroll in cohort leagues.
                    </span>
                  </div>
                </label>

                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    disabled={!isSuperAdmin}
                    checked={requireEmail}
                    onChange={e => setRequireEmail(e.target.checked)}
                    className="w-4 h-4 rounded text-amber-500 focus:ring-amber-500 bg-slate-950 border-slate-700"
                  />
                  <div>
                    <span className="font-semibold text-white block">Require Institutional Email (.edu / .ac)</span>
                    <span className="text-[11px] text-slate-400">
                      Restricts enrollment to authenticated academic domains.
                    </span>
                  </div>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Security & Brute-Force */}
        {activeTab === 'security_settings' && (
          <div className="max-w-2xl p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4 text-xs">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Lock className="w-5 h-5 text-amber-400" />
              <span>Anti-Cheat & Defense Policies</span>
            </h2>

            <div className="space-y-3.5 pt-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Anti-Cheat Heuristic Mode
                </label>
                <select
                  disabled={!isSuperAdmin}
                  value={antiCheatMode}
                  onChange={e => setAntiCheatMode(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                >
                  <option value="STANDARD">STANDARD — Regular tick evaluation</option>
                  <option value="STRICT">STRICT — Enforce wall-clock synchronization & background tab verification</option>
                  <option value="AGGRESSIVE">AGGRESSIVE — Auto-suspend timers exceeding 120s drift anomaly</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Max Single Session Cap (Hours)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={12}
                    disabled={!isSuperAdmin}
                    value={maxStudySessionHours}
                    onChange={e => setMaxStudySessionHours(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Session Timeout (Minutes)
                  </label>
                  <input
                    type="number"
                    min={30}
                    max={1440}
                    disabled={!isSuperAdmin}
                    value={sessionTimeoutMinutes}
                    onChange={e => setSessionTimeoutMinutes(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Max Failed Admin Login Attempts
                  </label>
                  <input
                    type="number"
                    min={3}
                    max={10}
                    disabled={!isSuperAdmin}
                    value={maxFailedLoginAttempts}
                    onChange={e => setMaxFailedLoginAttempts(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Lockout Duration (Minutes)
                  </label>
                  <input
                    type="number"
                    min={5}
                    max={60}
                    disabled={!isSuperAdmin}
                    value={lockoutDurationMinutes}
                    onChange={e => setLockoutDurationMinutes(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: System Configuration */}
        {activeTab === 'system_configuration' && (
          <div className="max-w-2xl p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4 text-xs">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Server className="w-5 h-5 text-amber-400" />
              <span>Full-Stack Host Telemetry</span>
            </h2>

            <div className="space-y-3 font-mono">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
                <span className="text-slate-400 font-sans">Node Environment</span>
                <span className="text-white font-bold">{process.env.NODE_ENV || 'development'}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
                <span className="text-slate-400 font-sans">Server Listen Port</span>
                <span className="text-white font-bold">3000</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
                <span className="text-slate-400 font-sans">Cryptographic Subsystem</span>
                <span className="text-emerald-400 font-bold">Node.js Native Scrypt / PBKDF2</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
                <span className="text-slate-400 font-sans">State Persistence Engine</span>
                <span className="text-emerald-400 font-bold">JSON Store (data/platform_state.json)</span>
              </div>
            </div>
          </div>
        )}

        {/* Save button if Super Admin */}
        {isSuperAdmin && activeTab !== 'system_configuration' && (
          <div className="max-w-2xl">
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-50 shadow-md shadow-amber-500/20"
            >
              {saving ? 'Persisting Parameters...' : 'Commit Platform Configuration'}
            </button>
          </div>
        )}
      </form>
    </div>
  );
};
