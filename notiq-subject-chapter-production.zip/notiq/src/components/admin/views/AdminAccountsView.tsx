import React, { useState, useEffect } from 'react';
import {
  Shield,
  ShieldAlert,
  UserPlus,
  KeyRound,
  Trash2,
  Edit,
  CheckCircle2,
  XCircle,
  Lock,
  FileText,
  Search,
  Filter,
  AlertTriangle,
  Download,
  Check,
  X,
  RefreshCw,
} from 'lucide-react';
import { useAdminAuth } from '../../../context/AdminAuthContext';

interface AdminAccount {
  id: string;
  username: string;
  name: string;
  email: string;
  role: 'SUPER_ADMIN' | 'ADMIN' | 'MODERATOR';
  isInitialPassword: boolean;
  status: 'ACTIVE' | 'DISABLED';
  createdAt: string;
  lastLoginAt?: string;
}

interface AuditLogEntry {
  id: string;
  adminId: string;
  adminUsername: string;
  role: string;
  action: string;
  target: string;
  timestamp: string;
  status: 'SUCCESS' | 'WARNING' | 'FAILED';
  metadata?: Record<string, any>;
  ip?: string;
}

interface AdminAccountsViewProps {
  initialSubItem?: string;
}

export const AdminAccountsView: React.FC<AdminAccountsViewProps> = ({
  initialSubItem = 'admin_accounts',
}) => {
  const { token, adminUser, changePassword } = useAdminAuth();

  const [activeTab, setActiveTab] = useState<string>(initialSubItem);
  const [admins, setAdmins] = useState<AdminAccount[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  // Filters for Audit Logs
  const [auditSearch, setAuditSearch] = useState('');
  const [auditActionFilter, setAuditActionFilter] = useState('ALL');
  const [auditRoleFilter, setAuditRoleFilter] = useState('ALL');

  // Modals
  const [showAddAdminModal, setShowAddAdminModal] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<AdminAccount | null>(null);
  const [resettingAdmin, setResettingAdmin] = useState<AdminAccount | null>(null);
  const [newPasswordForReset, setNewPasswordForReset] = useState('');

  // Add Admin Form
  const [newAdminUsername, setNewAdminUsername] = useState('');
  const [newAdminName, setNewAdminName] = useState('');
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminRole, setNewAdminRole] = useState<'SUPER_ADMIN' | 'ADMIN' | 'MODERATOR'>('ADMIN');
  const [newAdminPassword, setNewAdminPassword] = useState('');

  // Change Own Password Form
  const [currentPwd, setCurrentPwd] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const [pwdError, setPwdError] = useState<string | null>(null);
  const [pwdSuccess, setPwdSuccess] = useState(false);

  useEffect(() => {
    if (initialSubItem) {
      setActiveTab(initialSubItem);
    }
  }, [initialSubItem]);

  const fetchAdmins = async () => {
    try {
      const res = await fetch('/api/admin/admins', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setAdmins(data);
      }
    } catch (err) {
      console.error('Failed to load admins:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchAuditLogs = async () => {
    try {
      const res = await fetch('/api/admin/audit-logs', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setAuditLogs(data);
      }
    } catch (err) {
      console.error('Failed to load audit logs:', err);
    }
  };

  useEffect(() => {
    fetchAdmins();
    fetchAuditLogs();
  }, [token]);

  const isSuperAdmin = adminUser?.role === 'SUPER_ADMIN';

  const handleCreateAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/admins', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          username: newAdminUsername,
          name: newAdminName,
          email: newAdminEmail,
          role: newAdminRole,
          initialPassword: newAdminPassword,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setShowAddAdminModal(false);
        setNewAdminUsername('');
        setNewAdminName('');
        setNewAdminEmail('');
        setNewAdminPassword('');
        setActionMessage('Administrator created successfully.');
        setTimeout(() => setActionMessage(null), 3500);
        fetchAdmins();
        fetchAuditLogs();
      } else {
        alert(data.error || 'Failed to create administrator');
      }
    } catch (err: any) {
      alert(err.message || 'Network error');
    }
  };

  const handleUpdateAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAdmin) return;

    try {
      const res = await fetch(`/api/admin/admins/${editingAdmin.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: editingAdmin.name,
          email: editingAdmin.email,
          role: editingAdmin.role,
          status: editingAdmin.status,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setEditingAdmin(null);
        setActionMessage('Administrator details updated.');
        setTimeout(() => setActionMessage(null), 3500);
        fetchAdmins();
        fetchAuditLogs();
      } else {
        alert(data.error || 'Update failed');
      }
    } catch (err: any) {
      alert(err.message || 'Network error');
    }
  };

  const handleToggleStatus = async (admin: AdminAccount) => {
    const newStatus = admin.status === 'ACTIVE' ? 'DISABLED' : 'ACTIVE';
    try {
      const res = await fetch(`/api/admin/admins/${admin.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });

      const data = await res.json();
      if (res.ok) {
        setActionMessage(`Administrator ${admin.username} marked as ${newStatus}.`);
        setTimeout(() => setActionMessage(null), 3500);
        fetchAdmins();
        fetchAuditLogs();
      } else {
        alert(data.error || 'Toggle failed');
      }
    } catch (err: any) {
      alert(err.message || 'Network error');
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resettingAdmin || !newPasswordForReset) return;

    try {
      const res = await fetch(`/api/admin/admins/${resettingAdmin.id}/reset-password`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ newPassword: newPasswordForReset }),
      });

      const data = await res.json();
      if (res.ok) {
        setResettingAdmin(null);
        setNewPasswordForReset('');
        setActionMessage(data.message);
        setTimeout(() => setActionMessage(null), 4000);
        fetchAdmins();
        fetchAuditLogs();
      } else {
        alert(data.error || 'Password reset failed');
      }
    } catch (err: any) {
      alert(err.message || 'Network error');
    }
  };

  const handleDeleteAdmin = async (id: string, username: string) => {
    if (!confirm(`Are you certain you wish to permanently remove administrator @${username}?`)) return;

    try {
      const res = await fetch(`/api/admin/admins/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });

      const data = await res.json();
      if (res.ok) {
        setActionMessage(`Administrator @${username} removed.`);
        setTimeout(() => setActionMessage(null), 3500);
        fetchAdmins();
        fetchAuditLogs();
      } else {
        alert(data.error || 'Delete failed');
      }
    } catch (err: any) {
      alert(err.message || 'Network error');
    }
  };

  const handleChangeOwnPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwdError(null);
    setPwdSuccess(false);

    if (newPwd !== confirmPwd) {
      setPwdError('New passwords do not match.');
      return;
    }

    const res = await changePassword(currentPwd, newPwd, confirmPwd);
    if (res.success) {
      setPwdSuccess(true);
      setCurrentPwd('');
      setNewPwd('');
      setConfirmPwd('');
      setTimeout(() => setPwdSuccess(false), 4000);
      fetchAuditLogs();
    } else {
      setPwdError(res.error || 'Failed to update password.');
    }
  };

  const exportAuditLogs = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(auditLogs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `studiq_audit_trail_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Filtered Audit logs
  const filteredAuditLogs = auditLogs.filter(log => {
    if (auditActionFilter !== 'ALL' && log.action.toLowerCase() !== auditActionFilter.toLowerCase()) {
      return false;
    }
    if (auditRoleFilter !== 'ALL' && log.role.toLowerCase() !== auditRoleFilter.toLowerCase()) {
      return false;
    }
    if (auditSearch.trim()) {
      const q = auditSearch.toLowerCase().trim();
      return (
        log.adminUsername.toLowerCase().includes(q) ||
        log.target.toLowerCase().includes(q) ||
        log.action.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto text-slate-100">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 font-bold uppercase tracking-wider">
            <ShieldAlert className="w-4 h-4" />
            <span>Admin Governance & Identity Control</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1">
            Admin Accounts, RBAC & Security
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Maintain privileged operator credentials, role-based boundaries, and cryptographic verification logs.
          </p>
        </div>

        {isSuperAdmin && activeTab === 'admin_accounts' && (
          <button
            onClick={() => setShowAddAdminModal(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-sm shadow-amber-500/20"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add Administrator</span>
          </button>
        )}
      </div>

      {actionMessage && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
        {[
          { key: 'admin_accounts', label: 'Admin Accounts', count: admins.length },
          { key: 'roles_permissions', label: 'Roles & Permissions' },
          { key: 'security', label: 'Security & Password' },
          { key: 'audit_logs', label: 'Audit Logs', count: auditLogs.length },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
              activeTab === tab.key
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <span>{tab.label}</span>
            {tab.count !== undefined && (
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                  activeTab === tab.key ? 'bg-slate-950/30 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Tab 1: Admin Accounts */}
      {activeTab === 'admin_accounts' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>List of verified platform operators and role privileges.</span>
            {!isSuperAdmin && (
              <span className="text-amber-400 font-mono text-[11px]">
                Note: Super Administrator privileges required to add or modify admin accounts.
              </span>
            )}
          </div>

          <div className="rounded-xl border border-slate-800 overflow-x-auto bg-slate-900/60">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-900/90 text-slate-400 font-mono uppercase text-[10px]">
                  <th className="py-3 px-4">Operator</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Password State</th>
                  <th className="py-3 px-4">Last Login</th>
                  {isSuperAdmin && <th className="py-3 px-4 text-right">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {admins.map(admin => (
                  <tr key={admin.id} className="hover:bg-slate-850/50 transition-colors">
                    <td className="py-3 px-4">
                      <div>
                        <div className="font-semibold text-slate-100 flex items-center gap-1.5">
                          <span>{admin.name}</span>
                          {admin.id === adminUser?.id && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">
                              YOU
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          @{admin.username} &bull; {admin.email}
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                          admin.role === 'SUPER_ADMIN'
                            ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                            : admin.role === 'ADMIN'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
                        }`}
                      >
                        {admin.role.replace('_', ' ')}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      {admin.status === 'ACTIVE' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 w-max">
                          <CheckCircle2 className="w-3 h-3" />
                          ACTIVE
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center gap-1 w-max">
                          <XCircle className="w-3 h-3" />
                          DISABLED
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4">
                      {admin.isInitialPassword ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1 w-max">
                          <AlertTriangle className="w-3 h-3" />
                          INITIAL (CHANGE REQ)
                        </span>
                      ) : (
                        <span className="text-slate-400 font-mono text-[11px]">
                          Personalized
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4 font-mono text-slate-400 text-[11px]">
                      {admin.lastLoginAt ? new Date(admin.lastLoginAt).toLocaleString() : 'Never logged in'}
                    </td>

                    {isSuperAdmin && (
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setEditingAdmin(admin)}
                            title="Edit Role & Details"
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => {
                              setResettingAdmin(admin);
                              setNewPasswordForReset('');
                            }}
                            title="Reset Password"
                            className="p-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 transition-colors"
                          >
                            <KeyRound className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => handleToggleStatus(admin)}
                            title={admin.status === 'ACTIVE' ? 'Disable Account' : 'Enable Account'}
                            className={`p-1.5 rounded-lg transition-colors ${
                              admin.status === 'ACTIVE'
                                ? 'bg-rose-500/10 hover:bg-rose-500/20 text-rose-400'
                                : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400'
                            }`}
                          >
                            {admin.status === 'ACTIVE' ? (
                              <XCircle className="w-3.5 h-3.5" />
                            ) : (
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            )}
                          </button>

                          {admin.id !== adminUser?.id && (
                            <button
                              onClick={() => handleDeleteAdmin(admin.id, admin.username)}
                              title="Delete Administrator"
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Roles & Permissions */}
      {activeTab === 'roles_permissions' && (
        <div className="space-y-6">
          <div className="text-xs text-slate-400 leading-relaxed max-w-2xl">
            NOTIQ platform implements strict Role-Based Access Control (RBAC). Permissions are verified on every single server API invocation to guarantee zero privilege escalation.
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Super Admin */}
            <div className="p-5 rounded-2xl bg-purple-500/5 border border-purple-500/30 space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-purple-400" />
                <h3 className="font-bold text-white text-sm">SUPER ADMIN</h3>
              </div>
              <p className="text-xs text-slate-400">
                Full platform root authority. Can manage admins, reset security parameters, modify global league rules, and audit all platform operations.
              </p>
              <div className="pt-2 border-t border-purple-500/20 space-y-1.5 text-xs text-slate-300">
                <div className="flex items-center gap-2 text-emerald-400">
                  <Check className="w-3.5 h-3.5" /> <span>Full User Management & Deletions</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <Check className="w-3.5 h-3.5" /> <span>Admin Account Provisioning & Roles</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <Check className="w-3.5 h-3.5" /> <span>Password Resets & Key Issuance</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <Check className="w-3.5 h-3.5" /> <span>Global Leaderboard & Scoring Rules</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <Check className="w-3.5 h-3.5" /> <span>Anti-Cheat & Security Policy Config</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <Check className="w-3.5 h-3.5" /> <span>Immutable Audit Log Inspection</span>
                </div>
              </div>
            </div>

            {/* Admin */}
            <div className="p-5 rounded-2xl bg-amber-500/5 border border-amber-500/30 space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-amber-400" />
                <h3 className="font-bold text-white text-sm">ADMIN</h3>
              </div>
              <p className="text-xs text-slate-400">
                Academic operations lead. Manages syllabus challenges, cohorts, announcements, user reports, and student suspensions.
              </p>
              <div className="pt-2 border-t border-amber-500/20 space-y-1.5 text-xs text-slate-300">
                <div className="flex items-center gap-2 text-emerald-400">
                  <Check className="w-3.5 h-3.5" /> <span>Suspend & Reinstate Student Users</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <Check className="w-3.5 h-3.5" /> <span>Create Challenges & Achievements</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <Check className="w-3.5 h-3.5" /> <span>Broadcast Cohort Announcements</span>
                </div>
                <div className="flex items-center gap-2 text-rose-400">
                  <X className="w-3.5 h-3.5" /> <span>Cannot Modify Other Admins</span>
                </div>
                <div className="flex items-center gap-2 text-rose-400">
                  <X className="w-3.5 h-3.5" /> <span>Cannot Change System Security Config</span>
                </div>
              </div>
            </div>

            {/* Moderator */}
            <div className="p-5 rounded-2xl bg-sky-500/5 border border-sky-500/30 space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-sky-400" />
                <h3 className="font-bold text-white text-sm">MODERATOR</h3>
              </div>
              <p className="text-xs text-slate-400">
                Academic proctor. Inspects suspicious timers, resolves peer misconduct reports, and posts cohort notifications.
              </p>
              <div className="pt-2 border-t border-sky-500/20 space-y-1.5 text-xs text-slate-300">
                <div className="flex items-center gap-2 text-emerald-400">
                  <Check className="w-3.5 h-3.5" /> <span>Review Student Reports</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <Check className="w-3.5 h-3.5" /> <span>Broadcast General Announcements</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <Check className="w-3.5 h-3.5" /> <span>Inspect Leaderboard Standings</span>
                </div>
                <div className="flex items-center gap-2 text-rose-400">
                  <X className="w-3.5 h-3.5" /> <span>Cannot Suspend Users Directly</span>
                </div>
                <div className="flex items-center gap-2 text-rose-400">
                  <X className="w-3.5 h-3.5" /> <span>Cannot Edit Challenges or Rules</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Security & Password */}
      {activeTab === 'security' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Change Own Password Form */}
          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
            <div className="flex items-center gap-2.5">
              <KeyRound className="w-5 h-5 text-amber-400" />
              <h2 className="text-base font-bold text-white">Change Your Password</h2>
            </div>
            <p className="text-xs text-slate-400">
              Update your individual administrator password. Old sessions will be securely invalidated.
            </p>

            {pwdError && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{pwdError}</span>
              </div>
            )}

            {pwdSuccess && (
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Password successfully updated and hashed.</span>
              </div>
            )}

            <form onSubmit={handleChangeOwnPassword} className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Current Password
                </label>
                <input
                  type="password"
                  required
                  value={currentPwd}
                  onChange={e => setCurrentPwd(e.target.value)}
                  placeholder="Enter current password"
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  New Password
                </label>
                <input
                  type="password"
                  required
                  value={newPwd}
                  onChange={e => setNewPwd(e.target.value)}
                  placeholder="Must meet complexity rules"
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  required
                  value={confirmPwd}
                  onChange={e => setConfirmPwd(e.target.value)}
                  placeholder="Re-enter new password"
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-sm"
                >
                  Update & Encrypt Password
                </button>
              </div>
            </form>
          </div>

          {/* Security Protocols Display */}
          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
            <div className="flex items-center gap-2.5">
              <Lock className="w-5 h-5 text-emerald-400" />
              <h2 className="text-base font-bold text-white">Active Cryptographic Controls</h2>
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                <span className="font-semibold text-white block">Key Derivation Algorithm</span>
                <p className="text-slate-400 text-[11px]">
                  Scrypt-64 with CSPRNG 16-byte random salts. Resilient against hardware brute-force attacks.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                <span className="font-semibold text-white block">Session Lifespan & Tokens</span>
                <p className="text-slate-400 text-[11px]">
                  256-bit cryptographically secure session tokens expiring automatically after 24 hours.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                <span className="font-semibold text-white block">Brute-Force Rate Limiting</span>
                <p className="text-slate-400 text-[11px]">
                  Enforces 5 consecutive failed attempt threshold, triggering a 15-minute IP/account lockout.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                <span className="font-semibold text-white block">Initial Password Quarantine</span>
                <p className="text-slate-400 text-[11px]">
                  Detects default installation credentials and prompts for an immediate mandatory password change.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Audit Logs */}
      {activeTab === 'audit_logs' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {/* Search and filters */}
            <div className="flex flex-wrap items-center gap-2 flex-1">
              <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs flex-1 max-w-sm">
                <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <input
                  type="text"
                  value={auditSearch}
                  onChange={e => setAuditSearch(e.target.value)}
                  placeholder="Search logs by admin, target, action..."
                  className="bg-transparent text-slate-100 placeholder:text-slate-500 outline-none w-full"
                />
              </div>

              <select
                value={auditActionFilter}
                onChange={e => setAuditActionFilter(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 outline-none"
              >
                <option value="ALL">All Actions</option>
                <option value="ADMIN_LOGIN">Logins</option>
                <option value="PASSWORD_CHANGED">Password Changes</option>
                <option value="USER_SUSPENDED">Suspensions</option>
                <option value="CHALLENGE_CREATED">Challenges</option>
                <option value="ANNOUNCEMENT_CREATED">Announcements</option>
              </select>

              <select
                value={auditRoleFilter}
                onChange={e => setAuditRoleFilter(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 outline-none"
              >
                <option value="ALL">All Roles</option>
                <option value="SUPER_ADMIN">Super Admin</option>
                <option value="ADMIN">Admin</option>
                <option value="MODERATOR">Moderator</option>
                <option value="SYSTEM">System</option>
              </select>
            </div>

            <button
              onClick={exportAuditLogs}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Audit Trail</span>
            </button>
          </div>

          <div className="rounded-xl border border-slate-800 overflow-x-auto bg-slate-900/60">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-900/90 text-slate-400 font-mono uppercase text-[10px]">
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Operator</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Action</th>
                  <th className="py-3 px-4">Target</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Metadata</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                {filteredAuditLogs.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-500 font-sans">
                      No audit events found matching filters.
                    </td>
                  </tr>
                ) : (
                  filteredAuditLogs.map(log => (
                    <tr key={log.id} className="hover:bg-slate-850/50 transition-colors">
                      <td className="py-2.5 px-4 text-slate-400 whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-4 text-slate-200 font-semibold">
                        @{log.adminUsername}
                      </td>
                      <td className="py-2.5 px-4">
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300">
                          {log.role}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 font-bold text-amber-300">
                        {log.action}
                      </td>
                      <td className="py-2.5 px-4 text-slate-300">
                        {log.target}
                      </td>
                      <td className="py-2.5 px-4">
                        <span
                          className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                            log.status === 'SUCCESS'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : log.status === 'WARNING'
                              ? 'bg-amber-500/20 text-amber-400'
                              : 'bg-rose-500/20 text-rose-400'
                          }`}
                        >
                          {log.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-slate-400 text-[10px] truncate max-w-xs" title={JSON.stringify(log.metadata)}>
                        {log.metadata ? JSON.stringify(log.metadata) : '—'}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Admin Modal */}
      {showAddAdminModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-amber-400" />
              <span>Provision Administrator Account</span>
            </h3>

            <form onSubmit={handleCreateAdmin} className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Username
                </label>
                <input
                  type="text"
                  required
                  value={newAdminUsername}
                  onChange={e => setNewAdminUsername(e.target.value)}
                  placeholder="e.g. curator_john"
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={newAdminName}
                  onChange={e => setNewAdminName(e.target.value)}
                  placeholder="e.g. John Doe"
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Institutional Email
                </label>
                <input
                  type="email"
                  required
                  value={newAdminEmail}
                  onChange={e => setNewAdminEmail(e.target.value)}
                  placeholder="jdoe@notiq.academic"
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Privilege Role
                </label>
                <select
                  value={newAdminRole}
                  onChange={e => setNewAdminRole(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                >
                  <option value="MODERATOR">MODERATOR — Review reports & announcements</option>
                  <option value="ADMIN">ADMIN — Moderate users, challenges, leagues</option>
                  <option value="SUPER_ADMIN">SUPER ADMIN — Root governance & security</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Initial Password
                </label>
                <input
                  type="password"
                  required
                  value={newAdminPassword}
                  onChange={e => setNewAdminPassword(e.target.value)}
                  placeholder="Must contain uppercase, number, symbol"
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddAdminModal(false)}
                  className="px-3.5 py-2 rounded-xl text-xs text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider"
                >
                  Create & Issue Key
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Admin Modal */}
      {editingAdmin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-white">
              Edit Administrator @{editingAdmin.username}
            </h3>

            <form onSubmit={handleUpdateAdmin} className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={editingAdmin.name}
                  onChange={e => setEditingAdmin({ ...editingAdmin, name: e.target.value })}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Email
                </label>
                <input
                  type="email"
                  required
                  value={editingAdmin.email}
                  onChange={e => setEditingAdmin({ ...editingAdmin, email: e.target.value })}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Privilege Role
                </label>
                <select
                  value={editingAdmin.role}
                  onChange={e => setEditingAdmin({ ...editingAdmin, role: e.target.value as any })}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                >
                  <option value="MODERATOR">MODERATOR</option>
                  <option value="ADMIN">ADMIN</option>
                  <option value="SUPER_ADMIN">SUPER ADMIN</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Account Status
                </label>
                <select
                  value={editingAdmin.status}
                  onChange={e => setEditingAdmin({ ...editingAdmin, status: e.target.value as any })}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                >
                  <option value="ACTIVE">ACTIVE</option>
                  <option value="DISABLED">DISABLED</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setEditingAdmin(null)}
                  className="px-3.5 py-2 rounded-xl text-xs text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reset Admin Password Modal */}
      {resettingAdmin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/40 rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-amber-400" />
              <span>Reset Password for @{resettingAdmin.username}</span>
            </h3>
            <p className="text-xs text-slate-400">
              Provide a new temporary password. The administrator will be prompted to change it upon their next sign-in.
            </p>

            <form onSubmit={handleResetPassword} className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  New Temporary Password
                </label>
                <input
                  type="password"
                  required
                  value={newPasswordForReset}
                  onChange={e => setNewPasswordForReset(e.target.value)}
                  placeholder="Min 8 chars, uppercase, number, symbol"
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setResettingAdmin(null)}
                  className="px-3.5 py-2 rounded-xl text-xs text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase"
                >
                  Reset & Enforce Change
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
