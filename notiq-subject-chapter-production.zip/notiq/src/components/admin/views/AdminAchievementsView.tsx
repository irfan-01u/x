import React, { useState, useEffect } from 'react';
import {
  Award,
  PlusCircle,
  Sliders,
  CheckCircle2,
  Sparkles,
  Flame,
  Clock,
  Target,
  BookOpen,
  Edit,
} from 'lucide-react';
import { useAdminAuth } from '../../../context/AdminAuthContext';

interface AchievementItem {
  id: string;
  title: string;
  description: string;
  category: string;
  tier: string;
  xp: number;
  ruleMetric: string;
  ruleThreshold: number;
  unlocksCount: number;
  status: string;
  icon: string;
}

interface AdminAchievementsViewProps {
  initialSubItem?: string;
}

export const AdminAchievementsView: React.FC<AdminAchievementsViewProps> = ({
  initialSubItem = 'achievement_list',
}) => {
  const { token, adminUser } = useAdminAuth();

  const [activeTab, setActiveTab] = useState(initialSubItem);
  const [achievements, setAchievements] = useState<AchievementItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<string | null>(null);

  // Create form
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('TIME');
  const [tier, setTier] = useState('GOLD');
  const [xp, setXp] = useState(500);
  const [ruleMetric, setRuleMetric] = useState('study_hours');
  const [ruleThreshold, setRuleThreshold] = useState(50);
  const [icon, setIcon] = useState('Award');

  useEffect(() => {
    if (initialSubItem) {
      setActiveTab(initialSubItem);
    }
  }, [initialSubItem]);

  const fetchAchievements = async () => {
    try {
      const res = await fetch('/api/admin/achievements', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setAchievements(data);
      }
    } catch (err) {
      console.error('Failed to fetch achievements:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAchievements();
  }, [token]);

  const handleCreateAchievement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description) return;

    try {
      const res = await fetch('/api/admin/achievements', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title,
          description,
          category,
          tier,
          xp: Number(xp),
          ruleMetric,
          ruleThreshold: Number(ruleThreshold),
          icon,
        }),
      });

      if (res.ok) {
        setMessage('New achievement rule established and synced to unlock evaluator.');
        setTimeout(() => setMessage(null), 4000);
        setTitle('');
        setDescription('');
        setActiveTab('achievement_list');
        fetchAchievements();
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to create achievement');
      }
    } catch (err: any) {
      alert(err.message || 'Network error');
    }
  };

  const getTierBadge = (t: string) => {
    switch (t) {
      case 'DIAMOND':
        return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30';
      case 'PLATINUM':
        return 'bg-slate-300/20 text-slate-200 border-slate-300/30';
      case 'GOLD':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'SILVER':
        return 'bg-slate-400/20 text-slate-300 border-slate-400/30';
      default:
        return 'bg-amber-700/20 text-amber-500 border-amber-700/30';
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto text-slate-100">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-purple-400 font-bold uppercase tracking-wider">
            <Award className="w-4 h-4" />
            <span>Academic Milestones & Badges</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1">
            Achievement Catalog & Recognition Rules
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Configure unlock conditions, badge artwork, and XP awards for student milestones.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('create_achievement')}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-sm shadow-amber-500/20"
        >
          <PlusCircle className="w-4 h-4" />
          <span>New Achievement</span>
        </button>
      </div>

      {message && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        {[
          { key: 'achievement_list', label: 'Achievement List', count: achievements.length },
          { key: 'create_achievement', label: 'Create Achievement' },
          { key: 'achievement_rules', label: 'Achievement Rules Engine' },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
              activeTab === tab.key
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <span>{tab.label}</span>
            {tab.count !== undefined && (
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                  activeTab === tab.key ? 'bg-slate-950/30 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* List Tab */}
      {activeTab === 'achievement_list' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {achievements.map(a => (
            <div
              key={a.id}
              className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-sm leading-tight">{a.title}</h3>
                    <div className="flex items-center gap-1.5 mt-1">
                      <span className={`px-2 py-0.2 rounded text-[10px] font-mono font-bold border ${getTierBadge(a.tier)}`}>
                        {a.tier}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        +{a.xp} XP
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">
                {a.description}
              </p>

              <div className="pt-2 border-t border-slate-800 text-[11px] font-mono flex items-center justify-between text-slate-400">
                <span>Rule: {a.ruleMetric} &ge; {a.ruleThreshold}</span>
                <span className="text-white font-bold">{a.unlocksCount} Unlocked</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Tab */}
      {activeTab === 'create_achievement' && (
        <div className="max-w-xl p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <PlusCircle className="w-5 h-5 text-amber-400" />
            <span>Establish New Milestone Achievement</span>
          </h2>

          <form onSubmit={handleCreateAchievement} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Achievement Name
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Master of Late-Night Focus"
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Badge Description
              </label>
              <textarea
                required
                rows={2}
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Describe how the student earns this badge..."
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Category
                </label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                >
                  <option value="TIME">Study Time Hours</option>
                  <option value="STREAK">Streak Days</option>
                  <option value="POMODORO">Pomodoro Count</option>
                  <option value="ACADEMIC">Syllabus Completion</option>
                  <option value="MASTERY">Revision Mastery</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Tier Bracket
                </label>
                <select
                  value={tier}
                  onChange={e => setTier(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                >
                  <option value="BRONZE">BRONZE</option>
                  <option value="SILVER">SILVER</option>
                  <option value="GOLD">GOLD</option>
                  <option value="PLATINUM">PLATINUM</option>
                  <option value="DIAMOND">DIAMOND</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  XP Value
                </label>
                <input
                  type="number"
                  min={25}
                  required
                  value={xp}
                  onChange={e => setXp(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Rule Target Threshold
                </label>
                <input
                  type="number"
                  min={1}
                  required
                  value={ruleThreshold}
                  onChange={e => setRuleThreshold(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-sm"
              >
                Register Achievement Rule
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Rules Engine Tab */}
      {activeTab === 'achievement_rules' && (
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4 max-w-2xl text-xs text-slate-300">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-white">Automated Verification Evaluator</h2>
          </div>
          <p className="text-slate-400">
            Achievements evaluate immediately upon conclusion of any verified study session or chronometer finish.
          </p>

          <div className="space-y-2">
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="font-semibold text-white">Atomic Transaction Guarantees:</span> Once awarded, achievements cannot duplicate or desynchronize.
            </div>
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="font-semibold text-white">Retroactive Evaluation:</span> When a new achievement rule is created, eligible student accounts unlock it on their next completed session.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
