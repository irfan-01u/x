import React, { useState, useEffect } from 'react';
import {
  Users,
  Search,
  UserCheck,
  UserX,
  AlertTriangle,
  RotateCcw,
  Trash2,
  CheckCircle2,
  Plus,
  ShieldAlert,
  Flame,
  Clock,
  BookOpen,
  Filter,
  User,
} from 'lucide-react';
import { useAdminAuth } from '../../../context/AdminAuthContext';

interface StudentUser {
  id: string;
  username: string;
  name: string;
  email: string;
  avatar: string;
  totalStudyHours: number;
  sessionsCount: number;
  currentStreak: number;
  achievementsUnlocked: number;
  league: string;
  leaguePoints: number;
  status: 'ACTIVE' | 'SUSPENDED';
  joinedAt: string;
  lastActiveAt: string;
  reportsCount: number;
  suspendReason?: string;
}

interface UserReport {
  id: string;
  targetUserId: string;
  targetUsername: string;
  reportedBy: string;
  reason: string;
  description: string;
  timestamp: string;
  status: 'PENDING' | 'RESOLVED' | 'DISMISSED';
  resolvedBy?: string;
  resolvedAt?: string;
  resolutionNote?: string;
}

interface AdminUsersViewProps {
  initialSubItem?: string;
}

export const AdminUsersView: React.FC<AdminUsersViewProps> = ({ initialSubItem = 'all_users' }) => {
  const { token, adminUser } = useAdminAuth();

  const [activeTab, setActiveTab] = useState<string>(initialSubItem);
  const [users, setUsers] = useState<StudentUser[]>([]);
  const [reports, setReports] = useState<UserReport[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  // Modals / Prompts
  const [suspendingUser, setSuspendingUser] = useState<StudentUser | null>(null);
  const [suspendReason, setSuspendReason] = useState('');
  const [resolvingReport, setResolvingReport] = useState<UserReport | null>(null);
  const [resolutionNote, setResolutionNote] = useState('');
  const [showAddUserModal, setShowAddUserModal] = useState(false);

  // New user form state
  const [newUsername, setNewUsername] = useState('');
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newLeague, setNewLeague] = useState('Bronze');

  useEffect(() => {
    if (initialSubItem) {
      setActiveTab(initialSubItem);
    }
  }, [initialSubItem]);

  const fetchUsers = async () => {
    try {
      const res = await fetch(`/api/admin/users?search=${encodeURIComponent(search)}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setUsers(data);
      }
    } catch (err) {
      console.error('Failed to fetch users:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchReports = async () => {
    try {
      const res = await fetch('/api/admin/user-reports', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setReports(data);
      }
    } catch (err) {
      console.error('Failed to fetch reports:', err);
    }
  };

  useEffect(() => {
    fetchUsers();
    fetchReports();
  }, [token, search]);

  const handleUserAction = async (userId: string, action: string, reason?: string) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}/action`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ action, reason }),
      });
      const data = await res.json();
      if (res.ok) {
        setActionMessage(data.message);
        setTimeout(() => setActionMessage(null), 3000);
        fetchUsers();
      } else {
        alert(data.error || 'Action failed');
      }
    } catch (err: any) {
      alert(err.message || 'Network error');
    }
  };

  const handleResolveReport = async (reportId: string, status: 'RESOLVED' | 'DISMISSED') => {
    try {
      const res = await fetch(`/api/admin/user-reports/${reportId}/resolve`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status, resolutionNote }),
      });
      if (res.ok) {
        setActionMessage(`Report marked as ${status.toLowerCase()}`);
        setTimeout(() => setActionMessage(null), 3000);
        setResolvingReport(null);
        setResolutionNote('');
        fetchReports();
      }
    } catch (err) {
      console.error('Failed to resolve report:', err);
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername || !newName || !newEmail) return;

    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          username: newUsername,
          name: newName,
          email: newEmail,
          league: newLeague,
        }),
      });

      if (res.ok) {
        setShowAddUserModal(false);
        setNewUsername('');
        setNewName('');
        setNewEmail('');
        setActionMessage('Student user created successfully.');
        setTimeout(() => setActionMessage(null), 3000);
        fetchUsers();
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to create student user');
      }
    } catch (err: any) {
      alert(err.message || 'Network error');
    }
  };

  // Filter users based on tab
  const filteredUsers = users.filter(u => {
    if (activeTab === 'active_users') return u.status === 'ACTIVE';
    if (activeTab === 'suspended_users') return u.status === 'SUSPENDED';
    return true;
  });

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto text-slate-100">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-sky-400 font-bold uppercase tracking-wider">
            <Users className="w-4 h-4" />
            <span>Platform User Management</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1">
            Student Accounts & Discipline
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Audit student study records, enforce academic fair play, and moderate community reports.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAddUserModal(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-sm shadow-amber-500/20"
          >
            <Plus className="w-4 h-4" />
            <span>Enroll Student</span>
          </button>
        </div>
      </div>

      {actionMessage && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
        {[
          { key: 'all_users', label: 'All Users', count: users.length },
          { key: 'active_users', label: 'Active Users', count: users.filter(u => u.status === 'ACTIVE').length },
          { key: 'suspended_users', label: 'Suspended Users', count: users.filter(u => u.status === 'SUSPENDED').length },
          { key: 'user_reports', label: 'User Reports', count: reports.filter(r => r.status === 'PENDING').length },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
              activeTab === tab.key
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <span>{tab.label}</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                activeTab === tab.key ? 'bg-slate-950/30 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Content depending on active tab */}
      {activeTab === 'user_reports' ? (
        /* User Reports Sub-view */
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Review student misconduct flags & timer integrity anomalies.</span>
            <span className="font-mono">{reports.length} total reports filed</span>
          </div>

          <div className="space-y-3">
            {reports.map(rep => (
              <div
                key={rep.id}
                className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3"
              >
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-200">
                        @{rep.targetUsername}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                        {rep.reason}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold ${
                          rep.status === 'PENDING'
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-emerald-500/20 text-emerald-300'
                        }`}
                      >
                        {rep.status}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-1">
                      Reported by <span className="text-slate-300 font-mono">@{rep.reportedBy}</span> &bull; {new Date(rep.timestamp).toLocaleString()}
                    </div>
                  </div>

                  {rep.status === 'PENDING' && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setResolvingReport(rep);
                          setResolutionNote('');
                        }}
                        className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition-colors"
                      >
                        Take Action
                      </button>
                    </div>
                  )}
                </div>

                <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/80 text-xs text-slate-300 leading-relaxed font-mono">
                  "{rep.description}"
                </div>

                {rep.status === 'RESOLVED' && (
                  <div className="text-xs text-emerald-400/90 pt-1 border-t border-slate-800">
                    <span className="font-semibold">Resolved by {rep.resolvedBy}:</span> {rep.resolutionNote}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Users Table Sub-view */
        <div className="space-y-4">
          {/* Search bar */}
          <div className="flex items-center gap-3 bg-slate-900/80 border border-slate-800 rounded-xl px-3 py-2 text-xs">
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search students by username, full name, or university email..."
              className="w-full bg-transparent text-slate-100 placeholder:text-slate-500 outline-none"
            />
          </div>

          {/* Table */}
          <div className="rounded-xl border border-slate-800 overflow-x-auto bg-slate-900/60">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-900/90 text-slate-400 font-mono uppercase text-[10px]">
                  <th className="py-3 px-4">Student</th>
                  <th className="py-3 px-4">Study Time</th>
                  <th className="py-3 px-4">Streak</th>
                  <th className="py-3 px-4">League Division</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Moderation Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredUsers.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500">
                      No student records found matching filter criteria.
                    </td>
                  </tr>
                ) : (
                  filteredUsers.map(user => (
                    <tr key={user.id} className="hover:bg-slate-850/50 transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          {user.avatar ? <img src={user.avatar} alt={user.username} className="w-8 h-8 rounded-lg object-cover bg-slate-800 shrink-0" /> : <div className="w-8 h-8 rounded-lg bg-slate-800 shrink-0 flex items-center justify-center"><User className="w-4 h-4 text-slate-500" /></div>}
                          <div>
                            <div className="font-semibold text-slate-100 leading-tight">
                              {user.name}
                            </div>
                            <div className="text-[11px] text-slate-400 font-mono">
                              @{user.username}
                            </div>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4 font-mono">
                        <div className="text-slate-200 font-bold">
                          {user.totalStudyHours} hrs
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {user.sessionsCount} sessions
                        </div>
                      </td>

                      <td className="py-3 px-4 font-mono">
                        <div className="flex items-center gap-1 text-amber-400 font-bold">
                          <Flame className="w-3.5 h-3.5" />
                          <span>{user.currentStreak}d</span>
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-slate-200 border border-slate-700">
                          {user.league} ({user.leaguePoints} pts)
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        {user.status === 'ACTIVE' ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 w-max">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                            ACTIVE
                          </span>
                        ) : (
                          <div>
                            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center gap-1 w-max">
                              <UserX className="w-3 h-3" />
                              SUSPENDED
                            </span>
                            {user.suspendReason && (
                              <div className="text-[10px] text-rose-300/70 mt-1 max-w-xs truncate" title={user.suspendReason}>
                                {user.suspendReason}
                              </div>
                            )}
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {user.status === 'ACTIVE' ? (
                            <button
                              onClick={() => {
                                setSuspendingUser(user);
                                setSuspendReason('');
                              }}
                              title="Suspend User"
                              className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors"
                            >
                              <UserX className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <button
                              onClick={() => handleUserAction(user.id, 'unsuspend')}
                              title="Restore User to Active"
                              className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 transition-colors"
                            >
                              <UserCheck className="w-3.5 h-3.5" />
                            </button>
                          )}

                          <button
                            onClick={() => {
                              if (confirm(`Reset current streak for ${user.username} to 0?`)) {
                                handleUserAction(user.id, 'reset_streak');
                              }
                            }}
                            title="Reset Streak"
                            className="p-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 transition-colors"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>

                          {adminUser?.role === 'SUPER_ADMIN' && (
                            <button
                              onClick={() => {
                                if (confirm(`Permanently delete account for ${user.username}?`)) {
                                  handleUserAction(user.id, 'delete');
                                }
                              }}
                              title="Delete Record"
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Suspend Reason Dialog */}
      {suspendingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-slate-900 border border-rose-500/40 rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">
                  Suspend Student Account
                </h3>
                <p className="text-xs text-slate-400">
                  Target: @{suspendingUser.username}
                </p>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Reason for Suspension
              </label>
              <textarea
                required
                rows={3}
                value={suspendReason}
                onChange={e => setSuspendReason(e.target.value)}
                placeholder="Specify violation (e.g., bot scripted study intervals, abusive bio, fraudulent league points)..."
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-600 focus:border-rose-500 outline-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSuspendingUser(null)}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-slate-200"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleUserAction(suspendingUser.id, 'suspend', suspendReason);
                  setSuspendingUser(null);
                }}
                disabled={!suspendReason.trim()}
                className="px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 disabled:opacity-50 text-white font-bold text-xs uppercase tracking-wider transition-all"
              >
                Confirm Suspension
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Resolve Report Dialog */}
      {resolvingReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-white">
              Resolve Peer Report #{resolvingReport.id}
            </h3>
            <p className="text-xs text-slate-400">
              Target: @{resolvingReport.targetUsername} &bull; Flag: {resolvingReport.reason}
            </p>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Administrative Resolution Note
              </label>
              <textarea
                rows={3}
                value={resolutionNote}
                onChange={e => setResolutionNote(e.target.value)}
                placeholder="Describe resolution taken (e.g. user warned, sessions audited, flag dismissed)..."
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-600 focus:border-amber-500 outline-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setResolvingReport(null)}
                className="px-3.5 py-2 rounded-xl text-xs text-slate-400"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => handleResolveReport(resolvingReport.id, 'DISMISSED')}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
              >
                Dismiss
              </button>
              <button
                type="button"
                onClick={() => handleResolveReport(resolvingReport.id, 'RESOLVED')}
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs uppercase"
              >
                Mark Resolved
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add User Modal */}
      {showAddUserModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-white">
              Enroll New Student
            </h3>

            <form onSubmit={handleCreateUser} className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Username
                </label>
                <input
                  type="text"
                  required
                  value={newUsername}
                  onChange={e => setNewUsername(e.target.value)}
                  placeholder="e.g. marcus_aurelius"
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  placeholder="e.g. Marcus Aurelius"
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Institutional Email
                </label>
                <input
                  type="email"
                  required
                  value={newEmail}
                  onChange={e => setNewEmail(e.target.value)}
                  placeholder="student@university.edu"
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Initial League
                </label>
                <select
                  value={newLeague}
                  onChange={e => setNewLeague(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                >
                  <option value="Bronze">Bronze League</option>
                  <option value="Silver">Silver League</option>
                  <option value="Gold">Gold League</option>
                  <option value="Platinum">Platinum League</option>
                  <option value="Diamond">Diamond League</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddUserModal(false)}
                  className="px-3.5 py-2 rounded-xl text-xs text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider"
                >
                  Register Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
