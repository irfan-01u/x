import React, { useEffect, useState } from 'react';
import {
  Users,
  UserCheck,
  UserPlus,
  Clock,
  BookOpen,
  Flame,
  Award,
  Trophy,
  Server,
  Activity,
  ShieldAlert,
  AlertTriangle,
  ArrowUpRight,
  RefreshCw,
  Megaphone,
} from 'lucide-react';
import { useAdminAuth } from '../../../context/AdminAuthContext';
import { type AdminNavSelection } from '../AdminSidebar';

interface DashboardStats {
  totalUsers: number;
  activeUsers: number;
  suspendedUsers: number;
  newUsers: number;
  totalStudyHours: number;
  totalStudySessions: number;
  activeStreaksCount: number;
  totalAchievementsUnlocked: number;
  totalAchievementsConfigured: number;
  activeChallenges: number;
  totalChallenges: number;
  currentLeagueUsers: number;
  pendingReportsCount: number;
  adminsCount: number;
  systemStatus: {
    uptimeSeconds: number;
    nodeVersion: string;
    antiCheatMode: string;
    maintenanceMode: boolean;
    databaseHealthy: boolean;
    lastBackup: string;
  };
}

interface AdminDashboardViewProps {
  onNavigate: (nav: AdminNavSelection) => void;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({ onNavigate }) => {
  const { token, adminUser } = useAdminAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/admin/dashboard', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      }
    } catch (err) {
      console.error('Error fetching dashboard metrics:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, [token]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchStats();
  };

  const formatUptime = (seconds: number) => {
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    if (d > 0) return `${d}d ${h}h ${m}m`;
    if (h > 0) return `${h}h ${m}m ${s}s`;
    return `${m}m ${s}s`;
  };

  if (loading) {
    return (
      <div className="p-8 flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
          <span className="text-xs text-slate-400 font-mono">Aggregating live platform telemetry...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto text-slate-100">
      {/* Top Banner / Welcome */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 font-bold uppercase tracking-wider">
            <Activity className="w-4 h-4" />
            <span>Operational Control Plane</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1">
            System Overview & Real-Time Telemetry
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real platform metrics derived directly from student activity records and administrative audit events.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium text-slate-300 hover:text-white bg-slate-900 border border-slate-700/80 hover:border-slate-600 transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-amber-400' : ''}`} />
            <span>{refreshing ? 'Syncing...' : 'Sync Telemetry'}</span>
          </button>
        </div>
      </div>

      {/* Pending Reports Alert if any */}
      {stats && stats.pendingReportsCount > 0 && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
            <div>
              <p className="text-xs font-semibold text-rose-200">
                Action Required: {stats.pendingReportsCount} Pending Student Report(s)
              </p>
              <p className="text-[11px] text-rose-300/80">
                Suspicious study session durations or leaderboard exploits flagged by academic peers.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate({ section: 'users', subItem: 'user_reports' })}
            className="px-3 py-1.5 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs transition-colors shrink-0"
          >
            Review Reports
          </button>
        </div>
      )}

      {/* Grid of Real Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {/* Total Users */}
        <div
          onClick={() => onNavigate({ section: 'users', subItem: 'all_users' })}
          className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Students</span>
            <Users className="w-4 h-4 text-sky-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-white">
            {stats?.totalUsers || 0}
          </div>
          <div className="mt-1 text-[11px] text-slate-400 flex items-center gap-1">
            <span className="text-emerald-400 font-semibold">{stats?.activeUsers || 0} active</span>
            <span>&bull;</span>
            <span className="text-rose-400 font-semibold">{stats?.suspendedUsers || 0} suspended</span>
          </div>
        </div>

        {/* Active Streaks */}
        <div
          onClick={() => onNavigate({ section: 'users', subItem: 'active_users' })}
          className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Active Streaks</span>
            <Flame className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-amber-300">
            {stats?.activeStreaksCount || 0}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Scholars with active daily study streaks
          </div>
        </div>

        {/* Total Study Hours */}
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Study Hours</span>
            <Clock className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-emerald-300">
            {stats?.totalStudyHours.toLocaleString() || 0} <span className="text-sm font-normal text-slate-400">hrs</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Aggregated across all verified modules
          </div>
        </div>

        {/* Study Sessions */}
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Study Sessions</span>
            <BookOpen className="w-4 h-4 text-purple-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-purple-300">
            {stats?.totalStudySessions.toLocaleString() || 0}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Completed Pomodoros & Chronometers
          </div>
        </div>

        {/* Current League Users */}
        <div
          onClick={() => onNavigate({ section: 'leaderboard', subItem: 'weekly_leagues' })}
          className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Current League Users</span>
            <Trophy className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-white">
            {stats?.currentLeagueUsers || 0}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Competing in active weekly brackets
          </div>
        </div>

        {/* Active Challenges */}
        <div
          onClick={() => onNavigate({ section: 'challenges', subItem: 'active_challenges' })}
          className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Active Challenges</span>
            <Flame className="w-4 h-4 text-rose-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-white">
            {stats?.activeChallenges || 0}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            {stats?.totalChallenges || 0} Total Challenges Created
          </div>
        </div>

        {/* Total Achievements */}
        <div
          onClick={() => onNavigate({ section: 'achievements', subItem: 'achievement_list' })}
          className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Achievements Unlocked</span>
            <Award className="w-4 h-4 text-indigo-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-white">
            {stats?.totalAchievementsUnlocked || 0}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Across {stats?.totalAchievementsConfigured || 0} achievement rules
          </div>
        </div>

        {/* Administrators */}
        <div
          onClick={() => onNavigate({ section: 'admin_management', subItem: 'admin_accounts' })}
          className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Platform Admins</span>
            <ShieldAlert className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-white">
            {stats?.adminsCount || 0}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Authorized administrative operators
          </div>
        </div>
      </div>

      {/* System Status & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* System Health */}
        <div className="lg:col-span-1 p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Server className="w-4 h-4 text-amber-400" />
              <span>System & Engine Health</span>
            </h2>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              OPERATIONAL
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Engine Uptime</span>
              <span className="font-mono text-slate-200">
                {stats?.systemStatus ? formatUptime(stats.systemStatus.uptimeSeconds) : 'N/A'}
              </span>
            </div>

            <div className="flex items-center justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Node Runtime</span>
              <span className="font-mono text-slate-200">{stats?.systemStatus.nodeVersion}</span>
            </div>

            <div className="flex items-center justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Anti-Cheat Enforcement</span>
              <span className="font-mono text-amber-400 font-semibold">
                {stats?.systemStatus.antiCheatMode}
              </span>
            </div>

            <div className="flex items-center justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Database Engine</span>
              <span className="font-mono text-emerald-400 font-semibold">
                {stats?.systemStatus.databaseHealthy ? 'Healthy & Synced' : 'Degraded'}
              </span>
            </div>

            <div className="flex items-center justify-between py-1">
              <span className="text-slate-400">Maintenance Mode</span>
              <span className="font-mono text-slate-300">
                {stats?.systemStatus.maintenanceMode ? 'ENABLED (Restricted)' : 'OFF (Open)'}
              </span>
            </div>
          </div>
        </div>

        {/* Quick Operations Console */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Activity className="w-4 h-4 text-sky-400" />
            <span>Administrative Quick Operations</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <button
              onClick={() => onNavigate({ section: 'announcements', subItem: 'create_announcement' })}
              className="p-3.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-700/80 text-left transition-all flex items-start gap-3 group"
            >
              <Megaphone className="w-4 h-4 text-sky-400 shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
              <div>
                <div className="font-semibold text-slate-100 flex items-center gap-1">
                  <span>Broadcast Announcement</span>
                  <ArrowUpRight className="w-3 h-3 opacity-60" />
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Publish a high-priority notice to student dashboards.
                </p>
              </div>
            </button>

            <button
              onClick={() => onNavigate({ section: 'challenges', subItem: 'create_challenge' })}
              className="p-3.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-700/80 text-left transition-all flex items-start gap-3 group"
            >
              <Flame className="w-4 h-4 text-amber-400 shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
              <div>
                <div className="font-semibold text-slate-100 flex items-center gap-1">
                  <span>Launch Study Challenge</span>
                  <ArrowUpRight className="w-3 h-3 opacity-60" />
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Engage students with time or streak competitions.
                </p>
              </div>
            </button>

            <button
              onClick={() => onNavigate({ section: 'users', subItem: 'suspended_users' })}
              className="p-3.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-700/80 text-left transition-all flex items-start gap-3 group"
            >
              <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
              <div>
                <div className="font-semibold text-slate-100 flex items-center gap-1">
                  <span>Inspect Suspended Users</span>
                  <ArrowUpRight className="w-3 h-3 opacity-60" />
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Review anomalous timers and manage account appeals.
                </p>
              </div>
            </button>

            <button
              onClick={() => onNavigate({ section: 'admin_management', subItem: 'audit_logs' })}
              className="p-3.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-700/80 text-left transition-all flex items-start gap-3 group"
            >
              <Activity className="w-4 h-4 text-purple-400 shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
              <div>
                <div className="font-semibold text-slate-100 flex items-center gap-1">
                  <span>Review Audit Trail</span>
                  <ArrowUpRight className="w-3 h-3 opacity-60" />
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Verify administrative logins, role changes, and rules.
                </p>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
