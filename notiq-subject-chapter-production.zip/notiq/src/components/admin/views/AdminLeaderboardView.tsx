import React, { useState, useEffect } from 'react';
import {
  Trophy,
  Sliders,
  Flame,
  CheckCircle2,
  Clock,
  ShieldCheck,
  RefreshCw,
  Award,
  History,
  Calendar,
  AlertTriangle,
  Play,
  Crown,
} from 'lucide-react';
import { useAdminAuth } from '../../../context/AdminAuthContext';

interface LeaderboardRules {
  weekCycle: string;
  dailyResetTimezone: string;
  promotionCutoff: number;
  relegationCutoff: number;
  xpToPointsRatio: number;
  antiCheatWallClockStrictness: string;
  maxDailyHoursCap: number;
  lastCalculatedAt: string;
  lastDailyResetDate?: string;
  promotionPercentage: number;
  demotionPercentage: number;
  minimumParticipants: number;
  leagueTiers: string[];
}

interface AdminLeaderboardViewProps {
  initialSubItem?: string;
}

export const AdminLeaderboardView: React.FC<AdminLeaderboardViewProps> = ({
  initialSubItem = 'leaderboard_view',
}) => {
  const { token, adminUser } = useAdminAuth();

  const [activeTab, setActiveTab] = useState(initialSubItem);
  const [rules, setRules] = useState<LeaderboardRules | null>(null);
  const [leagues, setLeagues] = useState<Record<string, any[]>>({});
  const [dailyData, setDailyData] = useState<any>(null);
  const [dailyArchives, setDailyArchives] = useState<any[]>([]);
  const [selectedArchiveKey, setSelectedArchiveKey] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  // Form state for editing rules
  const [promotionCutoff, setPromotionCutoff] = useState(3);
  const [relegationCutoff, setRelegationCutoff] = useState(3);
  const [xpToPointsRatio, setXpToPointsRatio] = useState(1.0);
  const [antiCheatStrictness, setAntiCheatStrictness] = useState('MAXIMUM_STRICT');
  const [maxDailyHoursCap, setMaxDailyHoursCap] = useState(12);
  const [promotionPercentage, setPromotionPercentage] = useState(20);
  const [demotionPercentage, setDemotionPercentage] = useState(20);
  const [minimumParticipants, setMinimumParticipants] = useState(5);
  const [leagueTiers, setLeagueTiers] = useState('Bronze,Silver,Gold,Platinum,Diamond');
  const [dailyResetTimezone, setDailyResetTimezone] = useState('Asia/Dhaka');

  useEffect(() => {
    if (initialSubItem) {
      setActiveTab(initialSubItem);
    }
  }, [initialSubItem]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [resLeagues, resDaily, resArchives] = await Promise.all([
        fetch('/api/admin/leaderboard', {
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch('/api/admin/leaderboard/daily', {
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch('/api/admin/leaderboard/daily/archives', {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      if (resLeagues.ok) {
        const data = await resLeagues.json();
        setRules(data.rules);
        setLeagues(data.leagues || {});

        setPromotionCutoff(data.rules.promotionCutoff);
        setRelegationCutoff(data.rules.relegationCutoff);
        setXpToPointsRatio(data.rules.xpToPointsRatio);
        setAntiCheatStrictness(data.rules.antiCheatWallClockStrictness);
        setMaxDailyHoursCap(data.rules.maxDailyHoursCap);
        setPromotionPercentage(data.rules.promotionPercentage ?? 20);
        setDemotionPercentage(data.rules.demotionPercentage ?? 20);
        setMinimumParticipants(data.rules.minimumParticipants ?? 5);
        setLeagueTiers((data.rules.leagueTiers || ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond']).join(','));
        setDailyResetTimezone(data.rules.dailyResetTimezone || 'Asia/Dhaka');
      }

      if (resDaily.ok) {
        const dData = await resDaily.json();
        setDailyData(dData);
      }

      if (resArchives.ok) {
        const aData = await resArchives.json();
        setDailyArchives(aData);
        if (aData.length > 0 && !selectedArchiveKey) {
          setSelectedArchiveKey(aData[0].dateKey);
        }
      }
    } catch (err) {
      console.error('Failed to load admin leaderboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [token]);

  const handleSaveRules = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage(null);

    try {
      const res = await fetch('/api/admin/leaderboard/rules', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          promotionCutoff: Number(promotionCutoff),
          relegationCutoff: Number(relegationCutoff),
          xpToPointsRatio: Number(xpToPointsRatio),
          antiCheatWallClockStrictness: antiCheatStrictness,
          maxDailyHoursCap: Number(maxDailyHoursCap),
          promotionPercentage: Number(promotionPercentage),
          demotionPercentage: Number(demotionPercentage),
          minimumParticipants: Number(minimumParticipants),
          leagueTiers: leagueTiers.split(',').map(v => v.trim()).filter(Boolean),
          dailyResetTimezone,
        }),
      });

      if (res.ok) {
        setMessage('Leaderboard rules and daily reset configurations updated successfully.');
        setTimeout(() => setMessage(null), 4000);
        fetchData();
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to save rules');
      }
    } catch (err: any) {
      alert(err.message || 'Network error');
    } finally {
      setSaving(false);
    }
  };

  const handleTriggerDailyReset = async () => {
    if (!window.confirm('Trigger immediate daily reset and snapshot? This will seal standings for the current period and archive them.')) {
      return;
    }

    setResetting(true);
    setMessage(null);

    try {
      const res = await fetch('/api/admin/leaderboard/daily/reset', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({}),
      });

      if (res.ok) {
        const data = await res.json();
        setMessage(`Daily reset complete! Standings for ${data.snapshot.dateKey} sealed and archived.`);
        setTimeout(() => setMessage(null), 5000);
        fetchData();
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to trigger reset');
      }
    } catch (err: any) {
      alert(err.message || 'Network error triggering reset');
    } finally {
      setResetting(false);
    }
  };

  const isSuperOrAdmin = adminUser?.role === 'SUPER_ADMIN' || adminUser?.role === 'ADMIN';

  // Format seconds remaining into HH:mm:ss
  const sec = dailyData?.secondsUntilReset || 0;
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const formattedCountdown = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;

  const currentArchive = dailyArchives.find(a => a.dateKey === selectedArchiveKey) || dailyArchives[0] || null;

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto text-slate-100">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 font-bold uppercase tracking-wider">
            <Trophy className="w-4 h-4" />
            <span>Competitive League & Daily Reset Administration</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1">
            Leaderboard & League Operations
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage daily reset cycles (Asia/Dhaka), inspect sealed historical snapshots, and configure promotion thresholds.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchData}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-xs transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>

          {isSuperOrAdmin && (
            <button
              onClick={handleTriggerDailyReset}
              disabled={resetting}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow transition-all disabled:opacity-50"
            >
              <Clock className="w-3.5 h-3.5" />
              <span>{resetting ? 'Archiving...' : 'Trigger Daily Reset Now'}</span>
            </button>
          )}
        </div>
      </div>

      {message && (
        <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
        {[
          { key: 'leaderboard_view', label: 'Weekly League Brackets', icon: Trophy },
          { key: 'daily_leaderboard', label: 'Daily Leaderboard (Live)', icon: Clock },
          { key: 'daily_reset_archives', label: 'Daily Reset & Archives', icon: History },
          { key: 'leaderboard_rules', label: 'Rules & Anti-Cheat Config', icon: Sliders },
        ].map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === tab.key
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ------------------------------------------------------------- */}
      {/* TAB 1: WEEKLY LEAGUES                                         */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'leaderboard_view' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {Object.entries(leagues).map(([leagueName, users]) => (
              <div
                key={leagueName}
                className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3"
              >
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-amber-400" />
                    <h3 className="font-bold text-white text-sm">{leagueName} Division</h3>
                  </div>
                  <span className="text-xs font-mono text-slate-400">{users.length} Scholars</span>
                </div>

                <div className="space-y-2 text-xs">
                  {users.length === 0 ? (
                    <div className="py-4 text-center text-slate-500">No scholars in this tier</div>
                  ) : (
                    users.slice(0, 5).map((u, i) => (
                      <div
                        key={u.id}
                        className="flex items-center justify-between py-1.5 px-2 rounded-lg bg-slate-950/40 border border-slate-800"
                      >
                        <div className="flex items-center gap-2">
                          <span className="w-5 text-center font-mono font-bold text-amber-400 text-xs">
                            #{i + 1}
                          </span>
                          <span className="font-semibold text-slate-200">@{u.username}</span>
                        </div>
                        <div className="font-mono text-slate-300 font-bold">
                          {u.leaguePoints} pts
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 2: DAILY LEADERBOARD (LIVE)                               */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'daily_leaderboard' && (
        <div className="space-y-5">
          {/* Hero Banner */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold uppercase text-emerald-400">
                  Today's Active Period: {dailyData?.todayKey}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded font-mono font-bold bg-slate-800 text-slate-300">
                  Timezone: {dailyData?.timezone || 'Asia/Dhaka'}
                </span>
              </div>
              <h2 className="text-lg font-bold text-white mt-1">Live Daily Leaderboard Standing</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Total Study Logged Today: <strong>{Math.round((dailyData?.totalStudyMinutes || 0) / 60)} hours</strong> across {dailyData?.participantsCount || 0} scholars.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center min-w-[140px]">
              <div className="font-mono font-bold text-lg text-amber-400">{formattedCountdown}</div>
              <div className="text-[10px] text-slate-500 uppercase tracking-wider">Countdown to Reset</div>
            </div>
          </div>

          {/* Standings Table */}
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Live Participants & Study Durations
            </h3>

            <div className="space-y-1.5">
              {(dailyData?.rankings || []).map((user: any) => (
                <div
                  key={user.userId}
                  className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-850 text-xs"
                >
                  <div className="flex items-center gap-4">
                    <span className="w-6 font-mono font-bold text-center text-amber-400">
                      #{user.rank}
                    </span>
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-8 h-8 rounded-full object-cover border border-slate-700"
                    />
                    <div>
                      <div className="font-semibold text-white flex items-center gap-1.5">
                        <span>{user.name}</span>
                        {user.isCurrentUser && (
                          <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500 text-slate-950 font-bold">
                            YOU
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-400">@{user.username}</div>
                    </div>
                  </div>

                  <div className="font-mono font-bold text-right text-slate-200">
                    {Math.floor(user.studyMinutes / 60)}h {user.studyMinutes % 60}m
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 3: DAILY RESET & ARCHIVES                                */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'daily_reset_archives' && (
        <div className="space-y-5">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-sm font-bold text-white">Idempotent Daily Reset Snapshots</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Every midnight in {rules?.dailyResetTimezone || 'Asia/Dhaka'}, the server seals that day's final standings.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <label className="text-xs text-slate-400">Archive Date:</label>
              <select
                value={selectedArchiveKey}
                onChange={e => setSelectedArchiveKey(e.target.value)}
                className="text-xs p-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 font-mono outline-none"
              >
                {dailyArchives.map(a => (
                  <option key={a.dateKey} value={a.dateKey}>
                    {a.dateKey} &bull; Winner: {a.top3?.[0]?.name || 'N/A'}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {currentArchive ? (
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-white">Sealed Snapshot: {currentArchive.dateKey}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      IDEMPOTENT HASH VALIDATED
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5 font-mono">
                    Timezone: {currentArchive.timezone} &bull; Closed At: {new Date(currentArchive.closedAt).toLocaleString()}
                  </div>
                </div>

                <div className="text-right font-mono text-xs text-amber-400 font-bold">
                  {Math.round(currentArchive.totalStudyMinutes / 60)}h Total Studied
                </div>
              </div>

              {/* Top 3 Podium of Archive */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {(currentArchive.top3 || []).map((champ: any, idx: number) => (
                  <div
                    key={champ.userId || idx}
                    className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center space-y-2"
                  >
                    <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 font-mono font-bold text-xs inline-flex items-center justify-center">
                      #{idx + 1}
                    </span>
                    <img
                      src={champ.avatar}
                      alt={champ.name}
                      className="w-12 h-12 rounded-full mx-auto object-cover border border-slate-700"
                    />
                    <div>
                      <div className="font-bold text-xs text-white">{champ.name}</div>
                      <div className="text-[10px] text-slate-400">@{champ.username}</div>
                    </div>
                    <div className="font-mono font-bold text-xs text-amber-400">
                      {Math.floor(champ.studyMinutes / 60)}h {champ.studyMinutes % 60}m
                    </div>
                  </div>
                ))}
              </div>

              {/* Full Standings List */}
              <div className="space-y-1.5 pt-2">
                <span className="text-[11px] uppercase font-bold text-slate-400 block mb-2">
                  All Competitors ({currentArchive.rankings?.length || 0})
                </span>
                {(currentArchive.rankings || []).map((u: any, idx: number) => (
                  <div
                    key={u.userId || idx}
                    className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950/60 border border-slate-850 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-5 text-center font-mono text-slate-500">#{u.rank || idx + 1}</span>
                      <span className="font-semibold text-slate-200">{u.name}</span>
                      <span className="text-[10px] text-slate-500">@{u.username}</span>
                    </div>
                    <div className="font-mono text-slate-300 font-bold">
                      {Math.floor(u.studyMinutes / 60)}h {u.studyMinutes % 60}m
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-xs text-slate-500 bg-slate-900 rounded-xl border border-slate-800">
              No historical archives available.
            </div>
          )}
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 4: RULES & ANTI-CHEAT CONFIG                              */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'leaderboard_rules' && (
        <div className="max-w-2xl p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-white">Leaderboard & Daily Reset Configuration</h2>
          </div>
          <p className="text-xs text-slate-400">
            Configure automated daily midnight settlement, anti-cheat limits, and promotion parameters.
          </p>

          <form onSubmit={handleSaveRules} className="space-y-4 pt-2 text-xs">
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Daily Reset Timezone (Midnight Cutoff)
              </label>
              <select
                disabled={!isSuperOrAdmin}
                value={dailyResetTimezone}
                onChange={e => setDailyResetTimezone(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
              >
                <option value="Asia/Dhaka">Asia/Dhaka (UTC+6) &mdash; Standard Platform Cutoff</option>
                <option value="UTC">UTC (UTC+0)</option>
                <option value="America/New_York">America/New_York (UTC-5 / UTC-4)</option>
                <option value="Europe/London">Europe/London (UTC+0 / UTC+1)</option>
                <option value="Asia/Tokyo">Asia/Tokyo (UTC+9)</option>
              </select>
              <span className="text-[10px] text-slate-500 mt-1 block">
                The countdown chronometer and idempotent daily snapshot trigger at 00:00:00 in this timezone.
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Weekly Promotion Threshold (Top N)
                </label>
                <input
                  type="number"
                  min={1}
                  max={10}
                  disabled={!isSuperOrAdmin}
                  value={promotionCutoff}
                  onChange={e => setPromotionCutoff(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Weekly Relegation Threshold (Bottom N)
                </label>
                <input
                  type="number"
                  min={1}
                  max={10}
                  disabled={!isSuperOrAdmin}
                  value={relegationCutoff}
                  onChange={e => setRelegationCutoff(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">Promotion %</label>
                <input type="number" min={0} max={100} disabled={!isSuperOrAdmin} value={promotionPercentage} onChange={e => setPromotionPercentage(Number(e.target.value))} className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100" />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">Demotion %</label>
                <input type="number" min={0} max={100} disabled={!isSuperOrAdmin} value={demotionPercentage} onChange={e => setDemotionPercentage(Number(e.target.value))} className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100" />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">Min Participants</label>
                <input type="number" min={1} max={1000} disabled={!isSuperOrAdmin} value={minimumParticipants} onChange={e => setMinimumParticipants(Number(e.target.value))} className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100" />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">League Tiers</label>
              <input type="text" disabled={!isSuperOrAdmin} value={leagueTiers} onChange={e => setLeagueTiers(e.target.value)} className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100" />
              <span className="text-[10px] text-slate-500 mt-1 block">Comma-separated, lowest → highest. Example: Bronze,Silver,Gold,Platinum,Diamond.</span>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Max Daily Study Hours Cap (Anti-Bot Cap)
              </label>
              <input
                type="number"
                min={4}
                max={24}
                disabled={!isSuperOrAdmin}
                value={maxDailyHoursCap}
                onChange={e => setMaxDailyHoursCap(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">
                Study hours beyond this cap will not award competitive league points to prevent automated script abuse.
              </span>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Anti-Cheat Wall-Clock Strictness
              </label>
              <select
                disabled={!isSuperOrAdmin}
                value={antiCheatStrictness}
                onChange={e => setAntiCheatStrictness(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 focus:border-amber-500 outline-none font-mono"
              >
                <option value="MAXIMUM_STRICT">MAXIMUM STRICT &mdash; Strict NTP UTC drift verification & tab blur tracking</option>
                <option value="STANDARD">STANDARD &mdash; Regular tick verification</option>
                <option value="LENIENT">LENIENT &mdash; Allow offline sync without wall-clock enforcement</option>
              </select>
            </div>

            {isSuperOrAdmin && (
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-50"
                >
                  {saving ? 'Updating Engine...' : 'Commit & Apply Rules'}
                </button>
              </div>
            )}
          </form>
        </div>
      )}
    </div>
  );
};
