import React, { useState } from 'react';
import {
  LayoutDashboard,
  Users,
  Shield,
  Trophy,
  Award,
  Megaphone,
  Settings,
  ChevronDown,
  ChevronRight,
  UserCheck,
  UserX,
  FileQuestion,
  UserPlus,
  ShieldAlert,
  KeyRound,
  FileText,
  Flame,
  PlusCircle,
  History,
  Sliders,
  Sparkles,
  Server,
  Lock,
  Clock,
} from 'lucide-react';
import { useAdminAuth } from '../../context/AdminAuthContext';

export interface AdminNavSelection {
  section: string;
  subItem?: string;
}

interface AdminSidebarProps {
  currentNav: AdminNavSelection;
  onSelectNav: (nav: AdminNavSelection) => void;
  collapsed?: boolean;
}

export const AdminSidebar: React.FC<AdminSidebarProps> = ({
  currentNav,
  onSelectNav,
  collapsed = false,
}) => {
  const { adminUser } = useAdminAuth();

  // Track expanded parent sections
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    users: true,
    admin_management: true,
    leaderboard: false,
    challenges: false,
    achievements: false,
    announcements: false,
    settings: false,
  });

  const toggleSection = (sectionKey: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionKey]: !prev[sectionKey],
    }));
  };

  const navGroups = [
    {
      key: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      isLeaf: true,
    },
    {
      key: 'users',
      label: 'Users',
      icon: Users,
      subItems: [
        { key: 'all_users', label: 'All Users', icon: Users },
        { key: 'active_users', label: 'Active Users', icon: UserCheck },
        { key: 'suspended_users', label: 'Suspended Users', icon: UserX },
        { key: 'user_reports', label: 'User Reports', icon: FileQuestion },
      ],
    },
    {
      key: 'admin_management',
      label: 'Admin Management',
      icon: Shield,
      subItems: [
        { key: 'admin_accounts', label: 'Admin Accounts', icon: UserPlus },
        { key: 'roles_permissions', label: 'Roles & Permissions', icon: ShieldAlert },
        { key: 'security', label: 'Security', icon: Lock },
        { key: 'audit_logs', label: 'Audit Logs', icon: FileText },
      ],
    },
    {
      key: 'leaderboard',
      label: 'Leaderboard',
      icon: Trophy,
      subItems: [
        { key: 'leaderboard_view', label: 'Weekly Leagues', icon: Trophy },
        { key: 'daily_leaderboard', label: 'Daily Leaderboard', icon: Clock },
        { key: 'daily_reset_archives', label: 'Daily Reset & Archives', icon: History },
        { key: 'leaderboard_rules', label: 'Leaderboard Rules', icon: Sliders },
      ],
    },
    {
      key: 'challenges',
      label: 'Challenges',
      icon: Flame,
      subItems: [
        { key: 'active_challenges', label: 'Active Challenges', icon: Flame },
        { key: 'create_challenge', label: 'Create Challenge', icon: PlusCircle },
        { key: 'challenge_history', label: 'Challenge History', icon: History },
      ],
    },
    {
      key: 'achievements',
      label: 'Achievements',
      icon: Award,
      subItems: [
        { key: 'achievement_list', label: 'Achievement List', icon: Award },
        { key: 'create_achievement', label: 'Create Achievement', icon: PlusCircle },
        { key: 'achievement_rules', label: 'Achievement Rules', icon: Sliders },
      ],
    },
    {
      key: 'announcements',
      label: 'Announcements',
      icon: Megaphone,
      subItems: [
        { key: 'create_announcement', label: 'Create Announcement', icon: PlusCircle },
        { key: 'announcement_history', label: 'Announcement History', icon: History },
      ],
    },
    {
      key: 'settings',
      label: 'Settings',
      icon: Settings,
      subItems: [
        { key: 'platform_settings', label: 'Platform Settings', icon: Sliders },
        { key: 'security_settings', label: 'Security', icon: Lock },
        { key: 'system_configuration', label: 'System Configuration', icon: Server },
      ],
    },
  ];

  return (
    <aside
      className={`bg-[#0a0e17] border-r border-slate-800/80 select-none flex flex-col transition-all duration-200 z-20 ${
        collapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Brand / Section Header */}
      <div className="h-14 px-4 flex items-center border-b border-slate-800/80 bg-[#090d15]">
        {!collapsed ? (
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center font-bold text-xs">
              ⚡
            </div>
            <div>
              <span className="font-mono text-xs font-bold text-slate-200 tracking-wider">
                ADMIN NAVIGATION
              </span>
              <span className="text-[10px] text-slate-500 block font-mono">
                RBAC Level: {adminUser?.role}
              </span>
            </div>
          </div>
        ) : (
          <div className="mx-auto w-7 h-7 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs">
            ⚡
          </div>
        )}
      </div>

      {/* Nav List */}
      <div className="flex-1 overflow-y-auto py-3 px-2 space-y-1 text-xs">
        {navGroups.map(group => {
          const Icon = group.icon;
          const isSelected = currentNav.section === group.key;
          const isExpanded = expandedSections[group.key];

          if (group.isLeaf) {
            return (
              <button
                key={group.key}
                onClick={() => onSelectNav({ section: group.key })}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl font-medium transition-all ${
                  isSelected
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                    : 'text-slate-300 hover:text-white hover:bg-slate-850 hover:bg-slate-800/50'
                }`}
                title={group.label}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-slate-950' : 'text-slate-400'}`} />
                {!collapsed && <span>{group.label}</span>}
              </button>
            );
          }

          return (
            <div key={group.key} className="space-y-0.5">
              {/* Group Trigger */}
              <button
                onClick={() => {
                  toggleSection(group.key);
                  if (group.subItems && group.subItems.length > 0) {
                    onSelectNav({
                      section: group.key,
                      subItem: group.subItems[0].key,
                    });
                  }
                }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-medium transition-all ${
                  isSelected && !collapsed
                    ? 'bg-slate-800/80 text-amber-400'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/40'
                }`}
                title={group.label}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-amber-400' : 'text-slate-400'}`} />
                  {!collapsed && <span className="truncate">{group.label}</span>}
                </div>
                {!collapsed && (
                  <span className="text-slate-500">
                    {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                  </span>
                )}
              </button>

              {/* Sub items */}
              {!collapsed && isExpanded && group.subItems && (
                <div className="pl-6 pr-1 space-y-0.5 border-l border-slate-800 ml-4 my-1">
                  {group.subItems.map(sub => {
                    const SubIcon = sub.icon;
                    const isSubSelected =
                      currentNav.section === group.key && currentNav.subItem === sub.key;

                    return (
                      <button
                        key={sub.key}
                        onClick={() =>
                          onSelectNav({
                            section: group.key,
                            subItem: sub.key,
                          })
                        }
                        className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-[11px] transition-all text-left ${
                          isSubSelected
                            ? 'bg-amber-500/15 text-amber-300 font-semibold border border-amber-500/30'
                            : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/30'
                        }`}
                      >
                        <SubIcon className="w-3.5 h-3.5 shrink-0 opacity-70" />
                        <span className="truncate">{sub.label}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer Info */}
      {!collapsed && (
        <div className="p-3 border-t border-slate-800/80 text-[10px] text-slate-500 font-mono">
          <div className="flex items-center justify-between">
            <span>SECURE SESSION</span>
            <span className="text-emerald-400">ENCRYPTED</span>
          </div>
          <div className="truncate mt-0.5">Admin ID: {adminUser?.id}</div>
        </div>
      )}
    </aside>
  );
};
