import React, { useState } from 'react';
import { useAdminAuth } from '../../context/AdminAuthContext';
import { AdminHeader } from './AdminHeader';
import { AdminSidebar, type AdminNavSelection } from './AdminSidebar';
import { InitialPasswordModal } from './modals/InitialPasswordModal';

// Admin Sub-Views
import { AdminDashboardView } from './views/AdminDashboardView';
import { AdminUsersView } from './views/AdminUsersView';
import { AdminAccountsView } from './views/AdminAccountsView';
import { AdminLeaderboardView } from './views/AdminLeaderboardView';
import { AdminChallengesView } from './views/AdminChallengesView';
import { AdminAchievementsView } from './views/AdminAchievementsView';
import { AdminAnnouncementsView } from './views/AdminAnnouncementsView';
import { AdminSettingsView } from './views/AdminSettingsView';

interface AdminPanelProps {
  onNavigateHome: () => void;
  onNavigateLogin: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  onNavigateHome,
  onNavigateLogin,
}) => {
  const { isAuthenticated, loading, isInitialPasswordWarning } = useAdminAuth();

  const [currentNav, setCurrentNav] = useState<AdminNavSelection>({
    section: 'dashboard',
  });
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);

  // If loading authentication state
  if (loading) {
    return (
      <div className="h-screen w-screen bg-[#07090e] flex items-center justify-center text-slate-100">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
          <span className="text-xs text-slate-400 font-mono">Verifying administrative security token...</span>
        </div>
      </div>
    );
  }

  // If not authenticated, prompt redirect
  if (!isAuthenticated) {
    return (
      <div className="h-screen w-screen bg-[#07090e] flex items-center justify-center text-slate-100 p-4">
        <div className="max-w-md w-full p-6 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-4 shadow-2xl">
          <div className="w-12 h-12 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center justify-center mx-auto">
            🛡️
          </div>
          <h2 className="text-lg font-bold text-white">Access Denied &bull; Authentication Required</h2>
          <p className="text-xs text-slate-400">
            The Admin Management Panel is restricted to authorized platform administrators. Please sign in with privileged credentials.
          </p>
          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={onNavigateLogin}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all"
            >
              Go to Administrator Login
            </button>
            <button
              onClick={onNavigateHome}
              className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-colors"
            >
              Return to Student Workspace
            </button>
          </div>
        </div>
      </div>
    );
  }

  const renderActiveSection = () => {
    switch (currentNav.section) {
      case 'dashboard':
        return <AdminDashboardView onNavigate={setCurrentNav} />;
      case 'users':
        return <AdminUsersView initialSubItem={currentNav.subItem} />;
      case 'admin_management':
        return <AdminAccountsView initialSubItem={currentNav.subItem} />;
      case 'leaderboard':
        return <AdminLeaderboardView initialSubItem={currentNav.subItem} />;
      case 'challenges':
        return <AdminChallengesView initialSubItem={currentNav.subItem} />;
      case 'achievements':
        return <AdminAchievementsView initialSubItem={currentNav.subItem} />;
      case 'announcements':
        return <AdminAnnouncementsView initialSubItem={currentNav.subItem} />;
      case 'settings':
        return <AdminSettingsView initialSubItem={currentNav.subItem} />;
      default:
        return <AdminDashboardView onNavigate={setCurrentNav} />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#07090e] text-slate-100 font-sans selection:bg-amber-500/20 selection:text-amber-200">
      {/* Admin Sidebar */}
      <AdminSidebar
        currentNav={currentNav}
        onSelectNav={nav => {
          setCurrentNav(nav);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        collapsed={sidebarCollapsed}
      />

      {/* Main View Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#07090e]">
        {/* Admin Header */}
        <AdminHeader
          onToggleSidebar={() => setSidebarCollapsed(!sidebarCollapsed)}
          onNavigateHome={onNavigateHome}
          onOpenChangePassword={() => setShowPasswordModal(true)}
        />

        {/* Scrollable Viewport */}
        <main className="flex-1 overflow-y-auto pb-12">
          {renderActiveSection()}
        </main>
      </div>

      {/* Mandatory Initial Password Modal (or manually opened) */}
      <InitialPasswordModal
        isOpen={isInitialPasswordWarning || showPasswordModal}
        onClose={() => setShowPasswordModal(false)}
        required={isInitialPasswordWarning}
      />
    </div>
  );
};
