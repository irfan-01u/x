import React, { useState } from 'react';
import {
  Shield,
  ShieldAlert,
  LogOut,
  KeyRound,
  ExternalLink,
  ChevronDown,
  Activity,
  User,
  CheckCircle2,
  AlertTriangle,
  Menu,
} from 'lucide-react';
import { useAdminAuth } from '../../context/AdminAuthContext';
import { BrandLogo } from '../common/BrandLogo';

interface AdminHeaderProps {
  onToggleSidebar?: () => void;
  onNavigateHome: () => void;
  onOpenChangePassword: () => void;
}

export const AdminHeader: React.FC<AdminHeaderProps> = ({
  onToggleSidebar,
  onNavigateHome,
  onOpenChangePassword,
}) => {
  const { adminUser, logout, isInitialPasswordWarning } = useAdminAuth();
  const [profileOpen, setProfileOpen] = useState(false);

  const getRoleBadge = (role?: string) => {
    switch (role) {
      case 'SUPER_ADMIN':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono tracking-wider uppercase bg-gradient-to-r from-purple-500/20 to-amber-500/20 text-amber-300 border border-amber-500/30">
            SUPER ADMIN
          </span>
        );
      case 'ADMIN':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono tracking-wider uppercase bg-amber-500/20 text-amber-400 border border-amber-500/30">
            ADMIN
          </span>
        );
      case 'MODERATOR':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono tracking-wider uppercase bg-sky-500/20 text-sky-400 border border-sky-500/30">
            MODERATOR
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <header className="sticky top-0 z-30 flex flex-col bg-[#0b0f17]/95 border-b border-slate-800/80 backdrop-blur-md text-slate-100 select-none">
      {/* Top Warning Banner if Initial Password is in use */}
      {isInitialPasswordWarning && (
        <div className="bg-amber-500/15 border-b border-amber-500/30 px-4 py-2 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-amber-300 font-medium">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              <strong>Security Notice:</strong> You're using the initial admin password. Change your password for security.
            </span>
          </div>
          <button
            onClick={onOpenChangePassword}
            className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg font-bold text-[11px] uppercase tracking-wider transition-all shadow-sm shadow-amber-500/20 flex items-center gap-1.5"
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>Change Password</span>
          </button>
        </div>
      )}

      {/* Main Header bar */}
      <div className="h-14 px-4 sm:px-6 flex items-center justify-between gap-4">
        {/* Left Section: Mobile toggle & Console Title */}
        <div className="flex items-center gap-3">
          {onToggleSidebar && (
            <button
              onClick={onToggleSidebar}
              className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}

          <div className="flex items-center gap-2.5">
            <BrandLogo inverse className="h-8 w-auto max-w-[110px]" />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold tracking-tight text-sm text-white">
                  NOTIQ CONSOLE
                </span>
                {getRoleBadge(adminUser?.role)}
              </div>
            </div>
          </div>
        </div>

        {/* Center: System Status Indicator */}
        <div className="hidden lg:flex items-center gap-4 text-xs font-mono">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Integrity: Nominal</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-400">
            <Activity className="w-3.5 h-3.5 text-sky-400" />
            <span>Anti-Cheat Strict: Active</span>
          </div>
        </div>

        {/* Right Section: Workspace Switcher & Admin Menu */}
        <div className="flex items-center gap-3">
          {/* Switch to Student View */}
          <button
            onClick={onNavigateHome}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white border border-slate-700/80 hover:border-slate-600 bg-slate-900/60 transition-colors"
          >
            <span>Student Dashboard</span>
            <ExternalLink className="w-3 h-3 text-slate-400" />
          </button>

          {/* Profile Dropdown */}
          <div className="relative">
            <button
              onClick={() => setProfileOpen(!profileOpen)}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl border border-slate-700/70 hover:border-slate-600 bg-slate-900/80 transition-all text-xs"
            >
              <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-300 flex items-center justify-center font-bold text-xs">
                {adminUser?.username?.slice(0, 2).toUpperCase() || 'AD'}
              </div>
              <div className="hidden sm:block text-left">
                <div className="font-semibold text-slate-200 leading-tight">
                  {adminUser?.name || adminUser?.username}
                </div>
                <div className="text-[10px] text-slate-400 font-mono">
                  @{adminUser?.username}
                </div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {profileOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setProfileOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-56 rounded-xl bg-slate-900 border border-slate-800 shadow-xl shadow-black/80 py-1.5 z-50 text-xs animate-fadeIn">
                  <div className="px-3 py-2 border-b border-slate-800/80">
                    <p className="font-semibold text-slate-200">{adminUser?.name}</p>
                    <p className="text-[11px] text-slate-400 truncate">{adminUser?.email}</p>
                    <div className="mt-1.5">{getRoleBadge(adminUser?.role)}</div>
                  </div>

                  <div className="py-1">
                    <button
                      onClick={() => {
                        setProfileOpen(false);
                        onOpenChangePassword();
                      }}
                      className="w-full text-left px-3 py-2 flex items-center gap-2 text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors"
                    >
                      <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                      <span>Change Password</span>
                    </button>

                    <button
                      onClick={() => {
                        setProfileOpen(false);
                        onNavigateHome();
                      }}
                      className="sm:hidden w-full text-left px-3 py-2 flex items-center gap-2 text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-sky-400" />
                      <span>Switch to Student Workspace</span>
                    </button>
                  </div>

                  <div className="pt-1 border-t border-slate-800/80">
                    <button
                      onClick={async () => {
                        setProfileOpen(false);
                        await logout();
                      }}
                      className="w-full text-left px-3 py-2 flex items-center gap-2 text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition-colors"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out from Console</span>
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
