import React, { useState, useEffect } from 'react';
import { StudiumProvider, useStudium } from './context/StudiumContext';
import { AdminAuthProvider, useAdminAuth } from './context/AdminAuthContext';
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { MobileNav } from './components/common/MobileNav';
import { GlobalSearchModal } from './components/common/GlobalSearchModal';
import { QuickActionModal } from './components/common/QuickActionModal';
import { SessionCompletionModal } from './components/common/SessionCompletionModal';
import { FocusModeOverlay } from './components/common/FocusModeOverlay';
import { ActiveStopwatchRecoveryModal } from './components/common/ActiveStopwatchRecoveryModal';
import { MultipleSessionConflictModal } from './components/common/MultipleSessionConflictModal';

// Admin Components
import { AdminLoginView } from './components/admin/AdminLoginView';
import { AdminPanel } from './components/admin/AdminPanel';

// Student Views
import { DashboardView } from './components/views/DashboardView';
import { TimerView } from './components/views/TimerView';
import { PomodoroView } from './components/views/PomodoroView';
import { StopwatchView } from './components/views/StopwatchView';
import { SubjectsView } from './components/views/SubjectsView';
import { ChaptersView } from './components/views/ChaptersView';
import { TasksView } from './components/views/TasksView';
import { NotesView } from './components/views/NotesView';
import { PlannerView } from './components/views/PlannerView';
import { ExamsView } from './components/views/ExamsView';
import { RevisionView } from './components/views/RevisionView';
import { HeatmapView } from './components/views/HeatmapView';
import { AnalyticsView } from './components/views/AnalyticsView';
import { AchievementsView } from './components/views/AchievementsView';
import { LeaderboardView } from './components/views/LeaderboardView';
import { ReportsView } from './components/views/ReportsView';
import { ProfileView } from './components/views/ProfileView';
import { SettingsView } from './components/views/SettingsView';
import { AdminView } from './components/views/AdminView';

interface StudiumAppProps {
  onNavigateRoute: (route: string) => void;
}

const StudiumApp: React.FC<StudiumAppProps> = ({ onNavigateRoute }) => {
  const [activeView, setActiveView] = useState<string>('dashboard');
  const [selectedDetailId, setSelectedDetailId] = useState<string | undefined>();
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const { isAuthenticated, adminUser } = useAdminAuth();

  const handleNavigate = (view: string, detailId?: string) => {
    if (view === 'admin') {
      onNavigateRoute('/admin');
      return;
    }
    setActiveView(view);
    setSelectedDetailId(detailId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderActiveView = () => {
    switch (activeView) {
      case 'dashboard':
        return <DashboardView onNavigate={handleNavigate} />;
      case 'timer':
        return <TimerView />;
      case 'pomodoro':
        return <PomodoroView />;
      case 'stopwatch':
        return <StopwatchView />;
      case 'subjects':
        return <SubjectsView selectedSubjectId={selectedDetailId} onNavigate={handleNavigate} />;
      case 'chapters':
        return <ChaptersView selectedChapterId={selectedDetailId} onNavigate={handleNavigate} />;
      case 'tasks':
        return <TasksView onNavigate={handleNavigate} />;
      case 'notes':
        return <NotesView selectedNoteId={selectedDetailId} />;
      case 'planner':
        return <PlannerView />;
      case 'exams':
        return <ExamsView />;
      case 'revision':
        return <RevisionView onNavigate={handleNavigate} />;
      case 'heatmap':
        return <HeatmapView />;
      case 'analytics':
        return <AnalyticsView />;
      case 'achievements':
        return <AchievementsView />;
      case 'leaderboard':
        return <LeaderboardView />;
      case 'reports':
        return <ReportsView />;
      case 'profile':
        return <ProfileView />;
      case 'settings':
        return <SettingsView />;
      case 'admin':
        return <AdminView onNavigateRoute={onNavigateRoute} />;
      default:
        return <DashboardView onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[var(--bg-base)] text-[var(--text-main)]">
      {/* Sidebar for Desktop / Tablet */}
      <Sidebar
        activeView={activeView}
        onNavigate={handleNavigate}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* If logged in as admin, show persistent top switch indicator */}
        {isAuthenticated && (
          <div className="bg-amber-500/15 border-b border-amber-500/30 px-4 py-1.5 flex items-center justify-between text-xs text-amber-300">
            <span className="font-mono text-[11px]">
              Logged in as Admin (<strong>@{adminUser?.username}</strong> &bull; {adminUser?.role})
            </span>
            <button
              onClick={() => onNavigateRoute('/admin')}
              className="px-2.5 py-0.5 rounded bg-amber-500 text-slate-950 font-bold text-[10px] uppercase tracking-wider hover:bg-amber-400 transition-colors"
            >
              Open Admin Console &rarr;
            </button>
          </div>
        )}

        {/* Top Header */}
        <Header activeView={activeView} onNavigate={handleNavigate} />

        {/* Scrollable Viewport */}
        <main className="flex-1 overflow-y-auto pb-20 md:pb-8">
          {renderActiveView()}
        </main>

        {/* Bottom Nav for Mobile */}
        <MobileNav activeView={activeView} onNavigate={handleNavigate} />
      </div>

      {/* Global Overlays & Modals */}
      <GlobalSearchModal onNavigate={handleNavigate} />
      <QuickActionModal onNavigate={handleNavigate} />
      <SessionCompletionModal />
      <FocusModeOverlay />
      <ActiveStopwatchRecoveryModal />
      <MultipleSessionConflictModal />
    </div>
  );
};

export function App() {
  const [currentPath, setCurrentPath] = useState<string>(() => {
    try {
      return window.location.pathname || '/';
    } catch {
      return '/';
    }
  });

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    try {
      window.history.pushState({}, '', path);
    } catch {}
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <AdminAuthProvider>
      <StudiumProvider>
        {currentPath === '/admin/login' ? (
          <AdminLoginView onNavigate={navigate} />
        ) : currentPath === '/admin' || currentPath.startsWith('/admin/') ? (
          <AdminPanel
            onNavigateHome={() => navigate('/')}
            onNavigateLogin={() => navigate('/admin/login')}
          />
        ) : (
          <StudiumApp onNavigateRoute={navigate} />
        )}
      </StudiumProvider>
    </AdminAuthProvider>
  );
}

export default App;
