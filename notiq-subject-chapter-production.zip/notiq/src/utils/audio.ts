// Web Audio Synthesizer and Ambient Focus Generator

class SoundController {
  private ctx: AudioContext | null = null;
  private ambientNode: AudioNode | null = null;
  private ambientGain: GainNode | null = null;
  private currentAmbientType: string | null = null;

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  // Melodic timer start chime
  playStartChime(volume = 0.5) {
    try {
      const ctx = this.initCtx();
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now); // A4
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.15); // A5

      gain.gain.setValueAtTime(volume * 0.4, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.35);
    } catch {
      // Audio context restricted until user gesture
    }
  }

  // Uplifting timer complete fanfare
  playFinishChime(volume = 0.5) {
    try {
      const ctx = this.initCtx();
      const now = ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6 arpeggio

      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const noteStart = now + idx * 0.12;

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, noteStart);

        gain.gain.setValueAtTime(0.001, noteStart);
        gain.gain.linearRampToValueAtTime(volume * 0.45, noteStart + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + 0.6);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(noteStart);
        osc.stop(noteStart + 0.6);
      });
    } catch {
      // Audio context error
    }
  }

  // Gentle break bell
  playBreakChime(volume = 0.5) {
    try {
      const ctx = this.initCtx();
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.exponentialRampToValueAtTime(440, now + 0.4); // A4

      gain.gain.setValueAtTime(volume * 0.4, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.6);
    } catch {
      // Audio context error
    }
  }

  // Warning countdown tick (final 3 seconds)
  playWarningTick(volume = 0.5) {
    try {
      const ctx = this.initCtx();
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);

      gain.gain.setValueAtTime(volume * 0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.08);
    } catch {
      // Audio context error
    }
  }

  // Achievement unlock triumphant fanfare
  playAchievementFanfare(volume = 0.5) {
    try {
      const ctx = this.initCtx();
      const now = ctx.currentTime;
      const chords = [
        { freqs: [440, 554.37, 659.25], start: 0, dur: 0.2 },
        { freqs: [493.88, 622.25, 739.99], start: 0.2, dur: 0.2 },
        { freqs: [554.37, 659.25, 880], start: 0.4, dur: 0.6 },
      ];

      chords.forEach((chord) => {
        chord.freqs.forEach((freq) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          const start = now + chord.start;

          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, start);

          gain.gain.setValueAtTime(0.001, start);
          gain.gain.linearRampToValueAtTime(volume * 0.2, start + 0.03);
          gain.gain.exponentialRampToValueAtTime(0.001, start + chord.dur);

          osc.connect(gain);
          gain.connect(ctx.destination);

          osc.start(start);
          osc.stop(start + chord.dur);
        });
      });
    } catch {
      // Audio context error
    }
  }

  // Ambient sound generator (Rain, White Noise, Binaural Beats, Deep Drone)
  startAmbient(type: 'rain' | 'whitenoise' | 'binaural' | 'drone', volume = 0.3) {
    try {
      this.stopAmbient();
      const ctx = this.initCtx();
      this.currentAmbientType = type;

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(volume, ctx.currentTime);
      gain.connect(ctx.destination);
      this.ambientGain = gain;

      if (type === 'whitenoise' || type === 'rain') {
        const bufferSize = ctx.sampleRate * 2;
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          data[i] = Math.random() * 2 - 1;
        }

        const noise = ctx.createBufferSource();
        noise.buffer = buffer;
        noise.loop = true;

        if (type === 'rain') {
          // Lowpass filter for soothing rain sound
          const filter = ctx.createBiquadFilter();
          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(1000, ctx.currentTime);
          noise.connect(filter);
          filter.connect(gain);
        } else {
          noise.connect(gain);
        }

        noise.start();
        this.ambientNode = noise;
      } else if (type === 'binaural') {
        // Binaural 40Hz Gamma/Alpha state
        const merger = ctx.createChannelMerger(2);
        const oscL = ctx.createOscillator();
        const oscR = ctx.createOscillator();

        oscL.type = 'sine';
        oscR.type = 'sine';
        oscL.frequency.setValueAtTime(200, ctx.currentTime);
        oscR.frequency.setValueAtTime(240, ctx.currentTime); // 40Hz delta

        oscL.connect(merger, 0, 0);
        oscR.connect(merger, 0, 1);
        merger.connect(gain);

        oscL.start();
        oscR.start();
        this.ambientNode = merger;
      } else if (type === 'drone') {
        // Warm resonant drone
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        osc1.type = 'sawtooth';
        osc2.type = 'sine';
        osc1.frequency.setValueAtTime(110, ctx.currentTime);
        osc2.frequency.setValueAtTime(110.5, ctx.currentTime);

        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(220, ctx.currentTime);

        osc1.connect(filter);
        osc2.connect(filter);
        filter.connect(gain);

        osc1.start();
        osc2.start();
        this.ambientNode = filter;
      }
    } catch {
      // Audio error
    }
  }

  setAmbientVolume(volume: number) {
    if (this.ambientGain && this.ctx) {
      this.ambientGain.gain.setValueAtTime(Math.max(0, Math.min(1, volume)), this.ctx.currentTime);
    }
  }

  stopAmbient() {
    try {
      if (this.ambientNode) {
        if ('stop' in this.ambientNode && typeof (this.ambientNode as AudioScheduledSourceNode).stop === 'function') {
          (this.ambientNode as AudioScheduledSourceNode).stop();
        }
        this.ambientNode.disconnect();
        this.ambientNode = null;
      }
      if (this.ambientGain) {
        this.ambientGain.disconnect();
        this.ambientGain = null;
      }
      this.currentAmbientType = null;
    } catch {
      // Audio error
    }
  }

  getCurrentAmbient() {
    return this.currentAmbientType;
  }
}

export const soundFx = new SoundController();
