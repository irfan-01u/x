export type TimerMode = 'countdown' | 'countup' | 'deepwork' | 'pomodoro' | 'stopwatch';

export type StudyType =
  | 'Learning'
  | 'Revision'
  | 'Problem Solving'
  | 'Practice'
  | 'Reading'
  | 'Lecture'
  | 'Mock Test'
  | 'Assignment';

export type Difficulty = 'Easy' | 'Medium' | 'Hard' | 'Extreme';

export type Priority = 'Low' | 'Medium' | 'High' | 'Critical';

export type SubjectStatus = 'Active' | 'Paused' | 'Completed' | 'Archived';

export type ChapterStatus = 'Not Started' | 'Started' | 'In Progress' | 'Revision' | 'Completed';

export type TopicStatus = 'Not Started' | 'In Progress' | 'Completed';

export type LeagueTier = 'Bronze' | 'Silver' | 'Gold' | 'Platinum' | 'Diamond';

export interface StudySession {
  id: string;
  startTime: string; // ISO string
  endTime: string;   // ISO string
  duration: number;  // in seconds
  subjectId: string;
  chapterId?: string;
  topicId?: string;
  studyType: StudyType;
  difficulty: Difficulty;
  taskTitle?: string;
  note?: string;
  tags: string[];
  timerMode: TimerMode;
  completedNormally: boolean;
  interrupted: boolean;
  dateString: string; // YYYY-MM-DD
  deviceId: string;
}

export interface Subject {
  id: string;
  userId?: string;
  name: string;
  icon: string;
  accentColor: string;
  description: string;
  targetHours: number;
  priority: Priority;
  status: SubjectStatus;
  createdAt: string;
  order: number;
}

export interface ChapterChecklistItem {
  id: string;
  title: string;
  completed: boolean;
}

export interface Topic {
  id: string;
  chapterId: string;
  subjectId: string;
  userId?: string;
  name: string;
  description?: string;
  status: TopicStatus;
  completed: boolean;
  completedAt?: string;
  createdAt: string;
  updatedAt: string;
  order: number;
}

export interface Chapter {
  id: string;
  userId?: string;
  subjectId: string;
  name: string;
  description: string;
  priority: Priority;
  targetHours: number;
  deadline?: string;
  notes?: string;
  status: ChapterStatus;
  customProgress: number; // 0-100
  checklist: ChapterChecklistItem[];
  order: number;
  revisionCount: number;
  lastRevisionDate?: string;
  nextRevisionDate?: string;
  revisionRequired: boolean;
  completionDate?: string;
}

export interface Task {
  id: string;
  title: string;
  subjectId?: string;
  chapterId?: string;
  topicId?: string;
  priority: 'Low' | 'Medium' | 'High';
  deadline?: string;
  estimatedMinutes: number;
  scheduledDate?: string; // YYYY-MM-DD
  completed: boolean;
  completedAt?: string;
  order: number;
}

export interface NoteImage {
  id: string;
  noteId?: string;
  userId?: string;
  url: string;
  storagePath?: string;
  fileName: string;
  mimeType: string;
  fileSize: number;
  caption?: string;
  order: number;
  createdAt: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  subjectId?: string;
  chapterId?: string;
  topicId?: string;
  images?: NoteImage[];
  tags: string[];
  folder: string;
  isPinned: boolean;
  isFavorite: boolean;
  isArchived: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DailyGoalItem {
  id: string;
  title: string;
  completed: boolean;
}

export interface DailyGoal {
  dateString: string; // YYYY-MM-DD
  targetMinutes: number;
  targetPomodoros: number;
  targetSessions: number;
  targetChapters: number;
  targetTasks: number;
  tasks: DailyGoalItem[];
}

export interface StreakData {
  currentStreak: number;
  longestStreak: number;
  lastStudyDate: string; // YYYY-MM-DD
  streakRequirementMinutes: number;
  streakFreezesLeft: number;
  graceDayActive: boolean;
  streakHistory: Array<{ date: string; minutes: number; achieved: boolean }>;
}

export type AchievementCategory = 'TIME' | 'STREAK' | 'POMODORO' | 'CONSISTENCY' | 'SUBJECT' | 'SPECIAL';

export interface Achievement {
  id: string;
  title: string;
  description: string;
  category: AchievementCategory;
  targetValue: number;
  unit: string;
  unlocked: boolean;
  unlockedAt?: string;
  icon: string;
}

export interface Exam {
  id: string;
  name: string;
  subjectId: string;
  examDate: string; // YYYY-MM-DD
  examTime: string; // HH:mm
  location?: string;
  notes?: string;
  priority: 'Low' | 'Medium' | 'High';
}

export interface StudyBlock {
  id: string;
  title: string;
  subjectId: string;
  dayOfWeek: number; // 0 (Sun) to 6 (Sat)
  startTime: string; // HH:mm
  endTime: string;   // HH:mm
  status: 'Planned' | 'Completed' | 'Skipped' | 'Rescheduled';
  dateString?: string;
}

export interface UserProfile {
  id: string;
  accountType?: 'guest' | 'registered';
  deviceId?: string;
  name: string;
  username: string;
  avatar: string;
  bio: string;
  dailyGoalMinutes: number;
  preferredSubjects: string[];
  examDate?: string;
  studyTarget: string;
  level: number;
  xp: number;
  pinnedAchievementIds: string[];
  privacy: {
    isPublic: boolean;
    showOnLeaderboard: boolean;
    showAvatar: boolean;
    showRealName: boolean;
    discoverable: boolean;
  };
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'Study' | 'Achievement' | 'Leaderboard' | 'Social' | 'System';
  timestamp: string;
  read: boolean;
  actionUrl?: string;
}

export interface LeaderboardUser {
  rank: number;
  userId: string;
  name: string;
  username: string;
  avatar: string;
  studyMinutes: number;
  streak: number;
  xp: number;
  tier: LeagueTier;
  isCurrentUser?: boolean;
  change: number; // +2, -1, 0
  institution?: string;
  country?: string;
}

export interface AppSettings {
  theme: 'dark' | 'cyber' | 'light' | 'system';
  accent: 'mint' | 'violet' | 'blue' | 'amber';
  soundEnabled: boolean;
  masterVolume: number; // 0 to 1
  autoStartBreak: boolean;
  autoStartFocus: boolean;
  autoPlayMusic: boolean;
  longBreakInterval: number;
  defaultPomodoroFocus: number; // minutes
  defaultPomodoroShortBreak: number;
  defaultPomodoroLongBreak: number;
  defaultTimerPreset: number; // minutes
  streakRequirementMinutes: number;
  quietHoursEnabled: boolean;
  quietHoursStart: string; // "22:00"
  quietHoursEnd: string;   // "07:00"
  reducedMotion: boolean;
  highContrast: boolean;
  fontSize: 'sm' | 'md' | 'lg';
  dashboardLayout: 'minimal' | 'standard' | 'detailed';
  enabledWidgets: Record<string, boolean>;
}

export interface SyncStatus {
  status: 'Connected' | 'Syncing' | 'Offline' | 'Error';
  lastSyncedAt: string;
  pendingChangesCount: number;
  errorMessage?: string;
}

export interface ActiveStopwatchServerSession {
  userId: string;
  sessionId: string;
  startTime: number;
  lastResumeTime: number;
  status: 'running' | 'paused' | 'completed' | 'cancelled';
  subjectId: string;
  chapterId?: string;
  sessionType: string;
  taskTitle?: string;
  note?: string;
  tags: string[];
  accumulatedSeconds: number;
  pausedAt?: number;
  createdAt: string;
  lastUpdatedAt: string;
  laps: Array<{ lapNumber: number; lapTime: number; totalTime: number }>;
  elapsedSeconds?: number;
}

export interface DailyLeaderboardData {
  todayKey: string;
  timezone: string;
  secondsUntilReset: number;
  totalStudyMinutes: number;
  participantsCount: number;
  rankings: Array<{
    rank: number;
    userId: string;
    name: string;
    username: string;
    avatar: string;
    studyMinutes: number;
    streak: number;
    xp: number;
    tier: string;
    institution?: string;
    country?: string;
    isCurrentUser?: boolean;
    change?: number;
    studyScore?: number;
  }>;
  currentUser?: {
    rank: number;
    userId: string;
    name: string;
    username: string;
    avatar: string;
    studyMinutes: number;
    studyScore: number;
    xp: number;
    streak: number;
    tier: string;
    rankMovement: number;
    nextRankGapMinutes: number;
  } | null;
  nextRankGapMinutes?: number;
  rules?: { maxDailyHoursCap: number; dailyResetTimezone: string; xpToPointsRatio: number };
  friends?: any[];
  groups?: any[];
  yesterdaySnapshot: {
    dateKey: string;
    timezone: string;
    closedAt: string;
    totalStudyMinutes: number;
    participantsCount: number;
    top3: Array<{
      rank: number;
      name: string;
      username: string;
      avatar: string;
      studyMinutes: number;
      tier: string;
    }>;
    rankings: any[];
  } | null;
}

