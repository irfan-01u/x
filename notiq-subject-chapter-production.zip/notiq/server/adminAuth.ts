import crypto from 'crypto';
import type { Request, Response, NextFunction } from 'express';
import { adminStore, verifyPassword, hashPassword, type AdminRole, type AdminUser } from './adminStore';

export interface AdminSession {
  token: string;
  adminId: string;
  username: string;
  name: string;
  role: AdminRole;
  isInitialPassword: boolean;
  createdAt: number;
  expiresAt: number;
}

// In-memory active sessions map: token -> AdminSession
const activeSessions = new Map<string, AdminSession>();

// Failed login attempt tracking: key -> { count: number, lockoutUntil?: number }
const loginAttempts = new Map<string, { count: number; lockoutUntil?: number }>();

const SESSION_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours
const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000; // 15 minutes

export function createSession(admin: AdminUser): AdminSession {
  const token = crypto.randomBytes(32).toString('hex');
  const now = Date.now();
  const session: AdminSession = {
    token,
    adminId: admin.id,
    username: admin.username,
    name: admin.name,
    role: admin.role,
    isInitialPassword: admin.isInitialPassword,
    createdAt: now,
    expiresAt: now + SESSION_TTL_MS,
  };
  activeSessions.set(token, session);
  return session;
}

export function getSession(token: string): AdminSession | null {
  const session = activeSessions.get(token);
  if (!session) return null;
  if (Date.now() > session.expiresAt) {
    activeSessions.delete(token);
    return null;
  }
  return session;
}

export function revokeSession(token: string): boolean {
  return activeSessions.delete(token);
}

export function revokeAllSessionsForAdmin(adminId: string) {
  for (const [token, session] of activeSessions.entries()) {
    if (session.adminId === adminId) {
      activeSessions.delete(token);
    }
  }
}

export function checkRateLimit(key: string): { allowed: boolean; retryAfterSeconds?: number } {
  const record = loginAttempts.get(key);
  if (!record) return { allowed: true };

  const now = Date.now();
  if (record.lockoutUntil && now < record.lockoutUntil) {
    const retryAfter = Math.ceil((record.lockoutUntil - now) / 1000);
    return { allowed: false, retryAfterSeconds: retryAfter };
  }

  if (record.lockoutUntil && now >= record.lockoutUntil) {
    loginAttempts.delete(key);
    return { allowed: true };
  }

  return { allowed: true };
}

export function recordFailedAttempt(key: string): { locked: boolean; remainingAttempts: number } {
  const record = loginAttempts.get(key) || { count: 0 };
  record.count += 1;

  if (record.count >= MAX_ATTEMPTS) {
    record.lockoutUntil = Date.now() + LOCKOUT_MS;
    loginAttempts.set(key, record);
    return { locked: true, remainingAttempts: 0 };
  }

  loginAttempts.set(key, record);
  return { locked: false, remainingAttempts: MAX_ATTEMPTS - record.count };
}

export function clearFailedAttempts(key: string) {
  loginAttempts.delete(key);
}

// Helper to extract session token from header or cookie
export function extractToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7).trim();
  }

  const cookieHeader = req.headers.cookie;
  if (cookieHeader) {
    const cookies = cookieHeader.split(';').map(c => c.trim());
    for (const c of cookies) {
      if (c.startsWith('studiq_admin_session=')) {
        return decodeURIComponent(c.substring('studiq_admin_session='.length));
      }
    }
  }
  return null;
}

// Extend Request interface to include admin session
export interface AuthenticatedAdminRequest extends Request {
  admin?: AdminSession;
  adminUser?: AdminUser;
}

// Middleware: Require Admin Authentication & RBAC
export function requireAdminAuth(allowedRoles?: AdminRole[]) {
  return (req: AuthenticatedAdminRequest, res: Response, next: NextFunction) => {
    const token = extractToken(req);
    if (!token) {
      res.status(401).json({
        error: 'Authentication required. Please sign in to the Admin Console.',
        code: 'AUTH_REQUIRED',
      });
      return;
    }

    const session = getSession(token);
    if (!session) {
      res.status(401).json({
        error: 'Session has expired or is invalid. Please sign in again.',
        code: 'SESSION_EXPIRED',
      });
      return;
    }

    const user = adminStore.findAdminById(session.adminId);
    if (!user || user.status === 'DISABLED') {
      res.status(403).json({
        error: 'Administrator account has been disabled or removed.',
        code: 'ACCOUNT_DISABLED',
      });
      return;
    }

    // Role-based permission check
    if (allowedRoles && allowedRoles.length > 0) {
      if (!allowedRoles.includes(user.role)) {
        res.status(403).json({
          error: `Access denied. This action requires one of the following roles: ${allowedRoles.join(', ')}. Your role is ${user.role}.`,
          code: 'INSUFFICIENT_PERMISSIONS',
        });
        return;
      }
    }

    // Update session isInitialPassword in case it was changed
    session.isInitialPassword = user.isInitialPassword;
    session.role = user.role;

    req.admin = session;
    req.adminUser = user;
    next();
  };
}

// Password strength validator
export function validatePasswordStrength(password: string): { valid: boolean; reason?: string } {
  if (password.length < 8) {
    return { valid: false, reason: 'Password must be at least 8 characters long.' };
  }
  if (!/[A-Z]/.test(password)) {
    return { valid: false, reason: 'Password must contain at least one uppercase letter.' };
  }
  if (!/[a-z]/.test(password)) {
    return { valid: false, reason: 'Password must contain at least one lowercase letter.' };
  }
  if (!/[0-9]/.test(password)) {
    return { valid: false, reason: 'Password must contain at least one number.' };
  }
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    return { valid: false, reason: 'Password must contain at least one special character.' };
  }
  return { valid: true };
}
