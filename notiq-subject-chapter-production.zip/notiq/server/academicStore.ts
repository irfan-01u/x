import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Subject, Chapter, Topic, Note, NoteImage } from '../src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../data');
const UPLOADS_DIR = path.resolve(DATA_DIR, 'uploads');
const ACADEMIC_STATE_FILE = path.resolve(DATA_DIR, 'academic_state.json');
const DEMO_SUBJECT_IDS = new Set(['subj-1','subj-2','subj-3','subj-4','subj-5']);
const DEMO_CHAPTER_IDS = new Set(['chap-1-1','chap-1-2','chap-1-3','chap-2-1','chap-2-2','chap-3-1','chap-3-2','chap-4-1']);
const DEMO_TOPIC_IDS = new Set(['top-1-1-1','top-1-1-2','top-1-1-3','top-1-1-4','top-1-1-5','top-1-2-1','top-1-2-2','top-1-2-3','top-1-2-4','top-1-3-1','top-1-3-2','top-1-3-3','top-2-1-1','top-2-1-2','top-2-1-3','top-2-1-4','top-3-1-1','top-3-1-2','top-3-1-3','top-4-1-1','top-4-1-2','top-4-1-3']);
const DEMO_NOTE_IDS = new Set(['note-1','note-2','note-3']);


// Ensure directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

export interface AcademicState {
  subjects: Subject[];
  chapters: Chapter[];
  topics: Topic[];
  notes: Note[];
}

export class AcademicStore {
  private state: AcademicState;

  constructor() {
    this.state = this.loadState();
  }

  private loadState(): AcademicState {
    if (fs.existsSync(ACADEMIC_STATE_FILE)) {
      try {
        const raw = fs.readFileSync(ACADEMIC_STATE_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        const subjects = (Array.isArray(parsed.subjects) ? parsed.subjects : []).filter((s: Subject) => !DEMO_SUBJECT_IDS.has(s.id));
        const chapters = (Array.isArray(parsed.chapters) ? parsed.chapters : []).filter((c: Chapter) => !DEMO_CHAPTER_IDS.has(c.id) && !DEMO_SUBJECT_IDS.has(c.subjectId));
        const topics = (Array.isArray(parsed.topics) ? parsed.topics : []).filter((t: Topic) => !DEMO_TOPIC_IDS.has(t.id) && !DEMO_SUBJECT_IDS.has(t.subjectId) && !DEMO_CHAPTER_IDS.has(t.chapterId));
        const notes = (Array.isArray(parsed.notes) ? parsed.notes : []).filter((n: Note) => !DEMO_NOTE_IDS.has(n.id) && !DEMO_SUBJECT_IDS.has(n.subjectId) && (!n.chapterId || !DEMO_CHAPTER_IDS.has(n.chapterId)));
        const cleanState = { subjects, chapters, topics, notes };
        this.saveState(cleanState);
        return cleanState;
      } catch (err) {
        console.error('Failed reading academic_state.json, falling back to seed:', err);
      }
    }

    const defaultState: AcademicState = {
      subjects: [],
      chapters: [],
      topics: [],
      notes: [],
    };
    this.saveState(defaultState);
    return defaultState;
  }

  private saveState(stateToSave?: AcademicState): void {
    const s = stateToSave || this.state;
    try {
      fs.writeFileSync(ACADEMIC_STATE_FILE, JSON.stringify(s, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed saving academic_state.json:', err);
    }
  }

  public getAcademicTree(_userId = ''): AcademicState {
    return {
      subjects: this.state.subjects,
      chapters: this.state.chapters,
      topics: this.state.topics,
      notes: this.state.notes,
    };
  }

  // --- Subject Operations ---
  public getSubjects(): Subject[] {
    return this.state.subjects;
  }

  public addSubject(data: Omit<Subject, 'id' | 'createdAt' | 'order'>): Subject {
    const newSubject: Subject = {
      ...data,
      id: `subj-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      createdAt: new Date().toISOString(),
      order: this.state.subjects.length,
    };
    this.state.subjects.push(newSubject);
    this.saveState();
    return newSubject;
  }

  public updateSubject(id: string, updates: Partial<Subject>): Subject | null {
    const idx = this.state.subjects.findIndex(s => s.id === id);
    if (idx === -1) return null;
    this.state.subjects[idx] = { ...this.state.subjects[idx], ...updates };
    this.saveState();
    return this.state.subjects[idx];
  }

  public deleteSubject(id: string): boolean {
    const initialLen = this.state.subjects.length;
    this.state.subjects = this.state.subjects.filter(s => s.id !== id);
    if (this.state.subjects.length === initialLen) return false;

    // Cascade delete chapters, topics, notes
    const chapsToDelete = this.state.chapters.filter(c => c.subjectId === id).map(c => c.id);
    this.state.chapters = this.state.chapters.filter(c => c.subjectId !== id);
    this.state.topics = this.state.topics.filter(t => t.subjectId !== id && !chapsToDelete.includes(t.chapterId));
    this.state.notes = this.state.notes.filter(n => n.subjectId !== id);

    this.saveState();
    return true;
  }

  // --- Chapter Operations ---
  public getChapters(subjectId?: string): Chapter[] {
    if (subjectId) {
      return this.state.chapters.filter(c => c.subjectId === subjectId);
    }
    return this.state.chapters;
  }

  public addChapter(data: Omit<Chapter, 'id'>): Chapter {
    const newChapter: Chapter = {
      ...data,
      id: `chap-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      order: this.state.chapters.filter(c => c.subjectId === data.subjectId).length,
    };
    this.state.chapters.push(newChapter);
    this.saveState();
    return newChapter;
  }

  public updateChapter(id: string, updates: Partial<Chapter>): Chapter | null {
    const idx = this.state.chapters.findIndex(c => c.id === id);
    if (idx === -1) return null;
    this.state.chapters[idx] = { ...this.state.chapters[idx], ...updates };
    this.saveState();
    return this.state.chapters[idx];
  }

  public markChapterCompleted(id: string, completed = true): Chapter | null {
    const idx = this.state.chapters.findIndex(c => c.id === id);
    if (idx === -1) return null;
    const now = new Date().toISOString();
    const ch = this.state.chapters[idx];

    this.state.chapters[idx] = {
      ...ch,
      status: completed ? 'Completed' : 'In Progress',
      customProgress: completed ? 100 : ch.customProgress,
      completionDate: completed ? now : undefined,
    };

    // If marked completed, mark all topics completed
    if (completed) {
      this.state.topics = this.state.topics.map(t => {
        if (t.chapterId === id) {
          return {
            ...t,
            status: 'Completed',
            completed: true,
            completedAt: t.completedAt || now,
            updatedAt: now,
          };
        }
        return t;
      });
    }

    this.saveState();
    return this.state.chapters[idx];
  }

  public deleteChapter(id: string): boolean {
    const initialLen = this.state.chapters.length;
    this.state.chapters = this.state.chapters.filter(c => c.id !== id);
    if (this.state.chapters.length === initialLen) return false;

    // Cascade delete topics and notes associated with this chapter
    this.state.topics = this.state.topics.filter(t => t.chapterId !== id);
    this.state.notes = this.state.notes.filter(n => n.chapterId !== id);

    this.saveState();
    return true;
  }

  // --- Topic Operations ---
  public getTopics(chapterId?: string): Topic[] {
    if (chapterId) {
      return this.state.topics.filter(t => t.chapterId === chapterId);
    }
    return this.state.topics;
  }

  public addTopic(data: Omit<Topic, 'id' | 'createdAt' | 'updatedAt' | 'order'>): Topic {
    const now = new Date().toISOString();
    const newTopic: Topic = {
      ...data,
      id: `top-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      createdAt: now,
      updatedAt: now,
      order: this.state.topics.filter(t => t.chapterId === data.chapterId).length,
    };
    this.state.topics.push(newTopic);

    // Recompute parent chapter progress
    this.recalculateChapterProgress(data.chapterId);
    this.saveState();
    return newTopic;
  }

  public updateTopic(id: string, updates: Partial<Topic>): Topic | null {
    const idx = this.state.topics.findIndex(t => t.id === id);
    if (idx === -1) return null;
    const now = new Date().toISOString();
    this.state.topics[idx] = {
      ...this.state.topics[idx],
      ...updates,
      updatedAt: now,
    };

    if (updates.status !== undefined || updates.completed !== undefined) {
      this.recalculateChapterProgress(this.state.topics[idx].chapterId);
    }

    this.saveState();
    return this.state.topics[idx];
  }

  public toggleTopic(id: string): { topic: Topic; chapter: Chapter | null } | null {
    const idx = this.state.topics.findIndex(t => t.id === id);
    if (idx === -1) return null;

    const topic = this.state.topics[idx];
    const newCompleted = !topic.completed;
    const now = new Date().toISOString();

    this.state.topics[idx] = {
      ...topic,
      completed: newCompleted,
      status: newCompleted ? 'Completed' : 'In Progress',
      completedAt: newCompleted ? now : undefined,
      updatedAt: now,
    };

    const chapter = this.recalculateChapterProgress(topic.chapterId);
    this.saveState();

    return { topic: this.state.topics[idx], chapter };
  }

  public deleteTopic(id: string): boolean {
    const topic = this.state.topics.find(t => t.id === id);
    if (!topic) return false;

    this.state.topics = this.state.topics.filter(t => t.id !== id);
    // Delete topic-specific notes
    this.state.notes = this.state.notes.filter(n => n.topicId !== id);

    this.recalculateChapterProgress(topic.chapterId);
    this.saveState();
    return true;
  }

  private recalculateChapterProgress(chapterId: string): Chapter | null {
    const chIdx = this.state.chapters.findIndex(c => c.id === chapterId);
    if (chIdx === -1) return null;

    const chapterTopics = this.state.topics.filter(t => t.chapterId === chapterId);
    const chapter = this.state.chapters[chIdx];

    if (chapterTopics.length === 0) {
      return chapter;
    }

    const completedCount = chapterTopics.filter(t => t.completed).length;
    const progressPct = Math.round((completedCount / chapterTopics.length) * 100);

    const now = new Date().toISOString();
    let newStatus = chapter.status;

    if (completedCount === chapterTopics.length && chapterTopics.length > 0) {
      newStatus = 'Completed';
    } else if (completedCount > 0) {
      newStatus = 'In Progress';
    } else if (chapter.status === 'Completed') {
      newStatus = 'In Progress';
    }

    this.state.chapters[chIdx] = {
      ...chapter,
      customProgress: progressPct,
      status: newStatus,
      completionDate: newStatus === 'Completed' ? (chapter.completionDate || now) : undefined,
    };

    return this.state.chapters[chIdx];
  }

  // --- Note Operations ---
  public getNotes(filters?: { subjectId?: string; chapterId?: string; topicId?: string }): Note[] {
    let result = this.state.notes;
    if (filters?.subjectId) {
      result = result.filter(n => n.subjectId === filters.subjectId);
    }
    if (filters?.chapterId) {
      result = result.filter(n => n.chapterId === filters.chapterId);
    }
    if (filters?.topicId) {
      result = result.filter(n => n.topicId === filters.topicId);
    }
    return result;
  }

  public saveNote(data: Partial<Note> & { subjectId?: string; chapterId?: string; topicId?: string }): Note {
    const now = new Date().toISOString();

    if (data.id) {
      const idx = this.state.notes.findIndex(n => n.id === data.id);
      if (idx !== -1) {
        this.state.notes[idx] = {
          ...this.state.notes[idx],
          ...data,
          updatedAt: now,
        };
        this.saveState();
        return this.state.notes[idx];
      }
    }

    // Look for existing note for this chapter / topic if not specified
    if (data.topicId) {
      const existing = this.state.notes.find(n => n.topicId === data.topicId);
      if (existing) {
        return this.saveNote({ ...existing, ...data });
      }
    } else if (data.chapterId && !data.topicId) {
      const existing = this.state.notes.find(n => n.chapterId === data.chapterId && !n.topicId);
      if (existing) {
        return this.saveNote({ ...existing, ...data });
      }
    }

    const newNote: Note = {
      id: data.id || `note-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      title: data.title || 'Untitled Note',
      content: data.content || '',
      subjectId: data.subjectId,
      chapterId: data.chapterId,
      topicId: data.topicId,
      images: data.images || [],
      tags: data.tags || ['#notes'],
      folder: data.folder || 'General Notes',
      isPinned: !!data.isPinned,
      isFavorite: !!data.isFavorite,
      isArchived: !!data.isArchived,
      createdAt: now,
      updatedAt: now,
    };

    this.state.notes.unshift(newNote);
    this.saveState();
    return newNote;
  }

  public deleteNote(id: string): boolean {
    const initialLen = this.state.notes.length;
    const note = this.state.notes.find(n => n.id === id);

    // Delete associated images from disk
    if (note?.images) {
      for (const img of note.images) {
        if (img.storagePath && fs.existsSync(img.storagePath)) {
          try {
            fs.unlinkSync(img.storagePath);
          } catch {}
        }
      }
    }

    this.state.notes = this.state.notes.filter(n => n.id !== id);
    if (this.state.notes.length === initialLen) return false;

    this.saveState();
    return true;
  }

  // --- Note Image Operations ---
  public addNoteImage(noteId: string, image: NoteImage): Note | null {
    const idx = this.state.notes.findIndex(n => n.id === noteId);
    if (idx === -1) return null;

    const note = this.state.notes[idx];
    const currentImages = note.images || [];
    const updatedImages = [...currentImages, { ...image, order: currentImages.length }];

    this.state.notes[idx] = {
      ...note,
      images: updatedImages,
      updatedAt: new Date().toISOString(),
    };

    this.saveState();
    return this.state.notes[idx];
  }

  public deleteNoteImage(noteId: string, imageId: string): Note | null {
    const idx = this.state.notes.findIndex(n => n.id === noteId);
    if (idx === -1) return null;

    const note = this.state.notes[idx];
    const imageToDelete = (note.images || []).find(img => img.id === imageId);

    // Delete physical file from disk if local path exists
    if (imageToDelete?.storagePath && fs.existsSync(imageToDelete.storagePath)) {
      try {
        fs.unlinkSync(imageToDelete.storagePath);
      } catch (err) {
        console.warn('Failed unlinking image file:', err);
      }
    }

    const updatedImages = (note.images || [])
      .filter(img => img.id !== imageId)
      .map((img, i) => ({ ...img, order: i }));

    this.state.notes[idx] = {
      ...note,
      images: updatedImages,
      updatedAt: new Date().toISOString(),
    };

    this.saveState();
    return this.state.notes[idx];
  }

  public updateNoteImageCaption(noteId: string, imageId: string, caption: string): Note | null {
    const idx = this.state.notes.findIndex(n => n.id === noteId);
    if (idx === -1) return null;

    const note = this.state.notes[idx];
    const updatedImages = (note.images || []).map(img => {
      if (img.id === imageId) {
        return { ...img, caption };
      }
      return img;
    });

    this.state.notes[idx] = {
      ...note,
      images: updatedImages,
      updatedAt: new Date().toISOString(),
    };

    this.saveState();
    return this.state.notes[idx];
  }

  public reorderNoteImages(noteId: string, imageIds: string[]): Note | null {
    const idx = this.state.notes.findIndex(n => n.id === noteId);
    if (idx === -1) return null;

    const note = this.state.notes[idx];
    const currentImages = note.images || [];

    const reordered: NoteImage[] = [];
    imageIds.forEach((id, orderIndex) => {
      const found = currentImages.find(img => img.id === id);
      if (found) {
        reordered.push({ ...found, order: orderIndex });
      }
    });

    // Append any images that weren't in the provided list
    currentImages.forEach(img => {
      if (!imageIds.includes(img.id)) {
        reordered.push({ ...img, order: reordered.length });
      }
    });

    this.state.notes[idx] = {
      ...note,
      images: reordered,
      updatedAt: new Date().toISOString(),
    };

    this.saveState();
    return this.state.notes[idx];
  }
}

export const academicStore = new AcademicStore();
