import { Router, Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { academicStore } from './academicStore';
import { NoteImage } from '../src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../data');
const UPLOADS_DIR = path.resolve(DATA_DIR, 'uploads');

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Multer storage engine
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const sanitizedBase = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '_');
    const uniqueSuffix = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    cb(null, `${sanitizedBase}_${uniqueSuffix}${ext}`);
  },
});

// Multer upload middleware with strict file validation
const upload = multer({
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (_req, file, cb) => {
    const allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
    if (allowedMimeTypes.includes(file.mimetype.toLowerCase())) {
      cb(null, true);
    } else {
      cb(new Error('Invalid image format. Supported formats: JPG, JPEG, PNG, WEBP.'));
    }
  },
});

export const academicRouter = Router();

// GET /api/academic/tree - Fetch all subjects, chapters, topics, notes
academicRouter.get('/tree', (req: Request, res: Response) => {
  const userId = (req.query.userId as string) || '';
  const tree = academicStore.getAcademicTree(userId);
  res.json(tree);
});

// --- Subject Endpoints ---
academicRouter.get('/subjects', (_req: Request, res: Response) => {
  res.json(academicStore.getSubjects());
});

academicRouter.post('/subjects', (req: Request, res: Response) => {
  const { name, description, icon, accentColor, targetHours, priority, status } = req.body;
  if (!name || typeof name !== 'string' || !name.trim()) {
    return res.status(400).json({ error: 'Subject name is required.' });
  }

  const subject = academicStore.addSubject({
    name: name.trim(),
    description: description || '',
    icon: icon || 'BookOpen',
    accentColor: accentColor || '#38bdf8',
    targetHours: Number(targetHours) || 40,
    priority: priority || 'High',
    status: status || 'Active',
  });

  res.status(201).json(subject);
});

academicRouter.put('/subjects/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const updated = academicStore.updateSubject(id, req.body);
  if (!updated) {
    return res.status(404).json({ error: 'Subject not found.' });
  }
  res.json(updated);
});

academicRouter.delete('/subjects/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const deleted = academicStore.deleteSubject(id);
  if (!deleted) {
    return res.status(404).json({ error: 'Subject not found.' });
  }
  res.json({ success: true, id });
});

// --- Chapter Endpoints ---
academicRouter.get('/chapters', (req: Request, res: Response) => {
  const subjectId = req.query.subjectId as string | undefined;
  res.json(academicStore.getChapters(subjectId));
});

academicRouter.post('/chapters', (req: Request, res: Response) => {
  const { subjectId, name, description, priority, targetHours, deadline, status, notes } = req.body;
  if (!subjectId || !name || typeof name !== 'string' || !name.trim()) {
    return res.status(400).json({ error: 'Subject ID and Chapter name are required.' });
  }

  const chapter = academicStore.addChapter({
    subjectId,
    name: name.trim(),
    description: description || '',
    priority: priority || 'High',
    targetHours: Number(targetHours) || 10,
    deadline: deadline || undefined,
    status: status || 'Not Started',
    notes: notes || undefined,
    customProgress: status === 'Completed' ? 100 : 0,
    checklist: [],
    revisionCount: 0,
    revisionRequired: false,
    order: 0,
  });

  res.status(201).json(chapter);
});

academicRouter.put('/chapters/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const updated = academicStore.updateChapter(id, req.body);
  if (!updated) {
    return res.status(404).json({ error: 'Chapter not found.' });
  }
  res.json(updated);
});

academicRouter.post('/chapters/:id/complete', (req: Request, res: Response) => {
  const { id } = req.params;
  const { completed = true } = req.body;
  const chapter = academicStore.markChapterCompleted(id, !!completed);
  if (!chapter) {
    return res.status(404).json({ error: 'Chapter not found.' });
  }
  res.json(chapter);
});

academicRouter.delete('/chapters/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const deleted = academicStore.deleteChapter(id);
  if (!deleted) {
    return res.status(404).json({ error: 'Chapter not found.' });
  }
  res.json({ success: true, id });
});

// --- Topic Endpoints ---
academicRouter.get('/topics', (req: Request, res: Response) => {
  const chapterId = req.query.chapterId as string | undefined;
  res.json(academicStore.getTopics(chapterId));
});

academicRouter.post('/topics', (req: Request, res: Response) => {
  const { chapterId, subjectId, name, description, status } = req.body;
  if (!chapterId || !name || typeof name !== 'string' || !name.trim()) {
    return res.status(400).json({ error: 'chapterId and Topic name are required.' });
  }

  const isCompleted = status === 'Completed';
  const now = new Date().toISOString();

  const topic = academicStore.addTopic({
    chapterId,
    subjectId: subjectId || '',
    name: name.trim(),
    description: description || '',
    status: status || 'Not Started',
    completed: isCompleted,
    completedAt: isCompleted ? now : undefined,
  });

  res.status(201).json(topic);
});

academicRouter.put('/topics/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const updated = academicStore.updateTopic(id, req.body);
  if (!updated) {
    return res.status(404).json({ error: 'Topic not found.' });
  }
  res.json(updated);
});

academicRouter.post('/topics/:id/toggle', (req: Request, res: Response) => {
  const { id } = req.params;
  const result = academicStore.toggleTopic(id);
  if (!result) {
    return res.status(404).json({ error: 'Topic not found.' });
  }
  res.json(result);
});

academicRouter.delete('/topics/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const deleted = academicStore.deleteTopic(id);
  if (!deleted) {
    return res.status(404).json({ error: 'Topic not found.' });
  }
  res.json({ success: true, id });
});

// --- Note Endpoints ---
academicRouter.get('/notes', (req: Request, res: Response) => {
  const { subjectId, chapterId, topicId } = req.query;
  const notes = academicStore.getNotes({
    subjectId: subjectId as string,
    chapterId: chapterId as string,
    topicId: topicId as string,
  });
  res.json(notes);
});

academicRouter.post('/notes', (req: Request, res: Response) => {
  const note = academicStore.saveNote(req.body);
  res.json(note);
});

academicRouter.delete('/notes/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const deleted = academicStore.deleteNote(id);
  if (!deleted) {
    return res.status(404).json({ error: 'Note not found.' });
  }
  res.json({ success: true, id });
});

// --- Note Image Upload & Management ---
academicRouter.post('/notes/:noteId/images', (req: Request, res: Response) => {
  const { noteId } = req.params;

  upload.single('image')(req, res, (err) => {
    if (err) {
      const message = err instanceof multer.MulterError && err.code === 'LIMIT_FILE_SIZE'
        ? 'File exceeds maximum limit of 10MB.'
        : err.message || 'Image upload failed.';
      return res.status(400).json({ error: message });
    }

    if (!req.file) {
      return res.status(400).json({ error: 'No image file provided in request.' });
    }

    const file = req.file;
    const caption = (req.body.caption as string) || '';
    const fileUrl = `/api/uploads/${file.filename}`;

    const newImage: NoteImage = {
      id: `img-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      noteId,
      url: fileUrl,
      storagePath: file.path,
      fileName: file.originalname,
      mimeType: file.mimetype,
      fileSize: file.size,
      caption,
      order: 0,
      createdAt: new Date().toISOString(),
    };

    const updatedNote = academicStore.addNoteImage(noteId, newImage);
    if (!updatedNote) {
      // If note wasn't found, try to auto-create note if chapterId or topicId was passed
      const { chapterId, topicId, subjectId } = req.body;
      if (chapterId || topicId) {
        const createdNote = academicStore.saveNote({
          id: noteId,
          chapterId,
          topicId,
          subjectId,
          title: topicId ? 'Topic Note' : 'Chapter Note',
          content: '',
          images: [newImage],
        });
        return res.status(201).json({ note: createdNote, image: newImage });
      }
      return res.status(404).json({ error: 'Note not found.' });
    }

    res.status(201).json({ note: updatedNote, image: newImage });
  });
});

academicRouter.delete('/notes/:noteId/images/:imageId', (req: Request, res: Response) => {
  const { noteId, imageId } = req.params;
  const updatedNote = academicStore.deleteNoteImage(noteId, imageId);
  if (!updatedNote) {
    return res.status(404).json({ error: 'Note or image not found.' });
  }
  res.json({ success: true, note: updatedNote });
});

academicRouter.put('/notes/:noteId/images/:imageId/caption', (req: Request, res: Response) => {
  const { noteId, imageId } = req.params;
  const { caption = '' } = req.body;
  const updatedNote = academicStore.updateNoteImageCaption(noteId, imageId, caption);
  if (!updatedNote) {
    return res.status(404).json({ error: 'Note or image not found.' });
  }
  res.json({ success: true, note: updatedNote });
});

academicRouter.put('/notes/:noteId/images/reorder', (req: Request, res: Response) => {
  const { noteId } = req.params;
  const { imageIds = [] } = req.body;
  const updatedNote = academicStore.reorderNoteImages(noteId, imageIds);
  if (!updatedNote) {
    return res.status(404).json({ error: 'Note not found.' });
  }
  res.json({ success: true, note: updatedNote });
});
