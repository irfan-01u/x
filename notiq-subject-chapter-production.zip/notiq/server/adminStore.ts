import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../data');
const STATE_FILE = path.resolve(DATA_DIR, 'platform_state.json');

export type AdminRole = 'SUPER_ADMIN' | 'ADMIN' | 'MODERATOR';

export interface AdminUser {
  id: string;
  username: string;
  name: string;
  email: string;
  role: AdminRole;
  passwordHash: string;
  passwordSalt: string;
  isInitialPassword: boolean;
  status: 'ACTIVE' | 'DISABLED';
  createdAt: string;
  lastLoginAt?: string;
  failedLoginAttempts: number;
  lockoutUntil?: number;
}

export interface StudentUser {
  id: string;
  username: string;
  name: string;
  email: string;
  avatar: string;
  totalStudyHours: number;
  sessionsCount: number;
  currentStreak: number;
  achievementsUnlocked: number;
  league: 'Bronze' | 'Silver' | 'Gold' | 'Platinum' | 'Diamond' | 'Master';
  leaguePoints: number;
  status: 'ACTIVE' | 'SUSPENDED';
  joinedAt: string;
  lastActiveAt: string;
  reportsCount: number;
  suspendReason?: string;
  showOnLeaderboard?: boolean;
  showAvatar?: boolean;
  showRealName?: boolean;
}

export interface UserReport {
  id: string;
  targetUserId: string;
  targetUsername: string;
  reportedBy: string;
  reason: 'SUSPICIOUS_STUDY_TIME' | 'INAPPROPRIATE_PROFILE' | 'LEADERBOARD_EXPLOIT' | 'SPAM';
  description: string;
  timestamp: string;
  status: 'PENDING' | 'RESOLVED' | 'DISMISSED';
  resolvedBy?: string;
  resolvedAt?: string;
  resolutionNote?: string;
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  targetType: 'HOURS' | 'DAYS_STREAK' | 'POMODOROS' | 'SUBJECT_FOCUS';
  targetValue: number;
  xpReward: number;
  participantsCount: number;
  completionsCount: number;
  startDate: string;
  endDate: string;
  status: 'ACTIVE' | 'UPCOMING' | 'COMPLETED' | 'CANCELLED';
  badgeIcon: string;
}

export interface AchievementItem {
  id: string;
  title: string;
  description: string;
  category: 'TIME' | 'STREAK' | 'POMODORO' | 'ACADEMIC' | 'MASTERY';
  tier: 'BRONZE' | 'SILVER' | 'GOLD' | 'PLATINUM' | 'DIAMOND';
  xp: number;
  ruleMetric: string;
  ruleThreshold: number;
  unlocksCount: number;
  status: 'ACTIVE' | 'ARCHIVED';
  icon: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  targetAudience: 'ALL' | 'LEAGUE_COMPETITORS' | 'NEW_USERS';
  authorAdmin: string;
  createdAt: string;
  expiresAt?: string;
  active: boolean;
}

export interface ActiveStopwatchSession {
  userId: string;
  sessionId: string;
  startTime: number; // server timestamp ms
  lastResumeTime: number; // server timestamp ms
  status: 'running' | 'paused' | 'completed' | 'cancelled';
  subjectId: string;
  chapterId?: string;
  sessionType: string;
  taskTitle?: string;
  note?: string;
  tags: string[];
  accumulatedSeconds: number;
  pausedAt?: number;
  createdAt: string;
  lastUpdatedAt: string;
  laps: Array<{ lapNumber: number; lapTime: number; totalTime: number }>;
}

export interface RecordedStudySession {
  id: string;
  userId: string;
  startTime: string;
  endTime: string;
  duration: number; // seconds
  subjectId: string;
  chapterId?: string;
  sessionType: string;
  taskTitle?: string;
  note?: string;
  tags: string[];
  timerMode: string;
  completedNormally: boolean;
  interrupted: boolean;
  dateString: string; // YYYY-MM-DD in timezone
  createdAt: string;
}

export interface DailyLeaderboardEntry {
  rank: number;
  userId: string;
  name: string;
  username: string;
  avatar: string;
  studyMinutes: number;
  streak: number;
  xp: number;
  tier: string;
  institution?: string;
  country?: string;
  isCurrentUser?: boolean;
}

export interface LeaderboardSnapshotRecord {
  id: string;
  periodType: 'daily' | 'weekly' | 'monthly' | 'all-time';
  periodKey: string;
  userId: string;
  rank: number;
  studyMinutes: number;
  studyScore: number;
  streak: number;
  rankMovement: number;
  createdAt: string;
}

export interface LeaderboardHistoryRecord {
  id: string;
  periodType: 'daily' | 'weekly' | 'monthly' | 'all-time';
  periodKey: string;
  userId: string;
  finalRank: number;
  studyMinutes: number;
  studyScore: number;
  streak: number;
  leagueId?: string;
  rankMovement: number;
  personalBest: boolean;
  createdAt: string;
}

export interface WeeklyLeague {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  tier: string;
  status: 'ACTIVE' | 'COMPLETED';
  createdAt: string;
}

export interface LeagueMember {
  id: string;
  leagueId: string;
  userId: string;
  joinedAt: string;
  status: 'ACTIVE' | 'PROMOTED' | 'RETAINED' | 'DEMOTED';
}

export interface DailyLeaderboardSnapshot {
  dateKey: string; // YYYY-MM-DD
  timezone: string; // 'Asia/Dhaka'
  closedAt: string;
  totalStudyMinutes: number;
  participantsCount: number;
  top3: DailyLeaderboardEntry[];
  rankings: DailyLeaderboardEntry[];
}

export interface LeaderboardRuleConfig {
  weekCycle: 'SUNDAY_MIDNIGHT' | 'MONDAY_MIDNIGHT';
  dailyResetTimezone: string;
  promotionCutoff: number; // Top N users advance
  relegationCutoff: number; // Bottom N users relegate
  xpToPointsRatio: number;
  antiCheatWallClockStrictness: 'LENIENT' | 'STANDARD' | 'MAXIMUM_STRICT';
  maxDailyHoursCap: number;
  lastCalculatedAt: string;
  lastDailyResetDate?: string;
  promotionPercentage: number;
  demotionPercentage: number;
  minimumParticipants: number;
  leagueTiers: string[];
}

export interface PlatformSettings {
  maintenanceMode: boolean;
  registrationOpen: boolean;
  requireEmailVerification: boolean;
  antiCheatMode: 'STANDARD' | 'STRICT' | 'AGGRESSIVE';
  maxStudySessionHours: number;
  sessionTimeoutMinutes: number;
  maxFailedLoginAttempts: number;
  lockoutDurationMinutes: number;
  systemName: string;
  supportEmail: string;
}

export interface AuditLogEntry {
  id: string;
  adminId: string;
  adminUsername: string;
  role: string;
  action: string;
  target: string;
  timestamp: string;
  status: 'SUCCESS' | 'WARNING' | 'FAILED';
  metadata?: Record<string, any>;
  ip?: string;
}

const DEMO_STUDENT_USER_IDS = new Set(['user-01','user-02','user-03','user-04','user-05','user-06','user-07','user-08']);
const DEMO_ADMIN_IDS = new Set(['admin_mod_2','admin_ops_3']);
const DEMO_REPORT_IDS = new Set(['rep-1','rep-2']);
const DEMO_CHALLENGE_IDS = new Set(['ch-01','ch-02','ch-03','ch-04']);
const DEMO_ACHIEVEMENT_IDS = new Set(['ach-01','ach-02','ach-03','ach-04','ach-05']);
const DEMO_ANNOUNCEMENT_IDS = new Set(['ann-01','ann-02']);
const DEMO_AUDIT_IDS = new Set(['audit-01','audit-02','audit-03']);

interface PlatformState {
  admins: AdminUser[];
  users: StudentUser[];
  reports: UserReport[];
  challenges: Challenge[];
  achievements: AchievementItem[];
  announcements: Announcement[];
  leaderboardRules: LeaderboardRuleConfig;
  settings: PlatformSettings;
  auditLogs: AuditLogEntry[];
  activeStopwatches: Record<string, ActiveStopwatchSession>;
  dailySnapshots: DailyLeaderboardSnapshot[];
  studySessions: RecordedStudySession[];
  leaderboardSnapshots: LeaderboardSnapshotRecord[];
  leaderboardHistory: LeaderboardHistoryRecord[];
  weeklyLeagues: WeeklyLeague[];
  leagueMembers: LeagueMember[];
  leaderboardNotifications: Array<{ id: string; userId: string; title: string; message: string; createdAt: string; read: boolean }>;
}

// Secure password hashing using Node scrypt
export function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const chosenSalt = salt || crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, chosenSalt, 64);
  return {
    hash: derivedKey.toString('hex'),
    salt: chosenSalt,
  };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  try {
    const derivedKey = crypto.scryptSync(password, salt, 64);
    const keyBuffer = Buffer.from(hash, 'hex');
    return crypto.timingSafeEqual(derivedKey, keyBuffer);
  } catch {
    return false;
  }
}

// Timezone & Date calculation helpers.
// Daily leaderboard settlement is ALWAYS anchored to Asia/Dhaka.  Never use the
// Node/browser local timezone or UTC midnight as the source of truth.
export const DAILY_RESET_TIMEZONE = 'Asia/Dhaka';

function getZonedParts(date: Date, timeZone: string) {
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone,
    calendar: 'gregory',
    numberingSystem: 'latn',
    hour12: false,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
  const parts = Object.fromEntries(
    formatter.formatToParts(date)
      .filter(part => part.type !== 'literal')
      .map(part => [part.type, Number(part.value)])
  ) as Record<string, number>;
  // Some Intl implementations render midnight as 24:xx. Normalize it to 00:xx.
  if (parts.hour === 24) parts.hour = 0;
  return parts;
}

/** Return the timezone offset (UTC milliseconds -> local wall-clock milliseconds). */
function getTimeZoneOffsetMs(date: Date, timeZone: string): number {
  const p = getZonedParts(date, timeZone);
  const asUtcWallClock = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
  const roundedActual = Math.floor(date.getTime() / 1000) * 1000;
  return asUtcWallClock - roundedActual;
}

/** Convert a local calendar date/time in `timeZone` to its UTC instant. */
function zonedDateTimeToUtc(parts: { year: number; month: number; day: number; hour: number; minute: number; second: number }, timeZone: string): Date {
  let guess = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second);
  // Two iterations handle normal fixed-offset zones and DST transitions safely.
  for (let i = 0; i < 3; i++) {
    const offset = getTimeZoneOffsetMs(new Date(guess), timeZone);
    guess = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second) - offset;
  }
  return new Date(guess);
}

export function getDateKeyInTimezone(date: Date = new Date(), timeZone: string = DAILY_RESET_TIMEZONE): string {
  try {
    const p = getZonedParts(date, timeZone);
    return `${String(p.year).padStart(4, '0')}-${String(p.month).padStart(2, '0')}-${String(p.day).padStart(2, '0')}`;
  } catch {
    // This fallback is only for an invalid timezone/environment. The production
    // daily leaderboard always uses Asia/Dhaka, which is supported by Node.
    return date.toISOString().slice(0, 10);
  }
}

/** Add calendar days to a YYYY-MM-DD key without depending on server timezone. */
export function shiftDateKey(dateKey: string, days: number): string {
  const [year, month, day] = dateKey.split('-').map(Number);
  const d = new Date(Date.UTC(year, month - 1, day, 12, 0, 0));
  d.setUTCDate(d.getUTCDate() + days);
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
}

/**
 * Exact next midnight instant in the requested timezone.
 * For NOTIQ daily competition this is always 00:00:00 Asia/Dhaka.
 */
export function getNextMidnightInTimezone(now: Date = new Date(), timeZone: string = DAILY_RESET_TIMEZONE): Date {
  const current = getZonedParts(now, timeZone);
  const nextDateKey = shiftDateKey(
    `${String(current.year).padStart(4, '0')}-${String(current.month).padStart(2, '0')}-${String(current.day).padStart(2, '0')}`,
    1
  );
  const [year, month, day] = nextDateKey.split('-').map(Number);
  return zonedDateTimeToUtc({ year, month, day, hour: 0, minute: 0, second: 0 }, timeZone);
}

/** Exact wall-clock difference from now to the next timezone midnight. */
export function getSecondsUntilMidnightInTimezone(timeZone: string = DAILY_RESET_TIMEZONE, now: Date = new Date()): number {
  try {
    const nextMidnight = getNextMidnightInTimezone(now, timeZone);
    return Math.max(0, Math.ceil((nextMidnight.getTime() - now.getTime()) / 1000));
  } catch {
    return 0;
  }
}

class AdminStore {
  private state!: PlatformState;

  constructor() {
    this.init();
  }

  private init() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    if (fs.existsSync(STATE_FILE)) {
      try {
        const raw = fs.readFileSync(STATE_FILE, 'utf-8');
        this.state = JSON.parse(raw);
        // Remove only records known to be shipped demo/seed data. Real records are preserved.
        const removedUserIds = DEMO_STUDENT_USER_IDS;
        this.state.users = (this.state.users || []).filter(u => !removedUserIds.has(u.id));
        this.state.admins = (this.state.admins || []).filter(a => !DEMO_ADMIN_IDS.has(a.id));
        this.state.reports = (this.state.reports || []).filter(r => !DEMO_REPORT_IDS.has(r.id) && !removedUserIds.has(r.targetUserId) && !removedUserIds.has(r.reportedBy));
        this.state.challenges = (this.state.challenges || []).map(c => DEMO_CHALLENGE_IDS.has(c.id) ? { ...c, participantsCount: 0, completionsCount: 0 } : c);
        this.state.achievements = (this.state.achievements || []).map(a => DEMO_ACHIEVEMENT_IDS.has(a.id) ? { ...a, unlocksCount: 0 } : a);
        this.state.announcements = (this.state.announcements || []).filter(a => !DEMO_ANNOUNCEMENT_IDS.has(a.id));
        this.state.auditLogs = (this.state.auditLogs || []).filter(a => !DEMO_AUDIT_IDS.has(a.id));
        this.state.studySessions = (this.state.studySessions || []).filter(s => !removedUserIds.has(s.userId));
        this.state.dailySnapshots = (this.state.dailySnapshots || []).filter(s => !removedUserIds.has((s as any).userId));
        this.state.leaderboardSnapshots = (this.state.leaderboardSnapshots || []).filter(s => !removedUserIds.has(s.userId));
        this.state.leaderboardHistory = (this.state.leaderboardHistory || []).filter(s => !removedUserIds.has(s.userId));
        this.state.leagueMembers = (this.state.leagueMembers || []).filter(m => !removedUserIds.has(m.userId));
        this.state.leaderboardNotifications = (this.state.leaderboardNotifications || []).filter(n => !removedUserIds.has(n.userId));
        // Ensure backwards compatibility with existing state file
        if (!this.state.activeStopwatches) {
          this.state.activeStopwatches = {};
        }
        if (!this.state.dailySnapshots) {
          this.state.dailySnapshots = [];
        }
        if (!this.state.studySessions) {
          this.state.studySessions = [];
        }
        if (!this.state.leaderboardSnapshots) this.state.leaderboardSnapshots = [];
        if (!this.state.leaderboardHistory) this.state.leaderboardHistory = [];
        if (!this.state.weeklyLeagues) this.state.weeklyLeagues = [];
        if (!this.state.leagueMembers) this.state.leagueMembers = [];
        if (!this.state.leaderboardNotifications) this.state.leaderboardNotifications = [];
        if (!this.state.leaderboardRules) this.state.leaderboardRules = {} as LeaderboardRuleConfig;
        if (!this.state.leaderboardRules.maxDailyHoursCap || this.state.leaderboardRules.maxDailyHoursCap === 16) this.state.leaderboardRules.maxDailyHoursCap = 12;
        if (!this.state.leaderboardRules.weekCycle || this.state.leaderboardRules.weekCycle === 'SUNDAY_MIDNIGHT') this.state.leaderboardRules.weekCycle = 'MONDAY_MIDNIGHT';
        if (this.state.leaderboardRules.promotionPercentage === undefined) this.state.leaderboardRules.promotionPercentage = 20;
        if (this.state.leaderboardRules.demotionPercentage === undefined) this.state.leaderboardRules.demotionPercentage = 20;
        if (this.state.leaderboardRules.minimumParticipants === undefined) this.state.leaderboardRules.minimumParticipants = 5;
        if (!this.state.leaderboardRules.leagueTiers) this.state.leaderboardRules.leagueTiers = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond'];
        // Old builds shipped with synthetic leaderboard rows. They are not valid historical data.
        // Remove those rows unless they can be reconciled to real persisted study sessions.
        const realUserIds = new Set(this.state.studySessions.map(s => s.userId));
        this.state.dailySnapshots = (this.state.dailySnapshots || []).map(snapshot => ({
          ...snapshot,
          rankings: snapshot.rankings.filter(r => realUserIds.has(r.userId)),
          top3: snapshot.top3.filter(r => realUserIds.has(r.userId)),
        })).filter(snapshot => snapshot.rankings.length > 0);
        if (this.state.studySessions.length === 0) this.state.dailySnapshots = [];
        if (!this.state.leaderboardRules.dailyResetTimezone) {
          this.state.leaderboardRules.dailyResetTimezone = DAILY_RESET_TIMEZONE;
        }
        if (this.state.dailySnapshots.length === 0) {
          this.seedInitialDailySnapshots();
        }
        this.checkAndTriggerDailyReset();

        // Ensure initial admin exists if state is corrupted
        if (!this.state.admins || this.state.admins.length === 0) {
          this.seedInitialAdmin();
        }
        this.save();
        return;
      } catch (err) {
        console.error('Failed to parse platform state, re-seeding:', err);
      }
    }

    this.seedDefaultState();
    this.seedInitialDailySnapshots();
    this.save();
  }

  private seedInitialAdmin() {
    // Initial Admin Credentials: admin / STUDIQ@Admin#2026
    const { hash, salt } = hashPassword('STUDIQ@Admin#2026');
    const initialSuperAdmin: AdminUser = {
      id: 'admin_root_1',
      username: 'admin',
      name: 'Super Administrator',
      email: 'admin@studiq.academic',
      role: 'SUPER_ADMIN',
      passwordHash: hash,
      passwordSalt: salt,
      isInitialPassword: true,
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
      failedLoginAttempts: 0,
    };
    if (!this.state.admins) {
      this.state.admins = [];
    }
    this.state.admins.push(initialSuperAdmin);
  }

  private seedDefaultState() {
    const { hash, salt } = hashPassword('STUDIQ@Admin#2026');

    const initialSuperAdmin: AdminUser = {
      id: 'admin_root_1',
      username: 'admin',
      name: 'Super Administrator',
      email: 'admin@studiq.academic',
      role: 'SUPER_ADMIN',
      passwordHash: hash,
      passwordSalt: salt,
      isInitialPassword: true,
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
      failedLoginAttempts: 0,
    };

    const initialReports: UserReport[] = [];

    const initialChallenges: Challenge[] = [
      {
        id: 'ch-01',
        title: '7-Day Iron Habit Challenge',
        description: 'Complete at least 90 minutes of active focused study every day for 7 consecutive days.',
        targetType: 'DAYS_STREAK',
        targetValue: 7,
        xpReward: 500,
        participantsCount: 0,
        completionsCount: 0,
        startDate: '2026-09-20T00:00:00Z',
        endDate: '2026-09-27T23:59:59Z',
        status: 'ACTIVE',
        badgeIcon: 'Flame',
      },
      {
        id: 'ch-02',
        title: '20-Hour Theoretical Physics Marathon',
        description: 'Log 20 verified hours in Mathematics or Physics subject modules this week.',
        targetType: 'HOURS',
        targetValue: 20,
        xpReward: 1000,
        participantsCount: 0,
        completionsCount: 0,
        startDate: '2026-09-22T00:00:00Z',
        endDate: '2026-09-29T23:59:59Z',
        status: 'ACTIVE',
        badgeIcon: 'Atom',
      },
      {
        id: 'ch-03',
        title: '50 Pomodoros Without Interruption',
        description: 'Successfully complete 50 full 25m or 50m Pomodoro blocks without aborting early.',
        targetType: 'POMODOROS',
        targetValue: 50,
        xpReward: 750,
        participantsCount: 0,
        completionsCount: 0,
        startDate: '2026-09-18T00:00:00Z',
        endDate: '2026-09-30T23:59:59Z',
        status: 'ACTIVE',
        badgeIcon: 'Timer',
      },
      {
        id: 'ch-04',
        title: 'Midterm Spaced Revision Sprint',
        description: 'Review and clear 10 chapters scheduled in your spaced revision queue.',
        targetType: 'SUBJECT_FOCUS',
        targetValue: 10,
        xpReward: 600,
        participantsCount: 0,
        completionsCount: 0,
        startDate: '2026-09-10T00:00:00Z',
        endDate: '2026-09-20T23:59:59Z',
        status: 'COMPLETED',
        badgeIcon: 'RefreshCw',
      },
    ];

    const initialAchievements: AchievementItem[] = [
      {
        id: 'ach-01',
        title: 'First Step to Mastery',
        description: 'Complete your very first verified study session.',
        category: 'TIME',
        tier: 'BRONZE',
        xp: 50,
        ruleMetric: 'sessions_count',
        ruleThreshold: 1,
        unlocksCount: 0,
        status: 'ACTIVE',
        icon: 'Sparkles',
      },
      {
        id: 'ach-02',
        title: 'Centurion of Focus',
        description: 'Accumulate 100 total hours of deep work across all subjects.',
        category: 'TIME',
        tier: 'GOLD',
        xp: 500,
        ruleMetric: 'study_hours',
        ruleThreshold: 100,
        unlocksCount: 0,
        status: 'ACTIVE',
        icon: 'Clock',
      },
      {
        id: 'ach-03',
        title: 'Iron Discipline',
        description: 'Sustain a verified daily study streak for 30 consecutive days.',
        category: 'STREAK',
        tier: 'DIAMOND',
        xp: 1000,
        ruleMetric: 'streak_days',
        ruleThreshold: 30,
        unlocksCount: 0,
        status: 'ACTIVE',
        icon: 'Flame',
      },
      {
        id: 'ach-04',
        title: 'Pomodoro Artisan',
        description: 'Complete 100 Pomodoro focus intervals without early cancellation.',
        category: 'POMODORO',
        tier: 'SILVER',
        xp: 250,
        ruleMetric: 'pomodoro_count',
        ruleThreshold: 100,
        unlocksCount: 0,
        status: 'ACTIVE',
        icon: 'Target',
      },
      {
        id: 'ach-05',
        title: 'Syllabus Conqueror',
        description: 'Mark all chapters in at least 3 distinct subjects as 100% completed.',
        category: 'ACADEMIC',
        tier: 'PLATINUM',
        xp: 750,
        ruleMetric: 'subjects_completed',
        ruleThreshold: 3,
        unlocksCount: 0,
        status: 'ACTIVE',
        icon: 'BookOpen',
      },
    ];

    const initialAnnouncements: Announcement[] = [];

    const initialLeaderboardRules: LeaderboardRuleConfig = {
      weekCycle: 'MONDAY_MIDNIGHT',
      dailyResetTimezone: 'Asia/Dhaka',
      promotionCutoff: 3,
      relegationCutoff: 3,
      xpToPointsRatio: 1.0,
      antiCheatWallClockStrictness: 'MAXIMUM_STRICT',
      maxDailyHoursCap: 12,
      lastCalculatedAt: new Date(Date.now() - 43200000).toISOString(),
      promotionPercentage: 20,
      demotionPercentage: 20,
      minimumParticipants: 5,
      leagueTiers: ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond'],
    };

    const initialSettings: PlatformSettings = {
      maintenanceMode: false,
      registrationOpen: true,
      requireEmailVerification: true,
      antiCheatMode: 'STRICT',
      maxStudySessionHours: 6,
      sessionTimeoutMinutes: 480,
      maxFailedLoginAttempts: 5,
      lockoutDurationMinutes: 15,
      systemName: 'NOTIQ Academic Platform',
      supportEmail: 'support@studiq.academic',
    };

    const initialAuditLogs: AuditLogEntry[] = [];

    this.state = {
      admins: [initialSuperAdmin],
      users: [],
      reports: initialReports,
      challenges: initialChallenges,
      achievements: initialAchievements,
      announcements: initialAnnouncements,
      leaderboardRules: initialLeaderboardRules,
      settings: initialSettings,
      auditLogs: initialAuditLogs,
      activeStopwatches: {},
      dailySnapshots: [],
      studySessions: [],
      leaderboardSnapshots: [],
      leaderboardHistory: [],
      weeklyLeagues: [],
      leagueMembers: [],
      leaderboardNotifications: [],
    };
  }

  private seedInitialDailySnapshots() {
    // Competitive data must never be fabricated. Start with an empty archive;
    // real snapshots are produced only from validated study sessions.
    const tz = DAILY_RESET_TIMEZONE;
    this.state.dailySnapshots = this.state.dailySnapshots || [];
    this.state.leaderboardRules.lastDailyResetDate = getDateKeyInTimezone(new Date(), tz);
  }

  public save() {
    try {
      fs.writeFileSync(STATE_FILE, JSON.stringify(this.state, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to save platform state:', err);
    }
  }

  // --- Admins ---
  public getAdmins(): AdminUser[] {
    return this.state.admins;
  }

  public findAdminByUsername(username: string): AdminUser | undefined {
    return this.state.admins.find(a => a.username.toLowerCase() === username.toLowerCase().trim());
  }

  public findAdminById(id: string): AdminUser | undefined {
    return this.state.admins.find(a => a.id === id);
  }

  public addAdmin(admin: AdminUser) {
    this.state.admins.push(admin);
    this.save();
  }

  public updateAdmin(id: string, updates: Partial<AdminUser>) {
    const idx = this.state.admins.findIndex(a => a.id === id);
    if (idx !== -1) {
      this.state.admins[idx] = { ...this.state.admins[idx], ...updates };
      this.save();
      return this.state.admins[idx];
    }
    return null;
  }

  public removeAdmin(id: string): boolean {
    const initialLen = this.state.admins.length;
    this.state.admins = this.state.admins.filter(a => a.id !== id);
    if (this.state.admins.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // --- Users ---
  public getUsers(): StudentUser[] {
    return this.state.users;
  }

  public findUserById(id: string): StudentUser | undefined {
    return this.state.users.find(u => u.id === id);
  }

  public isRegisteredStudent(id: string): boolean {
    const normalized = String(id || '').trim();
    return Boolean(normalized && !normalized.startsWith('device:') && normalized !== 'guest-user' && this.state.users.some(u => u.id === normalized));
  }

  public updateUser(id: string, updates: Partial<StudentUser>) {
    const idx = this.state.users.findIndex(u => u.id === id);
    if (idx !== -1) {
      this.state.users[idx] = { ...this.state.users[idx], ...updates };
      this.save();
      return this.state.users[idx];
    }
    return null;
  }

  public addUser(user: StudentUser) {
    this.state.users.unshift(user);
    this.save();
  }

  public removeUser(id: string): boolean {
    const initialLen = this.state.users.length;
    this.state.users = this.state.users.filter(u => u.id !== id);
    if (this.state.users.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // --- Reports ---
  public getReports(): UserReport[] {
    return this.state.reports;
  }

  public updateReport(id: string, updates: Partial<UserReport>) {
    const idx = this.state.reports.findIndex(r => r.id === id);
    if (idx !== -1) {
      this.state.reports[idx] = { ...this.state.reports[idx], ...updates };
      this.save();
      return this.state.reports[idx];
    }
    return null;
  }

  // --- Challenges ---
  public getChallenges(): Challenge[] {
    return this.state.challenges;
  }

  public addChallenge(challenge: Challenge) {
    this.state.challenges.unshift(challenge);
    this.save();
  }

  public updateChallenge(id: string, updates: Partial<Challenge>) {
    const idx = this.state.challenges.findIndex(c => c.id === id);
    if (idx !== -1) {
      this.state.challenges[idx] = { ...this.state.challenges[idx], ...updates };
      this.save();
      return this.state.challenges[idx];
    }
    return null;
  }

  public deleteChallenge(id: string): boolean {
    const initialLen = this.state.challenges.length;
    this.state.challenges = this.state.challenges.filter(c => c.id !== id);
    if (this.state.challenges.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // --- Achievements ---
  public getAchievements(): AchievementItem[] {
    return this.state.achievements;
  }

  public addAchievement(item: AchievementItem) {
    this.state.achievements.unshift(item);
    this.save();
  }

  public updateAchievement(id: string, updates: Partial<AchievementItem>) {
    const idx = this.state.achievements.findIndex(a => a.id === id);
    if (idx !== -1) {
      this.state.achievements[idx] = { ...this.state.achievements[idx], ...updates };
      this.save();
      return this.state.achievements[idx];
    }
    return null;
  }

  // --- Announcements ---
  public getAnnouncements(): Announcement[] {
    return this.state.announcements;
  }

  public addAnnouncement(announcement: Announcement) {
    this.state.announcements.unshift(announcement);
    this.save();
  }

  public updateAnnouncement(id: string, updates: Partial<Announcement>) {
    const idx = this.state.announcements.findIndex(a => a.id === id);
    if (idx !== -1) {
      this.state.announcements[idx] = { ...this.state.announcements[idx], ...updates };
      this.save();
      return this.state.announcements[idx];
    }
    return null;
  }

  public deleteAnnouncement(id: string): boolean {
    const initialLen = this.state.announcements.length;
    this.state.announcements = this.state.announcements.filter(a => a.id !== id);
    if (this.state.announcements.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // --- Rules & Settings ---
  public getLeaderboardRules(): LeaderboardRuleConfig {
    return this.state.leaderboardRules;
  }

  public updateLeaderboardRules(updates: Partial<LeaderboardRuleConfig>) {
    // Daily leaderboard settlement is a platform-wide calendar boundary.
    // Admin configuration cannot move it away from Asia/Dhaka.
    this.state.leaderboardRules = {
      ...this.state.leaderboardRules,
      ...updates,
      dailyResetTimezone: DAILY_RESET_TIMEZONE,
    };
    this.save();
    return this.state.leaderboardRules;
  }

  public getSettings(): PlatformSettings {
    return this.state.settings;
  }

  public updateSettings(updates: Partial<PlatformSettings>) {
    this.state.settings = { ...this.state.settings, ...updates };
    this.save();
    return this.state.settings;
  }

  // --- Audit Logs ---
  public getAuditLogs(): AuditLogEntry[] {
    return this.state.auditLogs;
  }

  public logAudit(entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) {
    const newEntry: AuditLogEntry = {
      id: `audit-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      timestamp: new Date().toISOString(),
      ...entry,
    };
    this.state.auditLogs.unshift(newEntry);
    // Keep max 500 logs
    if (this.state.auditLogs.length > 500) {
      this.state.auditLogs.length = 500;
    }
    this.save();
  }

  // --- Persistent Stopwatch Management ---
  public calculateStopwatchElapsed(session: ActiveStopwatchSession): number {
    if (session.status === 'paused') {
      return session.accumulatedSeconds;
    }
    if (session.status === 'running') {
      const now = Date.now();
      const currentRun = Math.max(0, Math.floor((now - (session.lastResumeTime || session.startTime)) / 1000));
      return session.accumulatedSeconds + currentRun;
    }
    return session.accumulatedSeconds;
  }

  public getActiveStopwatch(userId: string): (ActiveStopwatchSession & { elapsedSeconds: number }) | null {
    const session = this.state.activeStopwatches[userId];
    if (!session) return null;
    const elapsedSeconds = this.calculateStopwatchElapsed(session);
    return { ...session, elapsedSeconds };
  }

  public startStopwatch(data: {
    userId: string;
    sessionId?: string;
    subjectId: string;
    chapterId?: string;
    sessionType?: string;
    taskTitle?: string;
    note?: string;
    tags?: string[];
    force?: boolean;
  }): {
    success: boolean;
    session?: ActiveStopwatchSession & { elapsedSeconds: number };
    conflict?: boolean;
    existingSession?: ActiveStopwatchSession & { elapsedSeconds: number };
  } {
    const existing = this.state.activeStopwatches[data.userId];
    if (existing && (existing.status === 'running' || existing.status === 'paused') && !data.force) {
      const elapsedSeconds = this.calculateStopwatchElapsed(existing);
      return {
        success: false,
        conflict: true,
        existingSession: { ...existing, elapsedSeconds },
      };
    }

    const now = Date.now();
    const session: ActiveStopwatchSession = {
      userId: data.userId,
      sessionId: data.sessionId || `sw-sess-${now}-${Math.random().toString(36).slice(2, 7)}`,
      startTime: now,
      lastResumeTime: now,
      status: 'running',
      subjectId: data.subjectId,
      chapterId: data.chapterId,
      sessionType: data.sessionType || 'Practice',
      taskTitle: data.taskTitle,
      note: data.note,
      tags: data.tags || ['#study', '#stopwatch'],
      accumulatedSeconds: 0,
      createdAt: new Date(now).toISOString(),
      lastUpdatedAt: new Date(now).toISOString(),
      laps: [],
    };

    this.state.activeStopwatches[data.userId] = session;
    this.save();

    return {
      success: true,
      session: { ...session, elapsedSeconds: 0 },
    };
  }

  public pauseStopwatch(userId: string): (ActiveStopwatchSession & { elapsedSeconds: number }) | null {
    const session = this.state.activeStopwatches[userId];
    if (!session || session.status !== 'running') return null;

    const now = Date.now();
    const currentRun = Math.max(0, Math.floor((now - (session.lastResumeTime || session.startTime)) / 1000));
    session.accumulatedSeconds += currentRun;
    session.status = 'paused';
    session.pausedAt = now;
    session.lastUpdatedAt = new Date(now).toISOString();
    this.save();

    return { ...session, elapsedSeconds: session.accumulatedSeconds };
  }

  public resumeStopwatch(userId: string): (ActiveStopwatchSession & { elapsedSeconds: number }) | null {
    const session = this.state.activeStopwatches[userId];
    if (!session || session.status !== 'paused') return null;

    const now = Date.now();
    session.status = 'running';
    session.lastResumeTime = now;
    session.pausedAt = undefined;
    session.lastUpdatedAt = new Date(now).toISOString();
    this.save();

    const elapsedSeconds = this.calculateStopwatchElapsed(session);
    return { ...session, elapsedSeconds };
  }

  public addStopwatchLap(
    userId: string,
    lapData?: { lapTime: number; totalTime: number }
  ): (ActiveStopwatchSession & { elapsedSeconds: number }) | null {
    const session = this.state.activeStopwatches[userId];
    if (!session) return null;

    const totalTime = this.calculateStopwatchElapsed(session);
    const lapNumber = session.laps.length + 1;
    const previousTotal = session.laps.length > 0 ? session.laps[session.laps.length - 1].totalTime : 0;
    const lapTime = lapData?.lapTime || Math.max(1, totalTime - previousTotal);

    session.laps.push({
      lapNumber,
      lapTime,
      totalTime,
    });
    session.lastUpdatedAt = new Date().toISOString();
    this.save();

    return { ...session, elapsedSeconds: totalTime };
  }

  public finishStopwatch(
    userId: string,
    interrupted = false
  ): { session: RecordedStudySession; elapsedSeconds: number } | null {
    const active = this.state.activeStopwatches[userId];
    if (!active) return null;

    const elapsedSeconds = Math.max(15, this.calculateStopwatchElapsed(active));
    const now = new Date();
    const startTime = new Date(active.startTime);
    const tz = DAILY_RESET_TIMEZONE;
    const dateKey = getDateKeyInTimezone(now, tz);

    const completedSession: RecordedStudySession = {
      id: active.sessionId,
      userId: active.userId,
      startTime: startTime.toISOString(),
      endTime: now.toISOString(),
      duration: elapsedSeconds,
      subjectId: active.subjectId,
      chapterId: active.chapterId,
      sessionType: active.sessionType,
      taskTitle: active.taskTitle,
      note: active.note,
      tags: active.tags,
      timerMode: 'stopwatch',
      completedNormally: !interrupted,
      interrupted,
      dateString: dateKey,
      createdAt: now.toISOString(),
    };

    // All competitive accounting goes through the same validated session pipeline.
    const result = this.recordStudySession(completedSession);
    // Remove active stopwatch even when the platform route already recorded the same session.
    delete this.state.activeStopwatches[userId];
    this.save();
    return { session: completedSession, elapsedSeconds };
  }

  public cancelStopwatch(userId: string): boolean {
    if (this.state.activeStopwatches[userId]) {
      delete this.state.activeStopwatches[userId];
      this.save();
      return true;
    }
    return false;
  }

  public syncStopwatch(
    userId: string,
    data: Partial<ActiveStopwatchSession>
  ): ActiveStopwatchSession & { elapsedSeconds: number } {
    let session = this.state.activeStopwatches[userId];
    const now = Date.now();
    if (!session) {
      session = {
        userId,
        sessionId: data.sessionId || `sw-offline-${now}`,
        startTime: data.startTime || now,
        lastResumeTime: data.lastResumeTime || data.startTime || now,
        status: data.status || 'running',
        subjectId: data.subjectId,
        chapterId: data.chapterId,
        sessionType: data.sessionType || 'Practice',
        taskTitle: data.taskTitle,
        note: data.note,
        tags: data.tags || ['#study', '#stopwatch'],
        accumulatedSeconds: data.accumulatedSeconds || 0,
        createdAt: data.createdAt || new Date(now).toISOString(),
        lastUpdatedAt: new Date(now).toISOString(),
        laps: data.laps || [],
      };
      this.state.activeStopwatches[userId] = session;
    } else {
      if (data.laps && data.laps.length >= session.laps.length) session.laps = data.laps;
      if (data.accumulatedSeconds !== undefined && data.accumulatedSeconds > session.accumulatedSeconds) {
        session.accumulatedSeconds = data.accumulatedSeconds;
      }
      if (data.status) session.status = data.status;
      session.lastUpdatedAt = new Date(now).toISOString();
    }

    this.save();
    const elapsedSeconds = this.calculateStopwatchElapsed(session);
    return { ...session, elapsedSeconds };
  }

  // --- Recorded Study Sessions / Leaderboard Source of Truth ---
  private getLeaderboardEligibleSessions() {
    const maxDailySeconds = Math.max(1, this.state.leaderboardRules.maxDailyHoursCap || 12) * 3600;
    const byUserDay: Record<string, number> = {};
    return this.state.studySessions
      .filter(s => s.completedNormally && !s.interrupted)
      .filter(s => Number.isFinite(s.duration) && s.duration > 0)
      .filter(s => this.state.users.some(u => u.id === s.userId && u.status === 'ACTIVE'))
      .filter(s => {
        const key = `${s.userId}:${s.dateString}`;
        const before = byUserDay[key] || 0;
        const remaining = Math.max(0, maxDailySeconds - before);
        const counted = Math.min(s.duration, remaining);
        byUserDay[key] = before + counted;
        return counted > 0;
      });
  }

  private getUserStreak(userId: string, throughDateKey?: string): number {
    const tz = DAILY_RESET_TIMEZONE;
    const dates = new Set(
      this.getLeaderboardEligibleSessions()
        .filter(s => s.userId === userId)
        .map(s => s.dateString)
    );
    let cursor = throughDateKey || getDateKeyInTimezone(new Date(), tz);
    let streak = 0;
    // A user may have no session today yet; in that case evaluate from yesterday.
    if (!dates.has(cursor)) {
      const d = new Date(`${cursor}T12:00:00Z`);
      d.setUTCDate(d.getUTCDate() - 1);
      cursor = getDateKeyInTimezone(d, tz);
    }
    for (let i = 0; i < 366; i++) {
      if (!dates.has(cursor)) break;
      streak += 1;
      const d = new Date(`${cursor}T12:00:00Z`);
      d.setUTCDate(d.getUTCDate() - 1);
      cursor = getDateKeyInTimezone(d, tz);
    }
    return streak;
  }

  private getPeriodBounds(periodType: 'daily' | 'weekly' | 'monthly' | 'all-time', now = new Date()) {
    const tz = DAILY_RESET_TIMEZONE;
    const todayKey = getDateKeyInTimezone(now, tz);
    if (periodType === 'daily') return { startKey: todayKey, endKey: todayKey, periodKey: todayKey };
    const today = new Date(`${todayKey}T12:00:00Z`);
    if (periodType === 'weekly') {
      const day = today.getUTCDay(); // Sun=0, Mon=1
      const diff = day === 0 ? 6 : day - 1;
      const start = new Date(today);
      start.setUTCDate(start.getUTCDate() - diff);
      const end = new Date(start);
      end.setUTCDate(end.getUTCDate() + 6);
      const startKey = getDateKeyInTimezone(start, tz);
      const endKey = getDateKeyInTimezone(end, tz);
      return { startKey, endKey, periodKey: startKey };
    }
    if (periodType === 'monthly') {
      const start = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), 1, 12));
      const end = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth() + 1, 0, 12));
      return { startKey: getDateKeyInTimezone(start, tz), endKey: getDateKeyInTimezone(end, tz), periodKey: getDateKeyInTimezone(start, tz).slice(0, 7) };
    }
    return { startKey: '0000-01-01', endKey: todayKey, periodKey: 'all-time' };
  }

  private getRealRankings(periodType: 'daily' | 'weekly' | 'monthly' | 'all-time', now = new Date()) {
    const bounds = this.getPeriodBounds(periodType, now);
    const sessions = this.getLeaderboardEligibleSessions().filter(s => s.dateString >= bounds.startKey && s.dateString <= bounds.endKey);
    const totals: Record<string, number> = {};
    sessions.forEach(s => { totals[s.userId] = (totals[s.userId] || 0) + s.duration; });
    const usersById = new Map(this.state.users.map(u => [u.id, u]));
    const rows = Object.entries(totals)
      .filter(([userId]) => usersById.get(userId)?.showOnLeaderboard !== false)
      .map(([userId, seconds]) => {
        const user = usersById.get(userId)!;
        const studyMinutes = Math.floor(seconds / 60);
        const studyScore = Math.round(studyMinutes * (this.state.leaderboardRules.xpToPointsRatio || 1));
        return {
          userId,
          name: user.showRealName === false ? user.username : user.name,
          username: user.username,
          avatar: user.showAvatar === false ? '' : user.avatar,
          studyMinutes,
          studyScore,
          streak: this.getUserStreak(userId, bounds.endKey),
          tier: user.league,
        };
      });
    rows.sort((a, b) => b.studyMinutes - a.studyMinutes || b.studyScore - a.studyScore || a.username.localeCompare(b.username));
    return rows.map((row, index) => ({ ...row, rank: index + 1 }));
  }

  private persistLiveSnapshot(periodType: 'daily' | 'weekly' | 'monthly' | 'all-time', rows: any[]) {
    const bounds = this.getPeriodBounds(periodType);
    const now = new Date().toISOString();
    for (const row of rows) {
      const idx = this.state.leaderboardSnapshots.findIndex(s => s.periodType === periodType && s.periodKey === bounds.periodKey && s.userId === row.userId);
      const previousRank = idx >= 0 ? this.state.leaderboardSnapshots[idx].rank : row.rank;
      const record: LeaderboardSnapshotRecord = {
        id: idx >= 0 ? this.state.leaderboardSnapshots[idx].id : `lbs-${periodType}-${bounds.periodKey}-${row.userId}`,
        periodType,
        periodKey: bounds.periodKey,
        userId: row.userId,
        rank: row.rank,
        studyMinutes: row.studyMinutes,
        studyScore: row.studyScore,
        streak: row.streak,
        rankMovement: previousRank - row.rank,
        createdAt: now,
      };
      if (idx >= 0) this.state.leaderboardSnapshots[idx] = record;
      else this.state.leaderboardSnapshots.push(record);
    }
    // Keep only recent live snapshots; finalized history is stored separately.
    if (this.state.leaderboardSnapshots.length > 5000) this.state.leaderboardSnapshots = this.state.leaderboardSnapshots.slice(-5000);
  }

  private finalizeDailyPeriod(dateKey: string): DailyLeaderboardSnapshot {
    const tz = DAILY_RESET_TIMEZONE;
    const existing = this.state.dailySnapshots.find(s => s.dateKey === dateKey);
    if (existing) return existing;
    const rows = this.getRealRankings('daily', new Date(`${dateKey}T12:00:00Z`));
    const snapshot: DailyLeaderboardSnapshot = {
      dateKey,
      timezone: tz,
      closedAt: new Date().toISOString(),
      totalStudyMinutes: rows.reduce((sum, r) => sum + r.studyMinutes, 0),
      participantsCount: rows.length,
      top3: rows.slice(0, 3).map(r => ({ ...r, xp: r.studyScore })),
      rankings: rows.map(r => ({ ...r, xp: r.studyScore })),
    };
    this.state.dailySnapshots.unshift(snapshot);
    if (rows[0]) this.state.leaderboardNotifications.unshift({ id: `notif-daily-winner-${dateKey}-${rows[0].userId}`, userId: rows[0].userId, title: 'Daily Winner', message: `You finished #1 on the ${dateKey} NOTIQ leaderboard.`, createdAt: new Date().toISOString(), read: false });
    rows.slice(0, 3).forEach(row => {
      if (row.rank > 1) this.state.leaderboardNotifications.unshift({ id: `notif-daily-top3-${dateKey}-${row.userId}`, userId: row.userId, title: 'Top 3 Finish', message: `You finished #${row.rank} on the ${dateKey} NOTIQ leaderboard.`, createdAt: new Date().toISOString(), read: false });
    });
    for (const row of rows) {
      const previous = this.state.leaderboardSnapshots.find(s => s.periodType === 'daily' && s.periodKey === dateKey && s.userId === row.userId);
      const bestDaily = this.state.leaderboardHistory.filter(h => h.userId === row.userId && h.periodType === 'daily').reduce((best, h) => Math.min(best, h.finalRank), Infinity);
      this.state.leaderboardHistory.push({
        id: `lbh-daily-${dateKey}-${row.userId}`,
        periodType: 'daily', periodKey: dateKey, userId: row.userId,
        finalRank: row.rank, studyMinutes: row.studyMinutes, studyScore: row.studyScore,
        streak: row.streak, rankMovement: previous ? previous.rankMovement : 0,
        personalBest: row.studyMinutes > 0 && row.rank < bestDaily,
        createdAt: new Date().toISOString(),
      });
    }
    return snapshot;
  }

  // --- Recorded Study Sessions (server validates and splits sessions at midnight) ---
  public recordStudySession(input: RecordedStudySession): { accepted: boolean; sessionIds: string[]; countedSeconds: number; reason?: string } {
    const now = new Date();
    const tz = DAILY_RESET_TIMEZONE;
    const maxDailySeconds = Math.max(1, this.state.leaderboardRules.maxDailyHoursCap || 12) * 3600;
    const student = this.state.users.find(u => u.id === input.userId);
    if (!student || student.status !== 'ACTIVE') return { accepted: false, sessionIds: [], countedSeconds: 0, reason: 'User is not an active student.' };
    if (!input.id || !input.startTime || !input.endTime) return { accepted: false, sessionIds: [], countedSeconds: 0, reason: 'Session timestamps are required.' };
    if (input.completedNormally === false || input.interrupted) return { accepted: false, sessionIds: [], countedSeconds: 0, reason: 'Only completed study sessions count.' };
    if (this.state.studySessions.some(s => s.id === input.id || s.id.startsWith(`${input.id}:`))) return { accepted: true, sessionIds: [], countedSeconds: 0, reason: 'Duplicate session ignored.' };

    const start = new Date(input.startTime);
    const end = new Date(input.endTime);
    const clientDuration = Number(input.duration);
    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start) return { accepted: false, sessionIds: [], countedSeconds: 0, reason: 'Invalid session time range.' };
    if (end.getTime() > now.getTime() + 60_000) return { accepted: false, sessionIds: [], countedSeconds: 0, reason: 'Future session timestamps are not accepted.' };
    const durationSeconds = Math.floor((end.getTime() - start.getTime()) / 1000);
    if (durationSeconds < 15 || !Number.isFinite(clientDuration) || Math.abs(clientDuration - durationSeconds) > 5) return { accepted: false, sessionIds: [], countedSeconds: 0, reason: 'Session duration does not match server-validated timestamps.' };
    if (durationSeconds > maxDailySeconds) return { accepted: false, sessionIds: [], countedSeconds: 0, reason: 'Session exceeds the configured daily study limit.' };

    const overlap = this.state.studySessions.some(s => s.userId === input.userId && new Date(s.startTime) < end && new Date(s.endTime) > start);
    if (overlap) return { accepted: false, sessionIds: [], countedSeconds: 0, reason: 'Overlapping study session detected.' };

    // Split at every Asia/Dhaka calendar midnight so all downstream analytics use the same allocation.
    const segments: RecordedStudySession[] = [];
    let cursor = start;
    let segmentIndex = 0;
    while (cursor < end) {
      const dateKey = getDateKeyInTimezone(cursor, tz);
      let probe = new Date(cursor.getTime() + 60_000);
      while (probe < end && getDateKeyInTimezone(probe, tz) === dateKey) probe = new Date(probe.getTime() + 60_000);
      // Find the first instant after cursor that belongs to the next date by binary search.
      let segmentEnd = end;
      if (getDateKeyInTimezone(end, tz) !== dateKey) {
        let lo = cursor.getTime(), hi = end.getTime();
        for (let i = 0; i < 40; i++) {
          const mid = Math.floor((lo + hi) / 2);
          if (getDateKeyInTimezone(new Date(mid), tz) === dateKey) lo = mid; else hi = mid;
        }
        segmentEnd = new Date(hi);
      }
      const segSeconds = Math.floor((segmentEnd.getTime() - cursor.getTime()) / 1000);
      if (segSeconds > 0) {
        segments.push({ ...input, id: segments.length === 0 ? input.id : `${input.id}:${dateKey}`, startTime: cursor.toISOString(), endTime: segmentEnd.toISOString(), duration: segSeconds, dateString: dateKey, createdAt: now.toISOString() });
      }
      cursor = segmentEnd;
      segmentIndex++;
      if (segmentIndex > 3) break;
    }

    const existingDaySeconds: Record<string, number> = {};
    for (const s of this.state.studySessions.filter(s => s.userId === input.userId)) {
      existingDaySeconds[s.dateString] = (existingDaySeconds[s.dateString] || 0) + s.duration;
    }
    let countedSeconds = 0;
    const acceptedSegments: RecordedStudySession[] = [];
    for (const segment of segments) {
      const remaining = Math.max(0, maxDailySeconds - (existingDaySeconds[segment.dateString] || 0));
      const allowed = Math.min(segment.duration, remaining);
      if (allowed <= 0) continue;
      acceptedSegments.push({ ...segment, duration: allowed });
      existingDaySeconds[segment.dateString] = (existingDaySeconds[segment.dateString] || 0) + allowed;
      countedSeconds += allowed;
    }
    if (!acceptedSegments.length) return { accepted: false, sessionIds: [], countedSeconds: 0, reason: 'Daily leaderboard limit has already been reached.' };

    this.state.studySessions.unshift(...acceptedSegments);
    student.totalStudyHours = Math.round((student.totalStudyHours + countedSeconds / 3600) * 10) / 10;
    student.sessionsCount += 1;
    student.leaguePoints += Math.round((countedSeconds / 60) * (this.state.leaderboardRules.xpToPointsRatio || 1));
    student.lastActiveAt = now.toISOString();

    const periods: Array<'daily' | 'weekly' | 'monthly' | 'all-time'> = ['daily', 'weekly', 'monthly', 'all-time'];
    periods.forEach(period => this.persistLiveSnapshot(period, this.getRealRankings(period)));
    this.save();
    return { accepted: true, sessionIds: acceptedSegments.map(s => s.id), countedSeconds };
  }

  // --- Daily / period leaderboards ---
  public checkAndTriggerDailyReset(): boolean {
    const tz = DAILY_RESET_TIMEZONE;
    const todayKey = getDateKeyInTimezone(new Date(), tz);
    const lastReset = this.state.leaderboardRules.lastDailyResetDate;
    if (!lastReset) {
      this.state.leaderboardRules.lastDailyResetDate = todayKey;
      this.save();
      return false;
    }
    if (lastReset >= todayKey) return false;
    let key = lastReset;
    while (key < todayKey) {
      this.finalizeDailyPeriod(key);
      key = shiftDateKey(key, 1);
    }
    this.state.leaderboardRules.lastDailyResetDate = todayKey;
    this.save();
    return true;
  }

  public triggerDailyReset(dateKeyToClose?: string): DailyLeaderboardSnapshot {
    const tz = DAILY_RESET_TIMEZONE;
    const targetDateKey = dateKeyToClose || shiftDateKey(getDateKeyInTimezone(new Date(), tz), -1);
    const snapshot = this.finalizeDailyPeriod(targetDateKey);
    const todayKey = getDateKeyInTimezone(new Date(), tz);
    if (targetDateKey < todayKey) this.state.leaderboardRules.lastDailyResetDate = todayKey;
    this.save();
    this.logAudit({ adminId: 'system', adminUsername: 'SYSTEM', role: 'SYSTEM', action: 'DAILY_LEADERBOARD_RESET', target: `Snapshot: ${targetDateKey}`, status: 'SUCCESS', metadata: { dateKey: targetDateKey, timezone: tz, totalMinutes: snapshot.totalStudyMinutes, participants: snapshot.participantsCount } });
    return snapshot;
  }

  public finalizeWeeklyLeague(referenceDate = new Date()): void {
    const tz = DAILY_RESET_TIMEZONE;
    const refKey = getDateKeyInTimezone(referenceDate, tz);
    const d = new Date(`${refKey}T12:00:00Z`);
    d.setUTCDate(d.getUTCDate() - 7);
    const bounds = this.getPeriodBounds('weekly', d);
    const leagueId = `league-${bounds.periodKey}`;
    if (this.state.weeklyLeagues.some(l => l.id === leagueId && l.status === 'COMPLETED')) return;
    const rows = this.getRealRankings('weekly', d);
    const tiers = this.state.leaderboardRules.leagueTiers || ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond'];
    const league = tiers.map(t => ({ tier: t, users: rows.filter(r => r.tier === t) }));
    const createdAt = new Date().toISOString();
    const leagueRecord: WeeklyLeague = { id: leagueId, name: `NOTIQ League ${bounds.periodKey}`, startDate: bounds.startKey, endDate: bounds.endKey, tier: 'ALL', status: 'COMPLETED', createdAt };
    this.state.weeklyLeagues.unshift(leagueRecord);
    for (const group of league) {
      const count = group.users.length;
      if (count < (this.state.leaderboardRules.minimumParticipants || 5)) continue;
      const promoteCount = Math.max(1, Math.floor(count * (this.state.leaderboardRules.promotionPercentage || 20) / 100));
      const demoteCount = Math.max(1, Math.floor(count * (this.state.leaderboardRules.demotionPercentage || 20) / 100));
      const tierIndex = tiers.indexOf(group.tier);
      const ordered = [...group.users].sort((a, b) => a.rank - b.rank);
      for (let i = 0; i < ordered.length; i++) {
        const row = ordered[i];
        const user = this.state.users.find(u => u.id === row.userId);
        if (!user) continue;
        let status: LeagueMember['status'] = 'RETAINED';
        let nextTier = user.league;
        if (tierIndex < tiers.length - 1 && i < promoteCount) {
          nextTier = tiers[tierIndex + 1] as StudentUser['league'];
          status = 'PROMOTED';
          this.state.leaderboardNotifications.unshift({ id: `notif-${leagueId}-up-${row.userId}`, userId: row.userId, title: 'League Promotion', message: `You were promoted to the ${nextTier} NOTIQ League.`, createdAt, read: false });
        } else if (tierIndex > 0 && i >= ordered.length - demoteCount) {
          nextTier = tiers[tierIndex - 1] as StudentUser['league'];
          status = 'DEMOTED';
          this.state.leaderboardNotifications.unshift({ id: `notif-${leagueId}-down-${row.userId}`, userId: row.userId, title: 'League Update', message: `Your NOTIQ League position changed to ${nextTier} for the next week.`, createdAt, read: false });
        } else {
          this.state.leaderboardNotifications.unshift({ id: `notif-${leagueId}-stay-${row.userId}`, userId: row.userId, title: 'League Position Maintained', message: `Your ${user.league} NOTIQ League position has been maintained.`, createdAt, read: false });
        }
        user.league = nextTier;
        this.state.leagueMembers.push({ id: `lm-${leagueId}-${row.userId}`, leagueId, userId: row.userId, joinedAt: createdAt, status });
      }
    }
    this.state.leaderboardNotifications = this.state.leaderboardNotifications.slice(0, 1000);
    this.save();
  }

  public getLeaderboardNotifications(userId: string) {
    return this.state.leaderboardNotifications.filter(n => n.userId === userId).slice(0, 50);
  }

  public markLeaderboardNotificationsRead(userId: string) {
    this.state.leaderboardNotifications.forEach(n => { if (n.userId === userId) n.read = true; });
    this.save();
  }

  public getPeriodLeaderboard(periodType: 'daily' | 'weekly' | 'monthly' | 'all-time', targetUserId = '') {
    this.checkAndTriggerDailyReset();
    const tz = DAILY_RESET_TIMEZONE;
    const bounds = this.getPeriodBounds(periodType);
    const rows = this.getRealRankings(periodType);
    const current = rows.find(r => r.userId === targetUserId) || null;
    const next = current ? rows.find(r => r.rank === current.rank - 1) : null;
    const movementRecord = current ? this.state.leaderboardSnapshots.find(s => s.periodType === periodType && s.periodKey === bounds.periodKey && s.userId === targetUserId) : undefined;
    this.persistLiveSnapshot(periodType, rows);
    const nextRankGapMinutes = current && next ? Math.max(0, next.studyMinutes - current.studyMinutes) : 0;
    const historyForUser = this.state.leaderboardHistory.filter(h => h.userId === targetUserId && h.periodType === periodType);
    const personalBest = {
      bestRank: current ? Math.min(current.rank, ...historyForUser.map(h => h.finalRank)) : (historyForUser.length ? Math.min(...historyForUser.map(h => h.finalRank)) : null),
      bestStudyMinutes: current ? Math.max(current.studyMinutes, ...historyForUser.map(h => h.studyMinutes)) : (historyForUser.length ? Math.max(...historyForUser.map(h => h.studyMinutes)) : 0),
    };
    return {
      periodType,
      periodKey: bounds.periodKey,
      startDate: bounds.startKey,
      endDate: bounds.endKey,
      todayKey: getDateKeyInTimezone(new Date(), tz),
      timezone: tz,
      secondsUntilReset: getSecondsUntilMidnightInTimezone(tz),
      totalStudyMinutes: rows.reduce((sum, r) => sum + r.studyMinutes, 0),
      participantsCount: rows.length,
      rankings: rows.map(r => ({ ...r, xp: r.studyScore, isCurrentUser: r.userId === targetUserId, change: r.userId === targetUserId ? (movementRecord?.rankMovement || 0) : 0 })),
      currentUser: current ? { ...current, xp: current.studyScore, rankMovement: movementRecord?.rankMovement || 0, nextRankGapMinutes } : null,
      nextRankGapMinutes,
      personalBest,
      previousSnapshotAvailable: !!movementRecord,
      friends: [],
      groups: [],
      rules: this.state.leaderboardRules,
    };
  }

  public getDailyLeaderboard(targetUserId: string = '') {
    const data = this.getPeriodLeaderboard('daily', targetUserId);
    return {
      ...data,
      yesterdaySnapshot: this.state.dailySnapshots[0] || null,
    };
  }

  public getDailySnapshots(): DailyLeaderboardSnapshot[] {
    return this.state.dailySnapshots;
  }
  public getLeaderboardHistory(periodType?: 'daily' | 'weekly' | 'monthly' | 'all-time') {
    return periodType ? this.state.leaderboardHistory.filter(h => h.periodType === periodType) : this.state.leaderboardHistory;
  }


  // Real statistics computation
  public getDashboardStats() {
    const totalUsers = this.state.users.length;
    const activeUsers = this.state.users.filter(u => u.status === 'ACTIVE').length;
    const suspendedUsers = this.state.users.filter(u => u.status === 'SUSPENDED').length;
    
    // New users in past 30 days
    const thirtyDaysAgo = Date.now() - 30 * 86400000;
    const newUsers = this.state.users.filter(u => new Date(u.joinedAt).getTime() > thirtyDaysAgo).length;

    // Total hours and sessions summed across all real student records
    const totalStudyHours = Math.round(this.state.users.reduce((acc, u) => acc + u.totalStudyHours, 0) * 10) / 10;
    const totalStudySessions = this.state.users.reduce((acc, u) => acc + u.sessionsCount, 0);

    // Active streaks
    const activeStreaksCount = this.state.users.filter(u => u.currentStreak > 0).length;

    // Achievements unlocked total
    const totalAchievementsUnlocked = this.state.users.reduce((acc, u) => acc + u.achievementsUnlocked, 0);

    // Active challenges
    const activeChallenges = this.state.challenges.filter(c => c.status === 'ACTIVE').length;

    // Current league users
    const currentLeagueUsers = this.state.users.filter(u => u.status === 'ACTIVE' && u.leaguePoints > 0).length;

    return {
      totalUsers,
      activeUsers,
      suspendedUsers,
      newUsers,
      totalStudyHours,
      totalStudySessions,
      activeStreaksCount,
      totalAchievementsUnlocked,
      totalAchievementsConfigured: this.state.achievements.length,
      activeChallenges,
      totalChallenges: this.state.challenges.length,
      currentLeagueUsers,
      pendingReportsCount: this.state.reports.filter(r => r.status === 'PENDING').length,
      adminsCount: this.state.admins.length,
      systemStatus: {
        uptimeSeconds: Math.floor(process.uptime()),
        nodeVersion: process.version,
        antiCheatMode: this.state.settings.antiCheatMode,
        maintenanceMode: this.state.settings.maintenanceMode,
        databaseHealthy: true,
        lastBackup: new Date().toISOString(),
      },
    };
  }
}

export const adminStore = new AdminStore();
