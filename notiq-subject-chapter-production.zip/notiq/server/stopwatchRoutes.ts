import { Router } from 'express';
import { adminStore } from './adminStore';

export const stopwatchRouter = Router();

const requireUserId = (value: unknown, res: any) => {
  const id = String(value || '').trim();
  if (!id) { res.status(400).json({ error: 'User ID is required.' }); return null; }
  if (!adminStore.isRegisteredStudent(id)) {
    res.status(403).json({ error: 'Device-only guest identities cannot use server account storage.' });
    return null;
  }
  return id;
};


// GET /api/stopwatch/active - Fetch active stopwatch session for a user
stopwatchRouter.get('/active', (req, res) => {
  const userId = String(req.query.userId || '').trim();
  if (!userId || !adminStore.isRegisteredStudent(userId)) return res.json({ active: false, session: null });
  const activeSession = adminStore.getActiveStopwatch(userId);

  if (!activeSession) {
    return res.json({ active: false, session: null });
  }

  res.json({
    active: true,
    session: activeSession,
  });
});

// POST /api/stopwatch/start - Start or restart a persistent stopwatch session
stopwatchRouter.post('/start', (req, res) => {
  const {
    userId,
    sessionId,
    subjectId,
    chapterId,
    sessionType,
    taskTitle,
    note,
    tags,
    force = false,
  } = req.body;
  const resolvedUserId = requireUserId(userId, res);
  if (!resolvedUserId) return;

  if (!subjectId) {
    return res.status(400).json({ error: 'Subject ID is required to start a study session.' });
  }

  const result = adminStore.startStopwatch({
    userId: resolvedUserId,
    sessionId,
    subjectId,
    chapterId,
    sessionType,
    taskTitle,
    note,
    tags,
    force,
  });

  if (result.conflict) {
    return res.status(409).json({
      error: 'An active study session is already running.',
      conflict: true,
      existingSession: result.existingSession,
    });
  }

  res.json({
    success: true,
    session: result.session,
  });
});

// POST /api/stopwatch/pause - Pause the running stopwatch
stopwatchRouter.post('/pause', (req, res) => {
  const { userId } = req.body;
  const resolvedUserId = requireUserId(userId, res);
  if (!resolvedUserId) return;
  const session = adminStore.pauseStopwatch(resolvedUserId);

  if (!session) {
    return res.status(404).json({ error: 'No active running stopwatch found to pause.' });
  }

  res.json({
    success: true,
    session,
  });
});

// POST /api/stopwatch/resume - Resume the paused stopwatch
stopwatchRouter.post('/resume', (req, res) => {
  const { userId } = req.body;
  const resolvedUserId = requireUserId(userId, res);
  if (!resolvedUserId) return;
  const session = adminStore.resumeStopwatch(resolvedUserId);

  if (!session) {
    return res.status(404).json({ error: 'No paused stopwatch found to resume.' });
  }

  res.json({
    success: true,
    session,
  });
});

// POST /api/stopwatch/lap - Add split lap record
stopwatchRouter.post('/lap', (req, res) => {
  const { userId, lapTime, totalTime } = req.body;
  const resolvedUserId = requireUserId(userId, res);
  if (!resolvedUserId) return;
  const session = adminStore.addStopwatchLap(
    resolvedUserId,
    lapTime && totalTime ? { lapTime: Number(lapTime), totalTime: Number(totalTime) } : undefined
  );

  if (!session) {
    return res.status(404).json({ error: 'No active stopwatch found to record lap.' });
  }

  res.json({
    success: true,
    session,
  });
});

// POST /api/stopwatch/finish - Complete and archive active stopwatch session
stopwatchRouter.post('/finish', (req, res) => {
  const { userId, interrupted = false } = req.body;
  const resolvedUserId = requireUserId(userId, res);
  if (!resolvedUserId) return;
  const result = adminStore.finishStopwatch(resolvedUserId, Boolean(interrupted));

  if (!result) {
    return res.status(404).json({ error: 'No active stopwatch found to finish.' });
  }

  res.json({
    success: true,
    session: result.session,
    elapsedSeconds: result.elapsedSeconds,
  });
});

// POST /api/stopwatch/cancel - Cancel and discard active stopwatch session
stopwatchRouter.post('/cancel', (req, res) => {
  const { userId } = req.body;
  const resolvedUserId = requireUserId(userId, res);
  if (!resolvedUserId) return;
  const cancelled = adminStore.cancelStopwatch(resolvedUserId);

  res.json({
    success: true,
    cancelled,
  });
});

// POST /api/stopwatch/sync - Offline recovery reconciliation
stopwatchRouter.post('/sync', (req, res) => {
  const { userId, session } = req.body;
  const resolvedUserId = requireUserId(userId, res);
  if (!resolvedUserId) return;
  if (!session) {
    return res.status(400).json({ error: 'Session payload is required for sync.' });
  }

  const updatedSession = adminStore.syncStopwatch(resolvedUserId, session);

  res.json({
    success: true,
    session: updatedSession,
  });
});
