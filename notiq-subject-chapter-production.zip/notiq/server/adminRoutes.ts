import { Router, type Response } from 'express';
import {
  adminStore,
  hashPassword,
  verifyPassword,
  type AdminUser,
  type AdminRole,
} from './adminStore';
import {
  createSession,
  revokeSession,
  requireAdminAuth,
  checkRateLimit,
  recordFailedAttempt,
  clearFailedAttempts,
  validatePasswordStrength,
  extractToken,
  type AuthenticatedAdminRequest,
} from './adminAuth';

export const adminRouter = Router();

// Helper to sanitize admin user for API responses (NEVER expose hashes or salts!)
function sanitizeAdmin(admin: AdminUser) {
  return {
    id: admin.id,
    username: admin.username,
    name: admin.name,
    email: admin.email,
    role: admin.role,
    isInitialPassword: admin.isInitialPassword,
    status: admin.status,
    createdAt: admin.createdAt,
    lastLoginAt: admin.lastLoginAt,
  };
}

// -------------------------------------------------------------
// AUTHENTICATION & LOGIN
// -------------------------------------------------------------

// POST /api/admin/login
adminRouter.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const rateLimitKey = `${ip}_${(username || '').toLowerCase()}`;

  if (!username || !password) {
    res.status(400).json({ error: 'Username and password are required.' });
    return;
  }

  // Check rate limiting / lockout
  const rateCheck = checkRateLimit(rateLimitKey);
  if (!rateCheck.allowed) {
    adminStore.logAudit({
      adminId: 'unknown',
      adminUsername: username,
      role: 'UNKNOWN',
      action: 'LOGIN_BLOCKED_RATE_LIMIT',
      target: username,
      status: 'FAILED',
      ip,
      metadata: { retryAfterSeconds: rateCheck.retryAfterSeconds },
    });
    res.status(429).json({
      error: `Too many failed login attempts. Account temporarily locked for security. Please try again in ${rateCheck.retryAfterSeconds} seconds.`,
      code: 'RATE_LIMITED',
      retryAfterSeconds: rateCheck.retryAfterSeconds,
    });
    return;
  }

  const admin = adminStore.findAdminByUsername(username);

  // If user does not exist or password does not match
  if (!admin || !verifyPassword(password, admin.passwordHash, admin.passwordSalt)) {
    const attemptStatus = recordFailedAttempt(rateLimitKey);
    adminStore.logAudit({
      adminId: admin ? admin.id : 'unknown',
      adminUsername: username,
      role: admin ? admin.role : 'UNKNOWN',
      action: 'ADMIN_LOGIN_FAILED',
      target: username,
      status: 'FAILED',
      ip,
      metadata: { remainingAttempts: attemptStatus.remainingAttempts },
    });

    if (attemptStatus.locked) {
      res.status(429).json({
        error: 'Too many consecutive failed attempts. Your login access has been suspended for 15 minutes.',
        code: 'ACCOUNT_LOCKED',
      });
      return;
    }

    res.status(401).json({
      error: `Invalid administrative credentials. ${attemptStatus.remainingAttempts} attempt(s) remaining before security lockout.`,
      code: 'INVALID_CREDENTIALS',
      remainingAttempts: attemptStatus.remainingAttempts,
    });
    return;
  }

  // Account disabled check
  if (admin.status === 'DISABLED') {
    adminStore.logAudit({
      adminId: admin.id,
      adminUsername: admin.username,
      role: admin.role,
      action: 'LOGIN_ATTEMPT_DISABLED_ACCOUNT',
      target: admin.username,
      status: 'FAILED',
      ip,
    });
    res.status(403).json({
      error: 'This administrator account has been disabled by a Super Administrator.',
      code: 'ACCOUNT_DISABLED',
    });
    return;
  }

  // Login successful
  clearFailedAttempts(rateLimitKey);
  const nowStr = new Date().toISOString();
  adminStore.updateAdmin(admin.id, {
    lastLoginAt: nowStr,
    failedLoginAttempts: 0,
  });

  const session = createSession(admin);

  // Set secure cookie
  res.cookie('studiq_admin_session', session.token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 24 * 60 * 60 * 1000,
    path: '/',
  });

  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'ADMIN_LOGIN',
    target: admin.username,
    status: 'SUCCESS',
    ip,
    metadata: { isInitialPassword: admin.isInitialPassword },
  });

  res.json({
    token: session.token,
    user: sanitizeAdmin(admin),
    warning: admin.isInitialPassword
      ? "You're using the initial admin password. Change your password for security."
      : null,
  });
});

// POST /api/admin/logout
adminRouter.post('/logout', (req, res) => {
  const token = extractToken(req);
  if (token) {
    revokeSession(token);
  }
  res.clearCookie('studiq_admin_session', { path: '/' });
  res.json({ success: true, message: 'Logged out successfully.' });
});

// GET /api/admin/me
adminRouter.get('/me', requireAdminAuth(), (req: AuthenticatedAdminRequest, res: Response) => {
  const admin = req.adminUser!;
  res.json({
    user: sanitizeAdmin(admin),
    isInitialPassword: admin.isInitialPassword,
    permissions: getPermissionsForRole(admin.role),
  });
});

function getPermissionsForRole(role: AdminRole): string[] {
  switch (role) {
    case 'SUPER_ADMIN':
      return [
        'MANAGE_USERS',
        'SUSPEND_USERS',
        'MANAGE_ADMINS',
        'CHANGE_ADMIN_ROLES',
        'RESET_ADMIN_PASSWORDS',
        'MANAGE_LEADERBOARD',
        'MANAGE_CHALLENGES',
        'MANAGE_ACHIEVEMENTS',
        'MANAGE_ANNOUNCEMENTS',
        'PLATFORM_SETTINGS',
        'SECURITY_SETTINGS',
        'VIEW_AUDIT_LOGS',
      ];
    case 'ADMIN':
      return [
        'MANAGE_USERS',
        'SUSPEND_USERS',
        'MANAGE_LEADERBOARD',
        'MANAGE_CHALLENGES',
        'MANAGE_ACHIEVEMENTS',
        'MANAGE_ANNOUNCEMENTS',
        'VIEW_AUDIT_LOGS',
      ];
    case 'MODERATOR':
      return [
        'VIEW_USERS',
        'MANAGE_ANNOUNCEMENTS',
        'MANAGE_CHALLENGES',
        'VIEW_AUDIT_LOGS',
      ];
  }
}

// -------------------------------------------------------------
// PASSWORD MANAGEMENT
// -------------------------------------------------------------

// POST /api/admin/change-password
adminRouter.post('/change-password', requireAdminAuth(), (req: AuthenticatedAdminRequest, res: Response) => {
  const { currentPassword, newPassword, confirmNewPassword } = req.body || {};
  const admin = req.adminUser!;

  if (!currentPassword || !newPassword || !confirmNewPassword) {
    res.status(400).json({ error: 'All password fields are required.' });
    return;
  }

  // Verify current password
  if (!verifyPassword(currentPassword, admin.passwordHash, admin.passwordSalt)) {
    adminStore.logAudit({
      adminId: admin.id,
      adminUsername: admin.username,
      role: admin.role,
      action: 'PASSWORD_CHANGE_FAILED_CURRENT_MISMATCH',
      target: admin.username,
      status: 'FAILED',
    });
    res.status(400).json({ error: 'Current password is incorrect.' });
    return;
  }

  // Match check
  if (newPassword !== confirmNewPassword) {
    res.status(400).json({ error: 'New password and confirmation do not match.' });
    return;
  }

  // Cannot reuse current password
  if (currentPassword === newPassword) {
    res.status(400).json({ error: 'New password must be different from your current password.' });
    return;
  }

  // Validate password strength
  const strength = validatePasswordStrength(newPassword);
  if (!strength.valid) {
    res.status(400).json({ error: strength.reason });
    return;
  }

  // Hash new password securely
  const { hash, salt } = hashPassword(newPassword);

  adminStore.updateAdmin(admin.id, {
    passwordHash: hash,
    passwordSalt: salt,
    isInitialPassword: false,
  });

  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'PASSWORD_CHANGED',
    target: admin.username,
    status: 'SUCCESS',
    metadata: { initialPasswordResolved: admin.isInitialPassword },
  });

  res.json({
    success: true,
    message: 'Your administrator password has been successfully updated.',
  });
});

// -------------------------------------------------------------
// DASHBOARD & REAL STATISTICS
// -------------------------------------------------------------

// GET /api/admin/dashboard
adminRouter.get('/dashboard', requireAdminAuth(), (_req, res) => {
  const stats = adminStore.getDashboardStats();
  res.json(stats);
});

// -------------------------------------------------------------
// USER MANAGEMENT
// -------------------------------------------------------------

// GET /api/admin/users
adminRouter.get('/users', requireAdminAuth(), (req, res) => {
  const { status, search } = req.query as { status?: string; search?: string };
  let users = adminStore.getUsers();

  if (status && status !== 'ALL') {
    users = users.filter(u => u.status === status.toUpperCase());
  }

  if (search && search.trim()) {
    const q = search.toLowerCase().trim();
    users = users.filter(
      u =>
        u.username.toLowerCase().includes(q) ||
        u.name.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q)
    );
  }

  res.json(users);
});

// POST /api/admin/users/:id/action
adminRouter.post('/users/:id/action', requireAdminAuth(['SUPER_ADMIN', 'ADMIN']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { action, reason } = req.body || {};
  const admin = req.adminUser!;

  const user = adminStore.findUserById(id);
  if (!user) {
    res.status(404).json({ error: 'Student user not found.' });
    return;
  }

  if (action === 'suspend') {
    adminStore.updateUser(id, {
      status: 'SUSPENDED',
      suspendReason: reason || 'Suspended by platform administrator for policy review.',
    });
    adminStore.logAudit({
      adminId: admin.id,
      adminUsername: admin.username,
      role: admin.role,
      action: 'USER_SUSPENDED',
      target: user.username,
      status: 'SUCCESS',
      metadata: { reason },
    });
    res.json({ success: true, message: `User ${user.username} has been suspended.` });
    return;
  }

  if (action === 'unsuspend') {
    adminStore.updateUser(id, {
      status: 'ACTIVE',
      suspendReason: undefined,
    });
    adminStore.logAudit({
      adminId: admin.id,
      adminUsername: admin.username,
      role: admin.role,
      action: 'USER_UNSUSPENDED',
      target: user.username,
      status: 'SUCCESS',
    });
    res.json({ success: true, message: `User ${user.username} status restored to active.` });
    return;
  }

  if (action === 'reset_streak') {
    adminStore.updateUser(id, { currentStreak: 0 });
    adminStore.logAudit({
      adminId: admin.id,
      adminUsername: admin.username,
      role: admin.role,
      action: 'USER_STREAK_RESET',
      target: user.username,
      status: 'SUCCESS',
      metadata: { previousStreak: user.currentStreak },
    });
    res.json({ success: true, message: `Streak for ${user.username} has been reset to 0.` });
    return;
  }

  if (action === 'delete') {
    if (admin.role !== 'SUPER_ADMIN') {
      res.status(403).json({ error: 'Only Super Administrators can permanently delete user records.' });
      return;
    }
    adminStore.removeUser(id);
    adminStore.logAudit({
      adminId: admin.id,
      adminUsername: admin.username,
      role: admin.role,
      action: 'USER_DELETED',
      target: user.username,
      status: 'SUCCESS',
    });
    res.json({ success: true, message: `User record for ${user.username} permanently deleted.` });
    return;
  }

  res.status(400).json({ error: 'Invalid user action specified.' });
});

// POST /api/admin/users (Create student user)
adminRouter.post('/users', requireAdminAuth(['SUPER_ADMIN', 'ADMIN']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { username, name, email, league } = req.body || {};
  const admin = req.adminUser!;

  if (!username || !name || !email) {
    res.status(400).json({ error: 'Username, name, and email are required.' });
    return;
  }

  const newUser = {
    id: `user-${Date.now()}`,
    username: username.toLowerCase().trim(),
    name: name.trim(),
    email: email.toLowerCase().trim(),
    avatar: '',
    totalStudyHours: 0,
    sessionsCount: 0,
    currentStreak: 0,
    achievementsUnlocked: 0,
    league: (league || 'Bronze') as any,
    leaguePoints: 0,
    status: 'ACTIVE' as const,
    joinedAt: new Date().toISOString(),
    lastActiveAt: new Date().toISOString(),
    reportsCount: 0,
  };

  adminStore.addUser(newUser);
  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'USER_CREATED',
    target: newUser.username,
    status: 'SUCCESS',
  });

  res.status(201).json(newUser);
});

// GET /api/admin/user-reports
adminRouter.get('/user-reports', requireAdminAuth(), (_req, res) => {
  res.json(adminStore.getReports());
});

// POST /api/admin/user-reports/:id/resolve
adminRouter.post('/user-reports/:id/resolve', requireAdminAuth(['SUPER_ADMIN', 'ADMIN', 'MODERATOR']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { status, resolutionNote } = req.body || {};
  const admin = req.adminUser!;

  const updated = adminStore.updateReport(id, {
    status: status || 'RESOLVED',
    resolvedBy: admin.username,
    resolvedAt: new Date().toISOString(),
    resolutionNote: resolutionNote || 'Reviewed and addressed by administration.',
  });

  if (!updated) {
    res.status(404).json({ error: 'Report not found.' });
    return;
  }

  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'USER_REPORT_RESOLVED',
    target: updated.targetUsername,
    status: 'SUCCESS',
    metadata: { resolutionNote, reportId: id },
  });

  res.json(updated);
});

// -------------------------------------------------------------
// ADMIN ACCOUNT MANAGEMENT (SUPER ADMIN ONLY)
// -------------------------------------------------------------

// GET /api/admin/admins
adminRouter.get('/admins', requireAdminAuth(['SUPER_ADMIN', 'ADMIN']), (_req, res) => {
  const admins = adminStore.getAdmins().map(sanitizeAdmin);
  res.json(admins);
});

// POST /api/admin/admins
adminRouter.post('/admins', requireAdminAuth(['SUPER_ADMIN']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { username, name, email, role, initialPassword } = req.body || {};
  const currentAdmin = req.adminUser!;

  if (!username || !name || !email || !role || !initialPassword) {
    res.status(400).json({ error: 'All fields (username, name, email, role, initialPassword) are required.' });
    return;
  }

  if (!['SUPER_ADMIN', 'ADMIN', 'MODERATOR'].includes(role)) {
    res.status(400).json({ error: 'Role must be SUPER_ADMIN, ADMIN, or MODERATOR.' });
    return;
  }

  const existing = adminStore.findAdminByUsername(username);
  if (existing) {
    res.status(400).json({ error: 'An administrator with this username already exists.' });
    return;
  }

  const strength = validatePasswordStrength(initialPassword);
  if (!strength.valid) {
    res.status(400).json({ error: strength.reason });
    return;
  }

  const { hash, salt } = hashPassword(initialPassword);
  const newAdmin: AdminUser = {
    id: `admin_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    username: username.toLowerCase().trim(),
    name: name.trim(),
    email: email.toLowerCase().trim(),
    role,
    passwordHash: hash,
    passwordSalt: salt,
    isInitialPassword: true,
    status: 'ACTIVE',
    createdAt: new Date().toISOString(),
    failedLoginAttempts: 0,
  };

  adminStore.addAdmin(newAdmin);

  adminStore.logAudit({
    adminId: currentAdmin.id,
    adminUsername: currentAdmin.username,
    role: currentAdmin.role,
    action: 'ADMIN_CREATED',
    target: newAdmin.username,
    status: 'SUCCESS',
    metadata: { assignedRole: role },
  });

  res.status(201).json(sanitizeAdmin(newAdmin));
});

// PUT /api/admin/admins/:id
adminRouter.put('/admins/:id', requireAdminAuth(['SUPER_ADMIN']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { name, email, role, status } = req.body || {};
  const currentAdmin = req.adminUser!;

  const targetAdmin = adminStore.findAdminById(id);
  if (!targetAdmin) {
    res.status(404).json({ error: 'Administrator not found.' });
    return;
  }

  // Prevent super admin from demoting or disabling self
  if (targetAdmin.id === currentAdmin.id && (status === 'DISABLED' || (role && role !== 'SUPER_ADMIN'))) {
    res.status(400).json({ error: 'You cannot disable or demote your own Super Administrator account.' });
    return;
  }

  const updates: Partial<AdminUser> = {};
  if (name) updates.name = name.trim();
  if (email) updates.email = email.toLowerCase().trim();
  if (role && ['SUPER_ADMIN', 'ADMIN', 'MODERATOR'].includes(role)) {
    updates.role = role;
  }
  if (status && ['ACTIVE', 'DISABLED'].includes(status)) {
    updates.status = status;
  }

  const updated = adminStore.updateAdmin(id, updates);

  adminStore.logAudit({
    adminId: currentAdmin.id,
    adminUsername: currentAdmin.username,
    role: currentAdmin.role,
    action: updates.role ? 'ADMIN_ROLE_CHANGED' : (updates.status ? 'ADMIN_STATUS_CHANGED' : 'ADMIN_UPDATED'),
    target: targetAdmin.username,
    status: 'SUCCESS',
    metadata: updates,
  });

  res.json(sanitizeAdmin(updated!));
});

// POST /api/admin/admins/:id/reset-password
adminRouter.post('/admins/:id/reset-password', requireAdminAuth(['SUPER_ADMIN']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { newPassword } = req.body || {};
  const currentAdmin = req.adminUser!;

  const targetAdmin = adminStore.findAdminById(id);
  if (!targetAdmin) {
    res.status(404).json({ error: 'Administrator not found.' });
    return;
  }

  if (!newPassword) {
    res.status(400).json({ error: 'New password is required.' });
    return;
  }

  const strength = validatePasswordStrength(newPassword);
  if (!strength.valid) {
    res.status(400).json({ error: strength.reason });
    return;
  }

  const { hash, salt } = hashPassword(newPassword);
  adminStore.updateAdmin(id, {
    passwordHash: hash,
    passwordSalt: salt,
    isInitialPassword: true, // Forces password change on their next login
  });

  adminStore.logAudit({
    adminId: currentAdmin.id,
    adminUsername: currentAdmin.username,
    role: currentAdmin.role,
    action: 'ADMIN_PASSWORD_RESET',
    target: targetAdmin.username,
    status: 'SUCCESS',
  });

  res.json({ success: true, message: `Password reset for ${targetAdmin.username}. They will be prompted to change it upon login.` });
});

// DELETE /api/admin/admins/:id
adminRouter.delete('/admins/:id', requireAdminAuth(['SUPER_ADMIN']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const currentAdmin = req.adminUser!;

  if (id === currentAdmin.id) {
    res.status(400).json({ error: 'You cannot delete your own administrator account.' });
    return;
  }

  const targetAdmin = adminStore.findAdminById(id);
  if (!targetAdmin) {
    res.status(404).json({ error: 'Administrator not found.' });
    return;
  }

  // Check if target is last Super Admin
  if (targetAdmin.role === 'SUPER_ADMIN') {
    const superAdmins = adminStore.getAdmins().filter(a => a.role === 'SUPER_ADMIN' && a.id !== id);
    if (superAdmins.length === 0) {
      res.status(400).json({ error: 'Cannot delete the system root Super Administrator.' });
      return;
    }
  }

  adminStore.removeAdmin(id);

  adminStore.logAudit({
    adminId: currentAdmin.id,
    adminUsername: currentAdmin.username,
    role: currentAdmin.role,
    action: 'ADMIN_REMOVED',
    target: targetAdmin.username,
    status: 'SUCCESS',
  });

  res.json({ success: true, message: `Administrator ${targetAdmin.username} removed.` });
});

// -------------------------------------------------------------
// AUDIT LOGS
// -------------------------------------------------------------

// GET /api/admin/audit-logs
adminRouter.get('/audit-logs', requireAdminAuth(), (req, res) => {
  const { search, action, role } = req.query as { search?: string; action?: string; role?: string };
  let logs = adminStore.getAuditLogs();

  if (action && action !== 'ALL') {
    logs = logs.filter(l => l.action.toLowerCase() === action.toLowerCase());
  }

  if (role && role !== 'ALL') {
    logs = logs.filter(l => l.role.toLowerCase() === role.toLowerCase());
  }

  if (search && search.trim()) {
    const q = search.toLowerCase().trim();
    logs = logs.filter(
      l =>
        l.adminUsername.toLowerCase().includes(q) ||
        l.target.toLowerCase().includes(q) ||
        l.action.toLowerCase().includes(q) ||
        (l.metadata && JSON.stringify(l.metadata).toLowerCase().includes(q))
    );
  }

  res.json(logs);
});

// -------------------------------------------------------------
// CHALLENGES MANAGEMENT
// -------------------------------------------------------------

// GET /api/admin/challenges
adminRouter.get('/challenges', requireAdminAuth(), (_req, res) => {
  res.json(adminStore.getChallenges());
});

// POST /api/admin/challenges
adminRouter.post('/challenges', requireAdminAuth(['SUPER_ADMIN', 'ADMIN']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { title, description, targetType, targetValue, xpReward, badgeIcon, startDate, endDate } = req.body || {};
  const admin = req.adminUser!;

  if (!title || !description || !targetType || !targetValue || !xpReward) {
    res.status(400).json({ error: 'Title, description, targetType, targetValue, and xpReward are required.' });
    return;
  }

  const newChallenge = {
    id: `ch-${Date.now()}`,
    title: title.trim(),
    description: description.trim(),
    targetType,
    targetValue: Number(targetValue),
    xpReward: Number(xpReward),
    participantsCount: 0,
    completionsCount: 0,
    startDate: startDate || new Date().toISOString(),
    endDate: endDate || new Date(Date.now() + 7 * 86400000).toISOString(),
    status: 'ACTIVE' as const,
    badgeIcon: badgeIcon || 'Flame',
  };

  adminStore.addChallenge(newChallenge);

  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'CHALLENGE_CREATED',
    target: newChallenge.title,
    status: 'SUCCESS',
    metadata: { xpReward: newChallenge.xpReward },
  });

  res.status(201).json(newChallenge);
});

// PUT /api/admin/challenges/:id
adminRouter.put('/challenges/:id', requireAdminAuth(['SUPER_ADMIN', 'ADMIN']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const updates = req.body || {};
  const admin = req.adminUser!;

  const updated = adminStore.updateChallenge(id, updates);
  if (!updated) {
    res.status(404).json({ error: 'Challenge not found.' });
    return;
  }

  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'CHALLENGE_UPDATED',
    target: updated.title,
    status: 'SUCCESS',
    metadata: updates,
  });

  res.json(updated);
});

// DELETE /api/admin/challenges/:id
adminRouter.delete('/challenges/:id', requireAdminAuth(['SUPER_ADMIN', 'ADMIN']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const admin = req.adminUser!;

  const success = adminStore.deleteChallenge(id);
  if (!success) {
    res.status(404).json({ error: 'Challenge not found.' });
    return;
  }

  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'CHALLENGE_DELETED',
    target: id,
    status: 'SUCCESS',
  });

  res.json({ success: true, message: 'Challenge deleted successfully.' });
});

// -------------------------------------------------------------
// ACHIEVEMENTS MANAGEMENT
// -------------------------------------------------------------

// GET /api/admin/achievements
adminRouter.get('/achievements', requireAdminAuth(), (_req, res) => {
  res.json(adminStore.getAchievements());
});

// POST /api/admin/achievements
adminRouter.post('/achievements', requireAdminAuth(['SUPER_ADMIN', 'ADMIN']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { title, description, category, tier, xp, ruleMetric, ruleThreshold, icon } = req.body || {};
  const admin = req.adminUser!;

  if (!title || !description || !category || !tier || !xp || !ruleMetric || !ruleThreshold) {
    res.status(400).json({ error: 'All achievement fields are required.' });
    return;
  }

  const newAchievement = {
    id: `ach-${Date.now()}`,
    title: title.trim(),
    description: description.trim(),
    category,
    tier,
    xp: Number(xp),
    ruleMetric,
    ruleThreshold: Number(ruleThreshold),
    unlocksCount: 0,
    status: 'ACTIVE' as const,
    icon: icon || 'Sparkles',
  };

  adminStore.addAchievement(newAchievement);

  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'ACHIEVEMENT_CREATED',
    target: newAchievement.title,
    status: 'SUCCESS',
  });

  res.status(201).json(newAchievement);
});

// PUT /api/admin/achievements/:id
adminRouter.put('/achievements/:id', requireAdminAuth(['SUPER_ADMIN', 'ADMIN']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const updates = req.body || {};
  const admin = req.adminUser!;

  const updated = adminStore.updateAchievement(id, updates);
  if (!updated) {
    res.status(404).json({ error: 'Achievement not found.' });
    return;
  }

  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'ACHIEVEMENT_UPDATED',
    target: updated.title,
    status: 'SUCCESS',
    metadata: updates,
  });

  res.json(updated);
});

// -------------------------------------------------------------
// ANNOUNCEMENTS MANAGEMENT
// -------------------------------------------------------------

// GET /api/admin/announcements
adminRouter.get('/announcements', requireAdminAuth(), (_req, res) => {
  res.json(adminStore.getAnnouncements());
});

// POST /api/admin/announcements
adminRouter.post('/announcements', requireAdminAuth(['SUPER_ADMIN', 'ADMIN', 'MODERATOR']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { title, content, priority, targetAudience } = req.body || {};
  const admin = req.adminUser!;

  if (!title || !content) {
    res.status(400).json({ error: 'Title and content are required.' });
    return;
  }

  const newAnn = {
    id: `ann-${Date.now()}`,
    title: title.trim(),
    content: content.trim(),
    priority: priority || 'MEDIUM',
    targetAudience: targetAudience || 'ALL',
    authorAdmin: admin.name || admin.username,
    createdAt: new Date().toISOString(),
    active: true,
  };

  adminStore.addAnnouncement(newAnn);

  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'ANNOUNCEMENT_CREATED',
    target: newAnn.title,
    status: 'SUCCESS',
    metadata: { priority: newAnn.priority },
  });

  res.status(201).json(newAnn);
});

// PUT /api/admin/announcements/:id
adminRouter.put('/announcements/:id', requireAdminAuth(['SUPER_ADMIN', 'ADMIN', 'MODERATOR']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const updates = req.body || {};
  const admin = req.adminUser!;

  const updated = adminStore.updateAnnouncement(id, updates);
  if (!updated) {
    res.status(404).json({ error: 'Announcement not found.' });
    return;
  }

  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'ANNOUNCEMENT_UPDATED',
    target: updated.title,
    status: 'SUCCESS',
    metadata: updates,
  });

  res.json(updated);
});

// DELETE /api/admin/announcements/:id
adminRouter.delete('/announcements/:id', requireAdminAuth(['SUPER_ADMIN', 'ADMIN', 'MODERATOR']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const admin = req.adminUser!;

  const success = adminStore.deleteAnnouncement(id);
  if (!success) {
    res.status(404).json({ error: 'Announcement not found.' });
    return;
  }

  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'ANNOUNCEMENT_DELETED',
    target: id,
    status: 'SUCCESS',
  });

  res.json({ success: true, message: 'Announcement deleted.' });
});

// -------------------------------------------------------------
// LEADERBOARD & LEAGUE RULES
// -------------------------------------------------------------

// GET /api/admin/leaderboard
adminRouter.get('/leaderboard', requireAdminAuth(), (_req, res) => {
  const rules = adminStore.getLeaderboardRules();
  const weekly = adminStore.getPeriodLeaderboard('weekly');
  const byTier: Record<string, any[]> = {};
  (rules.leagueTiers || ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond']).forEach((tier: string) => {
    byTier[tier] = weekly.rankings.filter((u: any) => u.tier === tier);
  });
  res.json({ rules, leagues: byTier, weekly });
});

// GET /api/admin/leaderboard/daily
adminRouter.get('/leaderboard/daily', requireAdminAuth(), (_req, res) => {
  const dailyData = adminStore.getDailyLeaderboard();
  res.json(dailyData);
});

// GET /api/admin/leaderboard/daily/archives
adminRouter.get('/leaderboard/daily/archives', requireAdminAuth(), (_req, res) => {
  const archives = adminStore.getDailySnapshots();
  res.json(archives);
});

// POST /api/admin/leaderboard/daily/reset - Trigger daily reset / snapshot now
adminRouter.post('/leaderboard/daily/reset', requireAdminAuth(['SUPER_ADMIN', 'ADMIN']), (req: AuthenticatedAdminRequest, res: Response) => {
  const { dateKey } = req.body || {};
  const admin = req.adminUser!;

  const snapshot = adminStore.triggerDailyReset(dateKey);

  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'MANUAL_DAILY_RESET_TRIGGERED',
    target: snapshot.dateKey,
    status: 'SUCCESS',
    metadata: { dateKey: snapshot.dateKey, totalMinutes: snapshot.totalStudyMinutes, champion: snapshot.top3[0]?.name },
  });

  res.json({
    success: true,
    message: `Daily reset for ${snapshot.dateKey} completed successfully. Standings archived.`,
    snapshot,
  });
});

// PUT /api/admin/leaderboard/rules
adminRouter.put('/leaderboard/rules', requireAdminAuth(['SUPER_ADMIN', 'ADMIN']), (req: AuthenticatedAdminRequest, res: Response) => {
  const updates = req.body || {};
  const admin = req.adminUser!;

  const updatedRules = adminStore.updateLeaderboardRules({
    ...updates,
    lastCalculatedAt: new Date().toISOString(),
  });

  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'LEADERBOARD_RULES_UPDATED',
    target: 'GLOBAL_LEAGUE_RULES',
    status: 'SUCCESS',
    metadata: updates,
  });

  res.json(updatedRules);
});

// -------------------------------------------------------------
// PLATFORM SETTINGS & SECURITY
// -------------------------------------------------------------

// GET /api/admin/settings
adminRouter.get('/settings', requireAdminAuth(), (_req, res) => {
  res.json(adminStore.getSettings());
});

// PUT /api/admin/settings
adminRouter.put('/settings', requireAdminAuth(['SUPER_ADMIN']), (req: AuthenticatedAdminRequest, res: Response) => {
  const updates = req.body || {};
  const admin = req.adminUser!;

  const updatedSettings = adminStore.updateSettings(updates);

  adminStore.logAudit({
    adminId: admin.id,
    adminUsername: admin.username,
    role: admin.role,
    action: 'PLATFORM_SETTINGS_UPDATED',
    target: 'SYSTEM_CONFIGURATION',
    status: 'SUCCESS',
    metadata: updates,
  });

  res.json(updatedSettings);
});
