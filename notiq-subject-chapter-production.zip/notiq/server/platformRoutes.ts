import { Router } from 'express';
import multer from 'multer';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { adminStore } from './adminStore';

export const platformRouter = Router();

const avatarUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const allowed = new Set(['image/jpeg', 'image/png', 'image/webp']);
    cb(null, allowed.has(file.mimetype));
  },
});

const AVATAR_DIR = path.resolve(process.cwd(), 'data/uploads/avatars');
fs.mkdirSync(AVATAR_DIR, { recursive: true });

function imageDimensions(buffer: Buffer, mime: string): { width: number; height: number } | null {
  if (mime === 'image/png' && buffer.length >= 24 && buffer.readUInt32BE(0) === 0x89504e47) {
    return { width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
  }
  if (mime === 'image/webp' && buffer.length >= 30 && buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP') {
    const type = buffer.toString('ascii', 12, 16);
    if (type === 'VP8X' && buffer.length >= 30) {
      return { width: 1 + buffer.readUIntLE(24, 3), height: 1 + buffer.readUIntLE(27, 3) };
    }
    if (type === 'VP8 ' && buffer.length >= 30) return { width: buffer.readUInt16LE(26), height: buffer.readUInt16LE(28) };
    if (type === 'VP8L' && buffer.length >= 25) {
      const b = buffer.readUInt32LE(21); return { width: (b & 0x3fff) + 1, height: ((b >> 14) & 0x3fff) + 1 };
    }
  }
  if (mime === 'image/jpeg' && buffer.length > 4 && buffer[0] === 0xff && buffer[1] === 0xd8) {
    let i = 2;
    while (i + 9 < buffer.length) {
      if (buffer[i] !== 0xff) { i++; continue; }
      const marker = buffer[i + 1]; i += 2;
      if (marker === 0xd8 || marker === 0xd9) continue;
      if (i + 1 >= buffer.length) break;
      const len = buffer.readUInt16BE(i);
      if (marker >= 0xc0 && marker <= 0xc3 || marker >= 0xc5 && marker <= 0xc7 || marker >= 0xc9 && marker <= 0xcb || marker >= 0xcd && marker <= 0xcf) {
        if (i + 7 >= buffer.length) break;
        return { width: buffer.readUInt16BE(i + 5), height: buffer.readUInt16BE(i + 3) };
      }
      i += Math.max(2, len);
    }
  }
  return null;
}

function safeAvatarReference(value: unknown): string | null {
  if (typeof value !== 'string' || !value) return null;
  return value.startsWith('/api/uploads/avatars/') ? value : null;
}

function deleteStoredAvatar(value: unknown) {
  const safe = safeAvatarReference(value);
  if (!safe) return;
  const filename = path.basename(safe);
  const target = path.join(AVATAR_DIR, filename);
  if (target.startsWith(AVATAR_DIR + path.sep)) {
    try { fs.unlinkSync(target); } catch {}
  }
}

// Persistent profile-picture upload. Guest/device avatars are namespaced by their device identity;
// registered avatars are stored against the real registered student id.
platformRouter.post('/profile/avatar', (req, res, next) => {
  avatarUpload.single('avatar')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err instanceof Error ? err.message : 'Invalid image upload.' });
    next();
  });
}, (req, res) => {
  const userId = String(req.body?.userId || '').trim();
  const deviceId = String(req.body?.deviceId || '').trim();
  if (!userId || !req.file) return res.status(400).json({ error: 'Profile id and image are required.' });

  const isGuest = userId.startsWith('device:');
  const isRegistered = adminStore.isRegisteredStudent(userId);
  if (!isGuest && !isRegistered) return res.status(403).json({ error: 'Profile is not a valid registered account.' });
  if (isGuest && deviceId !== userId) return res.status(403).json({ error: 'Device identity mismatch.' });

  const magicOk = (req.file.mimetype === 'image/png' && req.file.buffer.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) ||
    (req.file.mimetype === 'image/jpeg' && req.file.buffer[0] === 0xff && req.file.buffer[1] === 0xd8) ||
    (req.file.mimetype === 'image/webp' && req.file.buffer.toString('ascii', 0, 4) === 'RIFF' && req.file.buffer.toString('ascii', 8, 12) === 'WEBP');
  if (!magicOk) return res.status(400).json({ error: 'Invalid image file.' });
  const dimensions = imageDimensions(req.file.buffer, req.file.mimetype);
  if (!dimensions || dimensions.width < 64 || dimensions.height < 64 || dimensions.width > 8000 || dimensions.height > 8000) {
    return res.status(400).json({ error: 'Image dimensions must be between 64×64 and 8000×8000 pixels.' });
  }

  const ext = req.file.mimetype === 'image/png' ? 'png' : req.file.mimetype === 'image/webp' ? 'webp' : 'jpg';
  const filename = `${crypto.randomUUID()}.${ext}`;
  fs.writeFileSync(path.join(AVATAR_DIR, filename), req.file.buffer, { mode: 0o644 });
  const avatarUrl = `/api/uploads/avatars/${filename}`;

  if (isRegistered) {
    const existing = adminStore.findUserById(userId);
    if (!existing) { try { fs.unlinkSync(path.join(AVATAR_DIR, filename)); } catch {} return res.status(404).json({ error: 'Registered account not found.' }); }
    deleteStoredAvatar(existing.avatar);
    adminStore.updateUser(userId, { avatar: avatarUrl });
  }

  res.json({ success: true, avatarUrl });
});

platformRouter.delete('/profile/avatar', (req, res) => {
  const userId = String(req.body?.userId || '').trim();
  const deviceId = String(req.body?.deviceId || '').trim();
  if (!userId) return res.status(400).json({ error: 'Profile id is required.' });
  const isGuest = userId.startsWith('device:');
  if (isGuest) {
    if (deviceId !== userId) return res.status(403).json({ error: 'Device identity mismatch.' });
    deleteStoredAvatar(req.body?.avatar);
    return res.json({ success: true, avatarUrl: '' });
  }
  const existing = adminStore.findUserById(userId);
  if (!existing) return res.status(404).json({ error: 'Registered account not found.' });
  deleteStoredAvatar(existing.avatar);
  adminStore.updateUser(userId, { avatar: '' });
  res.json({ success: true, avatarUrl: '' });
});


// GET /api/platform/announcements - Active cohort announcements
platformRouter.get('/announcements', (_req, res) => {
  const activeAnnouncements = adminStore
    .getAnnouncements()
    .filter(a => a.active);
  res.json(activeAnnouncements);
});

// GET /api/platform/challenges - Active and upcoming challenges
platformRouter.get('/challenges', (_req, res) => {
  const challenges = adminStore
    .getChallenges()
    .filter(c => c.status === 'ACTIVE' || c.status === 'UPCOMING');
  res.json(challenges);
});

// GET /api/platform/achievements - Active achievements catalog
platformRouter.get('/achievements', (_req, res) => {
  const achievements = adminStore
    .getAchievements()
    .filter(a => a.status === 'ACTIVE');
  res.json(achievements);
});

// GET /api/platform/leaderboard - real study-session based standings
platformRouter.get('/leaderboard', (req, res) => {
  const period = String(req.query.period || 'daily') as 'daily' | 'weekly' | 'monthly' | 'all-time';
  const allowed = new Set(['daily', 'weekly', 'monthly', 'all-time']);
  if (!allowed.has(period)) return res.status(400).json({ error: 'Invalid leaderboard period.' });
  const userId = String(req.query.userId || '').trim();
  res.json(adminStore.getPeriodLeaderboard(period, userId));
});

// Backwards-compatible daily endpoint
platformRouter.get('/leaderboard/daily', (req, res) => {
  const userId = String(req.query.userId || '').trim();
  res.json(adminStore.getDailyLeaderboard(userId));
});

// Historical daily leaderboard snapshots
platformRouter.get('/leaderboard/daily/archives', (_req, res) => {
  res.json(adminStore.getDailySnapshots());
});

platformRouter.get('/leaderboard/history', (req, res) => {
  const period = req.query.period ? String(req.query.period) as any : undefined;
  res.json(adminStore.getLeaderboardHistory(period));
});


platformRouter.get('/leaderboard/notifications', (req, res) => {
  const userId = String(req.query.userId || '').trim();
  res.json(userId && adminStore.isRegisteredStudent(userId) ? adminStore.getLeaderboardNotifications(userId) : []);
});

platformRouter.post('/leaderboard/notifications/read', (req, res) => {
  const userId = String(req.body?.userId || '').trim();
  if (userId && adminStore.isRegisteredStudent(userId)) adminStore.markLeaderboardNotificationsRead(userId);
  res.json({ success: true });
});

// Sync the authenticated/local student profile into the server-side leaderboard directory.
// Only public leaderboard fields are stored; email and private profile data are never exposed.
platformRouter.post('/profile/sync', (req, res) => {
  const { id, username, name, avatar, privacy } = req.body || {};
  if (!id || !username || !name) return res.status(400).json({ error: 'Profile id, username and name are required.' });
  const normalizedId = String(id).trim();
  if (normalizedId.startsWith('device:') || normalizedId === 'guest-user') {
    return res.status(403).json({ error: 'Device-only guest identities are not server accounts.' });
  }
  const existing = adminStore.findUserById(normalizedId);
  if (existing) {
    const updated = adminStore.updateUser(normalizedId, {
      username: String(username).slice(0, 50),
      name: String(name).slice(0, 100),
      avatar: typeof avatar === 'string' ? avatar : existing.avatar,
      showOnLeaderboard: privacy?.showOnLeaderboard !== false,
      showAvatar: privacy?.showAvatar !== false,
      showRealName: privacy?.showRealName !== false,
      lastActiveAt: new Date().toISOString(),
    });
    return res.json({ success: true, user: updated });
  }
  return res.status(404).json({ error: 'Registered student account not found.' });
});

// POST /api/platform/sessions - Log completed study session from frontend
platformRouter.post('/sessions', (req, res) => {
  const { session } = req.body || {};
  if (!session || !session.userId) {
    return res.status(400).json({ error: 'Valid session payload is required.' });
  }
  if (!adminStore.isRegisteredStudent(String(session.userId))) {
    return res.status(403).json({ error: 'Only registered student accounts can create server study records.' });
  }
  const result = adminStore.recordStudySession(session);
  if (!result.accepted) return res.status(422).json({ success: false, ...result });
  res.json({ success: true, ...result });
});

